# TEST REPORT

चलाए गए टेस्ट: 67 | समय: 187s | PASS: 67 FAIL: 0 SKIP: 0

> ⚠️ ये टेस्ट Docker/असली Telegram/असली Internet के बिना चले (LocalRunner + mock). देखें README_HINDI.md → 'क्या टेस्ट हुआ, क्या नहीं'.

| नतीजा | टेस्ट | क्या जाँचा |
|---|---|---|
| PASS | test_auto_restart_after_kill | Auto Restart/Recovery: Process को बाहर से मारने पर Monitor दोबारा चालू करता है |
| PASS | test_crashed_process_report | Crashed Process: Error Report में कारण (boom) दिखता है, Status failed |
| PASS | test_missing_configuration | Missing Configuration: Script को MY_API_KEY चाहिए → माँगता है → देने पर चलता है |
| PASS | test_plain_python_script | एक सामान्य Python Script: Upload → Analysis → Host → Logs |
| PASS | test_server_restart_recovery | Server Restart: नया Manager चलते Bot को अपनाता है, बंद मिले तो दोबारा चालू करता है |
| PASS | test_stopped_process | Stopped Process: Stop → बंद, Start → फिर चालू, बाकी Bot पर असर नहीं |
| PASS | test_syntax_error | Invalid Python Syntax: Host नहीं होता, लाइन नंबर के साथ कारण बताता है |
| PASS | test_aiogram_env_flow | aiogram Script: BOT_TOKEN Environment से पढ़ती है → Token देकर Host, Commands पहचाने |
| PASS | test_hardcoded_token_in_source | Code में लिखा Token: जाँचा जाता है; गलत निकले तो नया माँगकर (अनुमति से) बदला जाता है |
| PASS | test_javascript_bot_vendored | JavaScript Telegram Bot: package.json/commands पहचान, Token Environment से, Host |
| PASS | test_javascript_plain_and_syntax_error | JavaScript: सामान्य Script चलती है; Syntax गलती पकड़ी जाती है |
| PASS | test_ptb_patch_declined | Source बदलने की अनुमति न देने पर Code नहीं बदलता और Bot Host नहीं होता |
| PASS | test_ptb_placeholder_patch | python-telegram-bot Script: placeholder Token → अनुमति के बाद सिर्फ़ एक लाइन बदली, backup रहा |
| PASS | test_telebot_script_full_flow | TeleBot Script: Framework/Commands पहचान, Token माँगना, गलत/सही Token, Host, Token Logs में नहीं |
| PASS | test_token_reuse_rejected | एक Token दो Bots में नहीं लग सकता |
| PASS | test_dependency_safety_rules | Dependency सुरक्षा: URL/Git/option/typosquat रोके जाते हैं; पुराने API के लिए version pin |
| PASS | test_missing_module_error_classification | Missing Module Error: Logs से पहचान कर सही package का नाम सुझाता है |
| PASS | test_missing_requirements_txt_detection | requirements.txt नहीं है: Imports से Packages पहचाने गए (अनुमति वाली नीति के साथ) |
| PASS | test_missing_unknown_package_needs_permission | Missing Package (अनजान नाम): बिना अनुमति Install नहीं, पूछता है; मना करने पर blocked |
| PASS | test_offline_install_fails_gracefully | pip Install फेल (Internet नहीं): साफ़ संदेश, Bot failed, Crash नहीं |
| PASS | test_requirements_name_fix_and_blocked | requirements.txt में telebot → pyTelegramBotAPI अपने-आप सही; URL वाली line blocked |
| PASS | test_env_file_upload_refused | .env फाइल: सहेजी नहीं जाती, संदेश मिटाया जाता है |
| PASS | test_secret_redaction_and_paths | Secret Redaction और Path Traversal Protection |
| PASS | test_static_scan_blocks_dangerous_code | खतरनाक Code (docker.sock/miner/reverse shell): रोका जाता है, चलाया नहीं जाता, फाइलें हटती हैं |
| PASS | test_unsupported_language_project | PHP/HTML/APK Project: पहचान होती है, चलाने का दावा नहीं (Runtime नहीं) |
| PASS | test_upload_size_limit | बहुत बड़ी फाइल रोकी जाती है |
| PASS | test_zip_attacks_blocked | ZIP सुरक्षा: Zip-Slip, Symlink, Zip-Bomb, Absolute path, Password ZIP रोके जाते हैं |
| PASS | test_zip_project_nested_root | ZIP Project: एक Folder के अंदर Project, कई Scripts, सही Entry (main.py) चुनी गई |
| PASS | test_zip_slip_through_upload_creates_no_bot | Upload के रास्ते आया खराब ZIP: कोई Bot नहीं बनता, संदेश मिलता है |
| PASS | test_admin_friend_block_flow | Owner: Friend जोड़ना/हटाना/Block/Unblock/Broadcast/Stats/Backup; सभी को समान Access |
| PASS | test_group_chat_ignored | Group Chat में Bot कुछ नहीं करता |
| PASS | test_menu_22_buttons_all_work | Menu के सभी 22 बटन (और Owner का Admin बटन) काम करते हैं, कोई खाली नहीं |
| PASS | test_restart_hosting_command | /restartserver: पुष्टि के बाद ही Hosting Bot Restart माँगता है |
| PASS | test_slash_commands_and_permissions | सभी Slash Commands चलते हैं; Owner Commands पर Friend को मना |
| PASS | test_stranger_blocked | अनजान User: कोई सुविधा/Upload नहीं, बस एक बार निजी बॉट वाला संदेश |
| PASS | test_two_users_separation | दो अलग Users: अलग Folder; एक दूसरे का Bot/Token/Logs/Files नहीं छू सकता |
| PASS | test_bot_attach_and_analyze_only | requirements.txt Attach, और सिर्फ़-विश्लेषण मोड (Host नहीं) |
| PASS | test_user_backup_restore_and_db_backup | Backup & Restore: User Backup (Tokens Encrypted) → Restore, Database Backup → Restore |
| PASS | test_exports_and_txt_parse | JSON/TXT/CSV Export और TXT Import parsing |
| PASS | test_permission_denied_and_auth | Firebase Permission Denied: Bypass नहीं; सही Auth देने पर ही पढ़ा जाता है |
| PASS | test_public_url | Firebase Public URL: Connected, Response Time, Structure, Total/Online/Offline |
| PASS | test_ui_full_check_and_export | Firebase UI: पुष्टि → जाँच → नतीजा → Export (JSON/TXT/CSV फाइलें) |
| PASS | test_ui_requires_authorization_confirmation | Firebase UI: नया URL जाँचने से पहले 'मैं अधिकृत हूँ' की पुष्टि माँगता है; Mass-scan नहीं |
| PASS | test_unknown_schema_no_guessing | Schema अलग हो तो Online/Offline का अंदाज़ा नहीं लगाता |
| PASS | test_wrong_url | गलत Firebase URL: Invalid/Not Found साफ़ पहचाना |
| PASS | test_bot_limit_per_user | हर User के Bots की सीमा |
| PASS | test_config_validation | Config: खाली Token/Owner/Key पर साफ़ Hindi संदेश; local runner बिना अनुमति नहीं |
| PASS | test_docker_runner_command_is_hardened | Docker command में Isolation flags हैं और docker.sock कभी नहीं (Docker न होने पर भी command बनाकर जाँचा) |
| PASS | test_log_clear_and_rename_delete | Logs साफ़ करना, Rename, Delete (फाइलें/Token भी हटते हैं) |
| PASS | test_no_hardcoded_secrets_in_source | Source में कोई Telegram Token/API Key hardcoded नहीं |
| PASS | test_server_status_and_resources | Server Status/CPU/RAM/Disk/Running Bots Text |
| PASS | test_bad_token_and_oversize | गलत GitHub Token पर साफ़ संदेश; बहुत बड़ा Snapshot रोका जाता है |
| PASS | test_store_roundtrip_single_commit_history | GitHub Store: Snapshot भेजना/पढ़ना, और History नहीं बढ़ता (parentless commit) |
| PASS | test_kick_uploads_soon_after_change | नया Bot बनते ही (बदलाव पर) कुछ सेकंड में Snapshot GitHub पर पहुँच जाता है |
| PASS | test_malicious_snapshot_rejected_and_wrong_key | खराब Snapshot (../ path, symlink) और गलत SECRET_KEY रोके जाते हैं |
| PASS | test_pack_unpack_encrypted_roundtrip | Snapshot: Encrypted, venv/node_modules/logs बाहर, Restore पर DB और Project लौटते हैं, path ठीक होते हैं |
| PASS | test_restore_error_never_overwrites | GitHub पढ़ना फेल हुआ तो खाली Data से असली Snapshot नहीं मिटाता; 404 (पहली बार) हो तो Upload चलता है |
| PASS | test_secret_key_any_string | SECRET_KEY कोई भी लंबा string हो (Render का generateValue) तो चलता है; वही string हमेशा वही key |
| PASS | test_bots_run_as_separate_uids_and_cannot_read_manager_or_each_other | PROCESS mode (root): हर Bot अलग uid; Manager का DB और दूसरे Bot की files पढ़ नहीं सकता |
| PASS | test_fsize_limit_kills_big_writer | ulimit: एक फाइल की साइज़ सीमा पार करने पर Bot रोका जाता है |
| PASS | test_memory_limit_enforced | RAM सीमा: ज़्यादा Memory लेने वाला Bot Monitor रोक देता है और बताता है |
| PASS | test_full_cycle_snapshot_restore_recover_quietly | Render Restart जैसा चक्र: Bot चलता है → Snapshot → पूरा Data मिटा → Restore → Bot अपने-आप वापस (शांत संदेश) |
| PASS | test_recover_without_deps_starts_directly | Dependencies नहीं हैं तो Restore के बाद सीधे Start (reinstall नहीं) |
| PASS | test_gating_and_config_validation | ProcessRunner सिर्फ़ Render पर; Render में GitHub Token/Repo बिना रोका जाता है |
| PASS | test_health_server | Health URL: /health पर 200 'ok' (GET/HEAD), बाकी 404, कोई जानकारी लीक नहीं |
| PASS | test_render_main_end_to_end_boot_uses_snapshot | render_main.run(): खाली repo → चालू; Restore 'error' हो तो रुकता है (exit 3), असली Data सुरक्षित |
| PASS | test_snapshot_status_in_admin | Admin Panel में Snapshot की स्थिति दिखती है और 'अभी Snapshot' बटन काम करता है |