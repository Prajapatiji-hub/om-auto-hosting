#!/usr/bin/env bash
# OM AUTO HOSTING BOT - Ubuntu Server (Oracle Cloud Always Free आदि) पर Install Script.
# चलाएँ:  chmod +x install.sh && ./install.sh      (root नहीं, सामान्य user से; sudo खुद माँगेगा)
set -euo pipefail
cd "$(dirname "$0")"
APP_DIR="$(pwd)"
RUN_USER="${SUDO_USER:-$(id -un)}"

say() { printf '\n\033[1;32m== %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m⚠️  %s\033[0m\n' "$*"; }
die() { printf '\033[1;31m❌ %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] && [ -z "${SUDO_USER:-}" ] && die "root से नहीं चलाएँ. सामान्य user (जैसे ubuntu) से चलाएँ."
command -v sudo >/dev/null || die "sudo चाहिए."
grep -qi ubuntu /etc/os-release 2>/dev/null || warn "यह Script Ubuntu के लिए बनी है; दूसरे Linux पर कुछ बदलना पड़ सकता है."

say "1/9  Linux packages (Python3, pip, venv, Node.js, npm, SQLite, iptables…)"
sudo apt-get update -y
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-pip python3-venv nodejs npm sqlite3 \
  git curl ca-certificates iptables unzip

say "2/9  Docker"
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com -o /tmp/get-docker.sh
  sudo sh /tmp/get-docker.sh
fi
sudo systemctl enable --now docker
sudo usermod -aG docker "$RUN_USER" || true

say "3/9  Python virtual environment और Manager की Libraries"
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
.venv/bin/python - <<'PYCHK'
import sys
assert sys.version_info >= (3, 10), "Python 3.10+ चाहिए (Ubuntu 22.04/24.04 में होता है)"
PYCHK

say "4/9  Sandbox image बन रही है (पहली बार 5-10 मिनट लग सकते हैं)"
sudo docker build -t om-sandbox:latest .

say "5/9  अलग Docker network (Bots एक-दूसरे से बात नहीं कर सकेंगे)"
if ! sudo docker network inspect om_net >/dev/null 2>&1; then
  sudo docker network create --driver bridge \
    -o com.docker.network.bridge.enable_icc=false \
    -o com.docker.network.bridge.name=om-br0 om_net
fi

say "6/9  Firewall नियम (Bots को Host/Cloud-metadata से दूर रखना)"
sed "s|__APP_DIR__|$APP_DIR|g" deploy/om-firewall.service.template | sudo tee /etc/systemd/system/om-firewall.service >/dev/null
chmod +x deploy/om-firewall.sh
sudo systemctl daemon-reload
sudo systemctl enable --now om-firewall.service || warn "Firewall service शुरू नहीं हुई; 'sudo journalctl -u om-firewall' देखें."

say "7/9  Configuration (.env)"
if [ ! -f .env ]; then
  umask 077
  cp .env.example .env
  KEY="$(.venv/bin/python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
  echo
  echo "अब 3 जानकारी चाहिए. (Token टाइप/पेस्ट करने पर स्क्रीन पर कुछ नहीं दिखेगा - यह सामान्य है, फिर Enter दबाएँ.)"
  read -r -s -p "Hosting Bot का Token (@BotFather से): " BT; echo
  read -r -p "आपका Telegram User ID (@userinfobot से): " OWN
  read -r -p "दोस्तों के User ID (comma से अलग, खाली छोड़ सकते हैं): " FR
  read -r -p "आपका Telegram username बिना @ (वैकल्पिक): " UN
  sed -i "s|^BOT_TOKEN=.*|BOT_TOKEN=$BT|; s|^OWNER_ID=.*|OWNER_ID=$OWN|; s|^FRIEND_IDS=.*|FRIEND_IDS=$FR|; s|^OWNER_USERNAME=.*|OWNER_USERNAME=$UN|; s|^SECRET_KEY=.*|SECRET_KEY=$KEY|" .env
  chmod 600 .env
  warn "SECRET_KEY का Backup अलग सुरक्षित जगह रखें: .env फाइल में SECRET_KEY= वाली लाइन."
else
  echo ".env पहले से है, बदली नहीं."
fi

say "8/9  छोटी Server के लिए Swap (वैकल्पिक, 1 GB RAM वाली VM में मददगार)"
if [ ! -f /swapfile ] && [ "$(free -m | awk '/^Mem:/{print $2}')" -lt 3000 ]; then
  read -r -p "2 GB Swap बनाऊँ? [y/N]: " SW
  if [ "${SW:-n}" = "y" ] || [ "${SW:-n}" = "Y" ]; then
    sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
    grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
  fi
fi

say "9/9  Hosting Bot को systemd Service बनाना (Server Restart पर अपने-आप चालू)"
sed "s|__RUN_USER__|$RUN_USER|g; s|__APP_DIR__|$APP_DIR|g" deploy/om-hosting.service.template | sudo tee /etc/systemd/system/om-hosting.service >/dev/null
chmod +x start.sh
sudo systemctl daemon-reload
sudo systemctl enable --now om-hosting.service

echo
say "तैयार! ✅"
echo "• स्थिति देखें:   sudo systemctl status om-hosting"
echo "• Logs देखें:     sudo journalctl -u om-hosting -f"
echo "• अब Telegram में अपने Hosting Bot पर /start भेजें."
warn "पहली बार docker group लगने के लिए SSH से logout करके दोबारा login करें (अगर 'permission denied' दिखे)."
