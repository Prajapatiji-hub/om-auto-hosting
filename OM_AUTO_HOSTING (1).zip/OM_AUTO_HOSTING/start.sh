#!/usr/bin/env bash
# Hosting Bot चलाने की स्क्रिप्ट (systemd भी इसी को चलाता है).
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "❌ .env फाइल नहीं मिली. पहले: cp .env.example .env  और उसे भरें (या ./install.sh चलाएँ)." >&2
  exit 1
fi
PY=python3
[ -x .venv/bin/python ] && PY=.venv/bin/python

"$PY" - <<'PYCHK'
import sys
if sys.version_info < (3, 10):
    sys.exit("❌ Python 3.10 या नया चाहिए. install.sh चलाएँ.")
PYCHK

if ! command -v docker >/dev/null 2>&1; then
  echo "⚠️ Docker नहीं मिला - Bots Host नहीं हो पाएँगे. ./install.sh चलाएँ." >&2
fi
exec "$PY" main.py
