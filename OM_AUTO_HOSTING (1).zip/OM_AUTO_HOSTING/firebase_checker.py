"""firebase_checker.py - अधिकृत Firebase Realtime Database URLs की जाँच.

नियम (कोड में लागू):
- सिर्फ़ वही URL जाँचे जाते हैं जिन पर User ने "मैं अधिकृत हूँ" की पुष्टि की.
- Authentication / Security Rules को Bypass नहीं किया जाता. Private DB पर "Permission Denied" बताया जाता है.
  (चाहें तो User अपना Auth token/secret दे सकता है - वही जो उसके पास वैध रूप से है.)
- APK/Website/दूसरे Project से URLs निकालकर Mass Scan नहीं होता. सिर्फ़ User के दिए URLs.
- Redirect फॉलो नहीं होते; सिर्फ़ firebaseio.com / firebasedatabase.app होस्ट चलते हैं.
- Online/Offline सिर्फ़ तब गिना जाता है जब Data Schema साफ़ पहचाना जाए, वरना "उपलब्ध नहीं".
"""
from __future__ import annotations

import csv
import io
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

import requests

from security_manager import redact
from utils import esc, iso_now

HOST_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,60}(\.[a-z0-9-]+)?\.(firebaseio\.com|firebasedatabase\.app)$")
MAX_URLS = 50
SAMPLE = 200
ONLINE_BOOL = ("online", "isOnline", "is_online", "isonline")
ONLINE_STR = ("status", "state", "presence")
ONLINE_VALUES = {"online", "active"}
OFFLINE_VALUES = {"offline", "inactive"}


def normalize_url(raw: str, allow_any_host: bool = False) -> tuple[bool, str]:
    """(ok, url_or_reason). Query/Fragment/'.json' हटाकर साफ़ URL."""
    raw = (raw or "").strip().strip("<>\"'")
    if not raw:
        return False, "URL खाली है."
    if "://" not in raw:
        raw = "https://" + raw
    try:
        u = urlparse(raw)
    except ValueError:
        return False, "URL का format गलत है."
    if u.scheme != "https":
        return False, "सिर्फ़ https URL चलते हैं."
    if u.username or u.password or "@" in (u.netloc or ""):
        return False, "URL में user/password नहीं होना चाहिए."
    host = (u.hostname or "").lower()
    if not allow_any_host and not HOST_RE.match(host):
        return False, "यह Firebase Realtime Database का URL नहीं लगता (…firebaseio.com या …firebasedatabase.app होना चाहिए)."
    path = u.path or ""
    if path.endswith(".json"):
        path = path[:-5]
    path = path.rstrip("/")
    if re.search(r"[^A-Za-z0-9_\-./%]", path):
        return False, "Path में अजीब अक्षर हैं."
    port = f":{u.port}" if u.port and allow_any_host else ""
    return True, f"https://{host}{port}{path}"


def _default_get(url, params=None, timeout=10):
    return requests.get(url, params=params, timeout=timeout, allow_redirects=False)


def _is_collection(val) -> bool:
    return isinstance(val, dict) and len(val) > 0 and all(isinstance(v, dict) for v in val.values())


def _presence(record):
    """(True/False/None) - रिकॉर्ड में साफ़ पहचाना गया Online/Offline, वरना None. (field नाम भी लौटाता है)"""
    if not isinstance(record, dict):
        return None, None
    for f in ONLINE_BOOL:
        if f in record and isinstance(record[f], (bool, int)) and record[f] in (True, False, 0, 1):
            return bool(record[f]), f
    for f in ONLINE_STR:
        v = record.get(f)
        if isinstance(v, str):
            lv = v.strip().lower()
            if lv in ONLINE_VALUES:
                return True, f
            if lv in OFFLINE_VALUES:
                return False, f
    return None, None


def _count_presence(records: list) -> dict:
    on = off = unk = 0
    fields = set()
    for r in records:
        st, f = _presence(r)
        if st is None:
            unk += 1
        else:
            fields.add(f)
            if st:
                on += 1
            else:
                off += 1
    n = len(records)
    recognized = n > 0 and (on + off) / n >= 0.8 and len(fields) == 1
    return {"online": on, "offline": off, "unknown": unk, "n": n, "recognized": recognized, "field": next(iter(fields)) if fields else None}


def check_url(raw_url: str, auth: str | None = None, http_get=None, timeout: int = 10, allow_any_host=False) -> dict:
    get = http_get or _default_get
    res = {"url": "", "status": "invalid_url", "message": "", "http_status": None, "response_ms": None,
           "structure": {}, "total_records": None, "online": None, "offline": None, "schema": "n/a",
           "estimated": False, "notes": [], "checked_at": iso_now()}
    ok, val = normalize_url(raw_url, allow_any_host)
    if not ok:
        res["message"] = val
        res["url"] = redact(str(raw_url))[:200]
        return res
    base = val
    res["url"] = base
    auth_p = {"auth": auth} if auth else {}

    def fetch(extra=None):
        params = {**auth_p, **(extra or {})}
        t0 = time.time()
        r = get(base + "/.json", params=params, timeout=timeout)
        return r, int((time.time() - t0) * 1000)

    try:
        r, ms = fetch({"shallow": "true"})
    except requests.Timeout:
        res.update(status="timeout", message="Server ने समय पर जवाब नहीं दिया.")
        return res
    except requests.RequestException as e:
        res.update(status="error", message="Connection नहीं हो सका: " + redact(type(e).__name__))
        return res
    res["response_ms"] = ms
    res["http_status"] = r.status_code
    code = r.status_code
    if code in (401, 403):
        res.update(status="permission_denied", message="Permission denied — Database Private है (Security Rules पढ़ने नहीं देते)."
                   + (" दिया हुआ Auth भी काम नहीं आया." if auth else " Auth token देना हो तो 'Auth सेट करें' से दें."))
        return res
    if code == 404:
        res.update(status="not_found", message="Database नहीं मिला (URL गलत या Database मौजूद नहीं).")
        return res
    if code in (402, 423):
        res.update(status="disabled", message=f"Database उपलब्ध नहीं (HTTP {code}) — बंद/Lockdown/Billing की समस्या हो सकती है.")
        return res
    if code >= 300:
        res.update(status="error", message=f"अनपेक्षित जवाब (HTTP {code}).")
        return res
    try:
        data = r.json()
    except ValueError:
        res.update(status="error", message="जवाब JSON नहीं था.")
        return res

    res["status"] = "connected"
    res["message"] = "Connection सफल."
    if data is None:
        res["structure"] = {"root_type": "null", "top_keys": [], "key_count": 0}
        res["total_records"] = 0
        res["notes"].append("Database (या यह Path) खाली है.")
        return res
    if not isinstance(data, dict):
        res["structure"] = {"root_type": type(data).__name__, "top_keys": [], "key_count": 1}
        res["total_records"] = 1
        res["notes"].append("Root पर सीधा एक value है, records नहीं.")
        return res

    keys = list(data.keys())
    res["structure"] = {"root_type": "object", "top_keys": keys[:20], "key_count": len(keys)}

    # पहले कुछ children का नमूना लेकर तय करो: root में Collections हैं या सीधे Records
    def sample_of(path_suffix: str, limit: int):
        try:
            rr = get(base + path_suffix + "/.json", params={**auth_p, "orderBy": '"$key"', "limitToFirst": limit}, timeout=timeout)
        except requests.RequestException:
            return None
        if rr.status_code != 200:
            return None
        try:
            return rr.json()
        except ValueError:
            return None

    head = sample_of("", 3) or {}
    kinds = ["collection" if _is_collection(v) else ("record" if isinstance(v, dict) else "value") for v in head.values()]
    res["structure"]["child_kinds"] = sorted(set(kinds))
    records_pool: list = []
    total = 0
    exact = True

    if kinds and all(k == "collection" for k in kinds):
        # Root में Collections (जैसे users, orders)
        coll_counts = {}
        for ck in keys[:10]:
            try:
                rr = get(f"{base}/{ck}/.json", params={**auth_p, "shallow": "true"}, timeout=timeout)
            except requests.RequestException:
                continue
            if rr.status_code == 200:
                try:
                    d = rr.json()
                except ValueError:
                    continue
                if isinstance(d, dict):
                    coll_counts[ck] = len(d)
                    s = sample_of(f"/{ck}", SAMPLE)
                    if isinstance(s, dict):
                        records_pool.extend(list(s.values()))
                        if len(d) > SAMPLE:
                            exact = False
        if len(keys) > 10:
            exact = False
            res["notes"].append("सिर्फ़ पहली 10 collections गिनी गईं.")
        res["structure"]["collections"] = coll_counts
        total = sum(coll_counts.values())
    elif kinds and all(k == "record" for k in kinds):
        total = len(keys)
        s = sample_of("", SAMPLE)
        if isinstance(s, dict):
            records_pool = list(s.values())
        exact = len(keys) <= SAMPLE
    else:
        total = len(keys)
        res["notes"].append("Data का ढाँचा मिला-जुला है; Online/Offline की गणना नहीं हो सकती.")
        exact = True
    res["total_records"] = total

    if records_pool:
        pc = _count_presence(records_pool)
        if pc["recognized"]:
            res["schema"] = f"पहचाना: '{pc['field']}' field"
            if pc["unknown"]:
                res["notes"].append(f"{pc['unknown']} records में Online/Offline field नहीं मिला (वे गिनती में नहीं).")
            if exact and len(records_pool) == total:
                res["online"], res["offline"] = pc["online"], pc["offline"]
            else:
                ratio_on = pc["online"] / max(1, pc["online"] + pc["offline"])
                res["online"] = round(total * ratio_on)
                res["offline"] = total - res["online"]
                res["estimated"] = True
                res["notes"].append(f"Online/Offline अनुमानित है (पहले {len(records_pool)} records के आधार पर).")
        else:
            res["schema"] = "अनजान schema"
            res["notes"].append("Online/Offline के लिए साफ़ field (online/isOnline/status) नहीं मिला, इसलिए यह जानकारी उपलब्ध नहीं.")
    else:
        res["notes"].append("Records का नमूना नहीं मिल सका; Online/Offline उपलब्ध नहीं.")
    return res


def check_many(urls: list[str], auth_for=None, http_get=None, allow_any_host=False, workers=4) -> list[dict]:
    urls = list(dict.fromkeys(u.strip() for u in urls if u and u.strip()))[:MAX_URLS]

    def one(u):
        return check_url(u, auth=(auth_for(u) if auth_for else None), http_get=http_get, allow_any_host=allow_any_host)

    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(one, urls))


def parse_url_list(text: str) -> list[str]:
    out = []
    for line in (text or "").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            out.append(line.split()[0])
    return out


# ---------------------------------------------------------------- exports
def export_json(results: list[dict]) -> bytes:
    return json.dumps({"generated": iso_now(), "results": results}, ensure_ascii=False, indent=2).encode("utf-8")


def export_txt(results: list[dict]) -> bytes:
    L = [f"Firebase Check Report — {iso_now()} UTC", "=" * 50]
    for r in results:
        L.append(f"URL: {r['url']}")
        L.append(f"  Status: {r['status']} — {r['message']}")
        L.append(f"  Response time: {r['response_ms']} ms | HTTP: {r['http_status']}")
        if r["status"] == "connected":
            L.append(f"  Total records: {r['total_records']} | Online: {r['online'] if r['online'] is not None else 'N/A'} | Offline: {r['offline'] if r['offline'] is not None else 'N/A'}")
            L.append(f"  Schema: {r['schema']}{' (अनुमानित)' if r['estimated'] else ''}")
            L.append(f"  Top keys: {', '.join(r['structure'].get('top_keys', []))}")
        for n in r["notes"]:
            L.append(f"  Note: {n}")
        L.append("-" * 50)
    return "\n".join(L).encode("utf-8")


def export_csv(results: list[dict]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["url", "status", "http_status", "response_ms", "total_records", "online", "offline", "schema", "estimated", "top_keys", "message"])
    for r in results:
        w.writerow([r["url"], r["status"], r["http_status"], r["response_ms"], r["total_records"],
                    "" if r["online"] is None else r["online"], "" if r["offline"] is None else r["offline"],
                    r["schema"], r["estimated"], "|".join(r["structure"].get("top_keys", [])), r["message"]])
    return buf.getvalue().encode("utf-8-sig")


def result_html(r: dict) -> str:
    icon = {"connected": "🟢", "permission_denied": "🔒", "invalid_url": "⚠️", "not_found": "❓", "timeout": "⏱", "disabled": "⛔", "error": "❌"}.get(r["status"], "•")
    L = [f"{icon} <code>{esc(r['url'])}</code>", f"स्थिति: <b>{esc(r['status'])}</b> — {esc(r['message'])}"]
    if r["response_ms"] is not None:
        L.append(f"⚡ Response: {r['response_ms']} ms (HTTP {r['http_status']})")
    if r["status"] == "connected":
        s = r["structure"]
        L.append(f"🧱 Root: {esc(s.get('root_type'))} | Keys: {s.get('key_count')}" + (f" ({esc(', '.join(s.get('top_keys', [])[:8]))})" if s.get("top_keys") else ""))
        L.append(f"📊 Total records: <b>{r['total_records']}</b>")
        if r["online"] is not None:
            L.append(f"🟢 Online: {r['online']} | ⚪ Offline: {r['offline']}" + (" (अनुमानित)" if r["estimated"] else "") + f" — {esc(r['schema'])}")
        else:
            L.append("🟢 Online/Offline: उपलब्ध नहीं")
    for n in r["notes"]:
        L.append("ℹ️ " + esc(n))
    return "\n".join(L)
