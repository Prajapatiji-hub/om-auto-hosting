"""logs_manager.py - System Logs और Bot Logs (Secrets हमेशा छिपे रहते हैं)."""
from __future__ import annotations

import logging
import logging.handlers
import time
from pathlib import Path

from security_manager import redact


class RedactingFilter(logging.Filter):
    def filter(self, record):
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            pass
        return True


def setup_system_logging(cfg) -> logging.Logger:
    cfg.logs_dir.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(getattr(logging, cfg.log_level, logging.INFO))
    for h in list(root.handlers):
        if getattr(h, "_om", False):
            root.removeHandler(h)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh = logging.handlers.RotatingFileHandler(cfg.logs_dir / "om.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    sh = logging.StreamHandler()
    for h in (fh, sh):
        h._om = True
        h.setFormatter(fmt)
        h.addFilter(RedactingFilter())
        root.addHandler(h)
    # requests/urllib3 URL में Token छप सकता है
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("TeleBot").setLevel(logging.WARNING)
    return logging.getLogger("om")


def tail_system_log(cfg, lines=60) -> str:
    p = Path(cfg.logs_dir) / "om.log"
    if not p.exists():
        return ""
    data = p.read_bytes()[-80_000:].decode("utf-8", "ignore").splitlines()
    return redact("\n".join(data[-lines:]))


class LogsManager:
    def __init__(self, cfg, db, runner, tokens):
        self.cfg, self.db, self.runner, self.tokens = cfg, db, runner, tokens

    def _runtime_file(self, bot) -> Path:
        return Path(bot["project_dir"]).parent / "runtime.log"

    def secrets_for(self, bot) -> list[str]:
        return self.tokens.all_secrets(bot["id"], bot["owner_id"])

    def event(self, bot_id: int, level: str, message: str, secrets=()):
        self.db.add_log(bot_id, level, redact(message, secrets))

    def get_logs(self, bot, tail=40) -> str:
        """Live logs (चल रहा हो) या पिछला सहेजा हुआ snapshot. Secrets छिपे हुए."""
        st = self.db.get_status(bot["id"])
        text = self.runner.logs(bot["id"], tail=tail, since_ts=st.get("logs_since") or 0)
        if not text.strip():
            f = self._runtime_file(bot)
            if f.exists():
                text = "\n".join(f.read_text("utf-8", "ignore").splitlines()[-tail:])
        return redact(text, self.secrets_for(bot))

    def snapshot(self, bot):
        """Container हटाने/Restart से पहले Logs फाइल में सहेजना."""
        st = self.db.get_status(bot["id"])
        text = self.runner.logs(bot["id"], tail=2000, since_ts=st.get("logs_since") or 0)
        if text.strip():
            f = self._runtime_file(bot)
            f.parent.mkdir(parents=True, exist_ok=True)
            safe = redact(text, self.secrets_for(bot))
            f.write_text(safe[-300_000:], "utf-8")

    def clear(self, bot):
        self.db.update_status(bot["id"], logs_since=time.time())
        self.runner.clear_logs(bot["id"])
        f = self._runtime_file(bot)
        if f.exists():
            f.unlink()
        self.db.clear_logs(bot["id"])
