"""bot_manager.py - Hosting का दिमाग: Upload → Analysis → Config → Install → Start → Monitor.

हर Hosted Bot: अलग Project folder, अलग Container/Process, अलग Token.
हर Public function में Owner/Permission जाँच होती है (एक User दूसरे का Bot नहीं छू सकता).
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import threading
import time
from pathlib import Path

import command_detector
import error_handler
import file_analyzer
import project_detector
import security_manager as sec
from dependency_manager import DependencyManager
from docker_runner import RunnerError
from token_manager import TokenManager
from utils import ago, esc, human_duration, human_size, iso_now, pre

log = logging.getLogger("om.manager")


class BotError(Exception):
    """User को दिखाने लायक Error (Hindi message)."""


def dir_size(path) -> int:
    total = 0
    for dp, _dn, fns in os.walk(path):
        for f in fns:
            try:
                total += os.lstat(os.path.join(dp, f)).st_size
            except OSError:
                pass
    return total


class BotManager:
    def __init__(self, cfg, db, runner, tokens: TokenManager, deps: DependencyManager, logs, notifier=None):
        self.cfg, self.db, self.runner, self.tokens, self.deps, self.logs = cfg, db, runner, tokens, deps, logs
        self._notify = notifier or (lambda uid, text, buttons=None: None)
        self._locks: dict[int, threading.RLock] = {}
        self._busy: set[int] = set()
        self._autofix: dict[int, int] = {}
        self._glock = threading.Lock()
        self._tl = threading.local()
        self._install_sem = threading.Semaphore(1)   # Render की छोटी RAM में एक बार में एक Install
        self.on_change = lambda: None                # Snapshot जल्दी लेने का संकेत

    # ------------------------------------------------------------ helpers
    def set_notifier(self, fn):
        self._notify = fn

    def _changed(self):
        try:
            self.on_change()
        except Exception:
            pass

    def n(self, uid, text, buttons=None):
        if getattr(self._tl, "quiet", False) and not str(text).startswith(("❌", "⛔", "🛑", "♻️", "🚨")):
            return  # Restart के बाद की चुपचाप Recovery: सिर्फ़ ज़रूरी संदेश
        try:
            self._notify(uid, text, buttons)
        except Exception as e:  # Telegram error से Hosting न रुके
            log.warning("notify failed: %s", e)

    def lock(self, bot_id) -> threading.RLock:
        with self._glock:
            return self._locks.setdefault(bot_id, threading.RLock())

    def bot_root(self, owner_id, bot_id) -> Path:
        return sec.safe_join(self.cfg.users_dir, str(int(owner_id)), "bots", str(int(bot_id)))

    def get_for(self, actor_id: int, bot_id: int, allow_owner_admin=False) -> dict:
        """Permission-checked Bot. दूसरे User का Bot मिलने पर PermissionError जैसा व्यवहार."""
        bot = self.db.get_bot(int(bot_id))
        if bot is None:
            raise BotError("यह Bot नहीं मिला.")
        if bot["owner_id"] != actor_id and not (allow_owner_admin and actor_id == self.cfg.owner_id):
            raise BotError("यह Bot नहीं मिला.")  # जानबूझकर वही message - Bot का अस्तित्व भी नहीं बताते
        return bot

    def analysis_of(self, bot) -> dict:
        try:
            return json.loads(bot.get("analysis_json") or "{}")
        except ValueError:
            return {}

    def save_analysis(self, bot_id, analysis: dict):
        self.db.update_bot(bot_id, analysis_json=json.dumps(analysis, ensure_ascii=False))

    def secrets(self, bot) -> list:
        return self.tokens.all_secrets(bot["id"], bot["owner_id"])

    def run_bg(self, fn, *a):
        t = threading.Thread(target=self._guard, args=(fn, *a), daemon=True)
        t.start()
        return t

    def _guard(self, fn, *a):
        try:
            fn(*a)
        except Exception as e:
            log.exception("background task failed")
            try:
                bot_id = a[0] if a and isinstance(a[0], int) else None
                if bot_id:
                    bot = self.db.get_bot(bot_id)
                    if bot:
                        self.n(bot["owner_id"], "❌ अंदरूनी Error: " + esc(sec.redact(str(e), self.secrets(bot))[:300]))
            except Exception:
                pass

    # ------------------------------------------------------- JS syntax check
    def _js_syntax_check(self, root) -> list[dict]:
        out = []
        root = Path(root)
        n = 0
        for p in sec.iter_project_files(root):
            if p.suffix.lower() not in (".js", ".cjs", ".mjs"):
                continue
            n += 1
            if n > 60:
                break
            rel = str(p.relative_to(root))
            argv = self.runner.node_argv(root, "--check", rel)
            r = self.runner.run_oneshot(root, argv, network=False, timeout=30, mem_mb=256)
            if r.rc != 0 and "SyntaxError" in r.text:
                m = re.search(r"(?:^|\n)\s*(?:[^\n]*?):(\d+)\n", r.text)
                msg = next((l for l in r.text.splitlines() if "SyntaxError" in l), "SyntaxError")
                out.append({"file": rel, "line": int(m.group(1)) if m else 0, "msg": msg.strip()[:200]})
        return out

    # ============================================================ UPLOAD
    def create_from_file(self, owner_id: int, stored_path: str, filename: str) -> int | None:
        """Stage A: Receive → Detect → Analyze → Security → Config पूछना. Bot id लौटाता है."""
        ftype = project_detector.detect_file_type(filename)
        if len(self.db.list_bots(owner_id)) >= self.cfg.max_bots_per_user:
            self.n(owner_id, f"⚠️ आप {self.cfg.max_bots_per_user} Bots तक Host कर सकते हैं. पहले कोई पुराना Bot Delete करें.")
            return None
        bot_id = self.db.create_bot(owner_id, ftype["name"] or "bot", self.bot_root(owner_id, 0))
        root = self.bot_root(owner_id, bot_id)
        project = root / "project"
        project.mkdir(parents=True, exist_ok=True)
        os.chmod(root, 0o700)
        self.db.update_bot(bot_id, project_dir=str(project))
        self.db.add_upload(owner_id, bot_id, filename, stored_path, os.path.getsize(stored_path),
                           _sha256(stored_path), ftype["kind"])
        self.n(owner_id, f"📥 <b>{esc(filename)}</b> मिली — {esc(ftype['label'])}. जाँच शुरू…")
        try:
            if ftype["kind"] == "zip":
                sec.safe_extract_zip(stored_path, project, max_files=self.cfg.max_zip_files,
                                     max_total_bytes=self.cfg.max_zip_uncompressed_mb * 1048576)
                sec.flatten_single_root(project)
            elif ftype["kind"] in ("python", "javascript"):
                shutil.copy2(stored_path, project / sec.safe_filename(filename))
            else:
                raise BotError("यह फाइल Hosting के लिए समर्थित नहीं है.")
        except (sec.SecurityError, BotError) as e:
            self._abort(bot_id, owner_id, f"⛔ {esc(str(e))}")
            return None
        except OSError as e:
            self._abort(bot_id, owner_id, f"❌ फाइल सहेजने में दिक्कत: {esc(str(e))}")
            return None

        try:
            runtimes = self.runner.runtimes()
        except RunnerError as e:
            self._abort(bot_id, owner_id, f"❌ {esc(str(e))}")
            return None
        info = project_detector.scan_project(project, runtimes)
        if not info.runnable:
            msg = "\n".join("• " + esc(u) for u in info.unsupported) or "चलाने लायक Project नहीं मिला."
            langs = ", ".join(f"{k} ({v})" for k, v in sorted(info.languages.items()))
            self._abort(bot_id, owner_id, "🚫 <b>Host नहीं हो सकता</b>\n" + msg + (f"\nपहचानी गई भाषाएँ: {esc(langs)}" if langs else ""))
            return None

        findings = sec.static_scan(project)
        crit = [f for f in findings if f.severity == "critical"]
        analysis = file_analyzer.analyze_project(project, info, js_syntax_checker=self._js_syntax_check)
        ad = analysis.to_dict()
        ad["findings"] = [f.to_dict() for f in findings[:40]]
        ad["info"] = {"files": len(info.files), "languages": info.languages, "notes": info.notes,
                      "candidates": info.entry_candidates}
        name = _unique_name(self.db, owner_id, Path(info.entry).stem if info.entry else (ftype["name"] or "bot"))
        self.db.update_bot(bot_id, name=name, runtime=info.runtime, entry_file=info.entry,
                           framework=analysis.framework or "", analysis_json=json.dumps(ad, ensure_ascii=False))
        report = file_analyzer.format_analysis_html(analysis, info, findings)
        self.n(owner_id, report)
        if crit:
            shutil.rmtree(project, ignore_errors=True)
            project.mkdir(parents=True, exist_ok=True)
            self.db.update_bot(bot_id, status="blocked")
            self.db.update_status(bot_id, last_error="गंभीर सुरक्षा समस्या मिली, Code हटा दिया गया.")
            self.n(owner_id, "⛔ <b>सुरक्षा कारण से रोका गया.</b> इस Code में खतरनाक pattern मिले (ऊपर देखें). "
                             "मैंने इसे चलाया नहीं और फाइलें हटा दीं. अगर यह गलत अलार्म है तो Code से वह हिस्सा हटाकर दोबारा भेजें.")
            return bot_id
        self.logs.event(bot_id, "info", "Upload analysis पूरा")
        self._changed()
        self._continue(bot_id)
        return bot_id

    def _abort(self, bot_id, owner_id, text):
        bot = self.db.get_bot(bot_id)
        if bot:
            shutil.rmtree(self.bot_root(owner_id, bot_id), ignore_errors=True)
            self.db.delete_bot(bot_id)
        self.n(owner_id, text)

    # ======================================================= CONFIG FLOW
    def _continue(self, bot_id):
        """Config पूरी है? नहीं तो अगली चीज़ माँगो; हाँ तो Install+Start शुरू."""
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        analysis = self.analysis_of(bot)
        owner = bot["owner_id"]
        # Code में लिखा Token जाँचो
        self._verify_source_token(bot, analysis)
        analysis = self.analysis_of(self.db.get_bot(bot_id))
        miss = self.tokens.next_missing(bot, analysis)
        if miss:
            self.db.update_bot(bot_id, status="awaiting_config")
            self.db.set_state(owner, f"await_cfg:{bot_id}", {"bot_id": bot_id, "name": miss["name"], "kind": miss["kind"]})
            self.n(owner, self._ask_text(bot, miss))
            return
        # placeholder patch की अनुमति
        for c in self.tokens.config_status(bot, analysis):
            if c["method"] == "placeholder" and c["status"] == "set":
                self.db.update_bot(bot_id, status="awaiting_config")
                self.n(owner,
                       f"✍️ <b>{esc(bot['name'])}</b>: आपकी फाइल <code>{esc(c['file'])}</code> (लाइन {c['line']}) में "
                       f"'{esc(c['name'])}' की जगह placeholder लिखा है, और यह Script Environment से नहीं पढ़ती.\n"
                       "चलाने के लिए उस एक लाइन में आपका दिया Value डालना होगा. मूल फाइल <code>.om_backup/</code> में सुरक्षित रहेगी.\n"
                       "क्या मैं सिर्फ़ वही एक लाइन बदलूँ?",
                       [[("✅ हाँ, बदलो", f"patch:{bot_id}:{_slug(c['name'])}:y"), ("❌ नहीं", f"patch:{bot_id}:{_slug(c['name'])}:n")]])
                return
        self.db.set_state(owner, "", {})
        self.run_bg(self.finalize, bot_id)

    def _ask_text(self, bot, miss) -> str:
        if miss["kind"] == "token":
            return (f"🔑 <b>{esc(bot['name'])}</b> को Telegram Bot Token चाहिए.\n"
                    "कृपया इस Bot का Token <b>इसी निजी चैट</b> में भेजें (@BotFather से मिलता है).\n"
                    "🔒 मैं आपका Message तुरंत मिटा दूँगा, Token Encrypted रखूँगा और कभी वापस नहीं दिखाऊँगा.")
        return (f"🔑 <b>{esc(bot['name'])}</b> की Script को <code>{esc(miss['name'])}</code> चाहिए "
                f"({esc(miss.get('file') or '')}).\nकृपया इसकी Value इसी निजी चैट में भेजें.\n"
                "🔒 Message मिटा दिया जाएगा, Value Encrypted रखी जाएगी.")

    def _verify_source_token(self, bot, analysis):
        changed = False
        for c in analysis.get("config", []):
            if c["kind"] == "token" and c["method"] == "source_present" and not c.get("verified") and analysis.get("is_telegram"):
                path = Path(bot["project_dir"]) / c["file"]
                try:
                    line = path.read_text("utf-8", "ignore").split("\n")[c["line"] - 1]
                except (OSError, IndexError):
                    continue
                m = sec.TOKEN_RE.search(line)
                if not m:
                    continue
                res = self.tokens.verify(m.group(0))
                c["verified"] = True
                if res["ok"]:
                    self.tokens.save_bot_token(bot["id"], bot["owner_id"], m.group(0), res)
                    c["note"] = f"Code का Token सही है (@{res.get('username', '')})"
                elif res["kind"] in ("invalid", "format"):
                    self.n(bot["owner_id"], f"⚠️ <b>{esc(bot['name'])}</b>: Code में लिखा Token Telegram ने नहीं माना. नया Token देना होगा.")
                    c["method"] = "placeholder"
                    c["literal"] = "__TOKEN__"
                    c["note"] = "Code का पुराना Token गलत था"
                elif res["kind"] == "same_as_host":
                    c["method"] = "placeholder"
                    c["literal"] = "__TOKEN__"
                changed = True
        if changed:
            self.save_analysis(bot["id"], analysis)

    def provide_value(self, owner_id: int, bot_id: int, req_name: str, value: str) -> tuple[bool, str]:
        """User से मिला Token/API value सुरक्षित रखना. (ok, message)"""
        bot = self.get_for(owner_id, bot_id)
        analysis = self.analysis_of(bot)
        req = next((c for c in analysis.get("config", []) if c["name"] == req_name), None)
        value = (value or "").strip()
        if req is None and req_name == "__token__":
            req = {"kind": "token", "name": "Telegram Bot Token"}
        if req is None:
            return False, "यह Configuration इस Bot में नहीं मिली."
        if req["kind"] == "token":
            if analysis.get("is_telegram", True):
                res = self.tokens.verify(value)
                if not res["ok"]:
                    return False, res["message"]
                if self.tokens.token_used_elsewhere(res.get("id"), bot_id):
                    return False, "यह Token पहले से किसी और Hosted Bot में लगा है. एक Token से एक ही Bot चल सकता है."
            else:
                res = {"ok": False}
            self.tokens.save_bot_token(bot_id, owner_id, value, res)
            msg = res.get("message", "Token सुरक्षित रख लिया.")
        else:
            if not value or len(value) > 800 or re.search(r"[\r\n\x00]", value):
                return False, "Value खाली/बहुत लंबी है या उसमें नई लाइन है."
            self.tokens.save_api_value(owner_id, bot_id, req["name"], value)
            msg = f"{req['name']} सुरक्षित रख ली."
        self.logs.event(bot_id, "info", f"{req['name']} सेट हुई")
        self._changed()
        # Token बदलने पर चलता Bot नई value से Restart होना चाहिए
        if bot["status"] == "running":
            self.run_bg(self._restart_job, bot_id)
        else:
            self.db.set_state(owner_id, "", {})
            self.run_bg(self._continue, bot_id)
        return True, msg

    def add_manual_config(self, owner_id: int, bot_id: int, name: str) -> str:
        """User खुद कोई Environment Variable (API Key) जोड़ना चाहे तो."""
        bot = self.get_for(owner_id, bot_id)
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]{0,40}$", name or ""):
            raise BotError("नाम सिर्फ़ अक्षर/अंक/_ का हो (जैसे MY_API_KEY).")
        if name.upper() in ("PATH", "HOME", "PYTHONPATH", "LD_PRELOAD", "LD_LIBRARY_PATH", "NODE_OPTIONS", "PYTHONSTARTUP", "NODE_PATH"):
            raise BotError("यह Environment नाम सुरक्षा कारण से नहीं बदला जा सकता.")
        analysis = self.analysis_of(bot)
        if not any(c["name"] == name for c in analysis.get("config", [])):
            analysis.setdefault("config", []).append(
                {"kind": "api", "name": name, "method": "env", "env_names": [name], "file": "", "line": 0,
                 "literal": "", "optional": False, "note": "आपने खुद जोड़ा"})
            self.save_analysis(bot_id, analysis)
        return name

    def apply_patch(self, owner_id: int, bot_id: int, slug: str, yes: bool) -> str:
        bot = self.get_for(owner_id, bot_id)
        analysis = self.analysis_of(bot)
        req = next((c for c in analysis.get("config", []) if _slug(c["name"]) == slug and c["method"] == "placeholder"), None)
        if req is None:
            return "यह अनुरोध अब मान्य नहीं है."
        if not yes:
            return "ठीक है, Source नहीं बदला गया. Bot तभी चलेगा जब Script को Value मिल सके (आप फाइल में खुद Environment Variable से पढ़ने का Code रख सकते हैं)."
        if req["kind"] == "token":
            value = self.tokens.get_bot_token(bot_id, owner_id)
        else:
            value = self.tokens.get_api_value(owner_id, bot_id, req["name"])
        if not value:
            return "Value नहीं मिली, पहले Token/Key दें."
        ok, why = TokenManager.patch_placeholder(bot["project_dir"], req, value)
        if not ok:
            return "❌ " + why
        req["method"] = "patched"
        req["note"] = "आपकी अनुमति से एक लाइन बदली गई"
        self.save_analysis(bot_id, analysis)
        self.logs.event(bot_id, "info", f"{req['file']}:{req['line']} में placeholder बदला (अनुमति के साथ)")
        self.run_bg(self._continue, bot_id)
        return "✅ एक लाइन बदल दी (मूल फाइल .om_backup में सुरक्षित). अब आगे बढ़ रहा हूँ…"

    # ========================================================= FINALIZE
    def finalize(self, bot_id: int, quiet: bool = False, preclaimed: bool = False):
        """Stage B: Dependencies → Syntax → Start → Observe → Report."""
        with self._glock:
            if bot_id in self._busy and not preclaimed:
                return
            self._busy.add(bot_id)
        self._tl.quiet = quiet
        try:
            self._finalize(bot_id)
        finally:
            self._tl.quiet = False
            with self._glock:
                self._busy.discard(bot_id)
            self._changed()

    def _finalize(self, bot_id):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        owner = bot["owner_id"]
        analysis = self.analysis_of(bot)
        name = esc(bot["name"])
        progress = lambda t: self.n(owner, f"⏳ <b>{name}</b>: {esc(t)}")
        self.db.update_bot(bot_id, status="installing")
        # --- Dependencies
        if bot["runtime"] == "node":
            plan = self.deps.plan_node(bot, analysis)
        else:
            plan = self.deps.plan_python(bot, analysis)
        for note in plan.notes:
            self.n(owner, "ℹ️ " + esc(note))
        for it in plan.items:
            if it.reason and it.status == "ok" and it.source in ("requirements", "pin"):
                self.n(owner, f"🔧 {esc(it.name)}: {esc(it.reason)}")
        if plan.blocked():
            self.n(owner, "🚫 <b>सुरक्षा कारण से Install नहीं होंगे:</b>\n" +
                   "\n".join(f"• {esc(i.name)} — {esc(i.reason)}" for i in plan.blocked()))
        if plan.pending():
            self.db.update_bot(bot_id, status="awaiting_confirm")
            self._record_pending(bot, plan)
            for it in plan.pending():
                self.n(owner, f"❓ <b>{name}</b> को package <code>{esc(it.name)}</code> चाहिए.\n{esc(it.reason)}\n"
                              "सुरक्षा के लिए अनजान package मैं खुद Install नहीं करता. क्या Install करूँ?",
                       [[("✅ Install करो", f"inst:{bot_id}:{it.name}:y"), ("❌ नहीं", f"inst:{bot_id}:{it.name}:n")]])
            return
        with self._install_sem:
            res = self.deps.install_node(bot, plan, progress) if bot["runtime"] == "node" else self.deps.install_python(bot, plan, progress)
        if res.conflicts:
            self.n(owner, "⚠️ Dependency टकराव:\n" + pre("\n".join(res.conflicts[:6]), 800))
        if not res.ok:
            self.db.update_bot(bot_id, status="failed")
            self.db.update_status(bot_id, last_error=sec.redact(res.message, self.secrets(bot)))
            self.n(owner, f"❌ <b>{name}</b>: {esc(res.message)}\n" + (pre(sec.redact(res.log, self.secrets(bot)), 1500) if res.log else ""))
            return
        self.n(owner, f"✅ <b>{name}</b>: {esc(res.message)}")
        # --- Syntax
        analysis = self.analysis_of(self.db.get_bot(bot_id))
        if analysis.get("syntax_errors"):
            e = analysis["syntax_errors"][0]
            self.db.update_bot(bot_id, status="failed")
            self.db.update_status(bot_id, last_error=f"Syntax Error: {e['file']}:{e['line']} {e['msg']}")
            self.n(owner, f"❌ <b>{name}</b>: Syntax Error — <code>{esc(e['file'])}</code> लाइन {e['line']}: {esc(e['msg'])}\n"
                          "Code ठीक करके फाइल दोबारा भेजें. मैं आपका Code खुद नहीं बदलता.")
            return
        # --- Startup test + Host
        self.n(owner, f"🚀 <b>{name}</b>: Start करके {self.cfg.startup_observe_sec} सेकंड जाँच रहा हूँ…")
        ok, detail = self._start_and_observe(bot_id)
        self._after_start_report(bot_id, ok, detail)

    def _record_pending(self, bot, plan):
        for it in plan.pending():
            self.db.set_dep(bot["id"], "npm" if bot["runtime"] == "node" else "pip", it.name, it.spec, it.source, "pending_confirm", it.reason)

    def confirm_dep(self, owner_id: int, bot_id: int, name: str, yes: bool) -> str:
        bot = self.get_for(owner_id, bot_id)
        eco = "npm" if bot["runtime"] == "node" else "pip"
        row = next((r for r in self.db.list_deps(bot_id) if r["name"] == name and r["ecosystem"] == eco), None)
        if not row:
            return "यह अनुरोध अब मान्य नहीं है."
        if not yes:
            self.db.set_dep(bot_id, eco, name, row["spec"], row["source"], "blocked", "User ने मना किया")
            return f"ठीक है, '{name}' Install नहीं होगा. Bot चलने के लिए इसकी जरूरत हो तो Error आएगा."
        ok, why = self.deps.check_manual_name(bot["runtime"], name)
        if not ok and "मिलता-जुलता" not in why:
            return "❌ " + why
        self.db.set_dep(bot_id, eco, name, row["spec"], "confirmed", "confirmed", "User की अनुमति")
        pend = [r for r in self.db.list_deps(bot_id) if r["status"] == "pending_confirm"]
        if not pend:
            self.run_bg(self.finalize, bot_id)
            return f"✅ '{name}' की अनुमति मिली. Install शुरू कर रहा हूँ…"
        return f"✅ '{name}' की अनुमति मिली. बाकी packages का इंतज़ार है."

    def reinstall_deps(self, owner_id: int, bot_id: int):
        bot = self.get_for(owner_id, bot_id)
        self.stop_bot(owner_id, bot_id, quiet=True)
        self.run_bg(self.finalize, bot_id)

    def add_package(self, owner_id: int, bot_id: int, name: str) -> tuple[bool, str]:
        bot = self.get_for(owner_id, bot_id)
        ok, why = self.deps.check_manual_name(bot["runtime"], name)
        if not ok:
            return False, why
        self.deps.add_manual(bot, name.strip())
        self.run_bg(self.finalize, bot_id)
        return True, f"'{name.strip()}' जोड़ा. Install और Restart हो रहा है…"

    # ============================================================ START
    def _check_capacity(self, bot):
        running = len(self.runner.list_running())
        if running >= self.cfg.max_running_total and not self.runner.is_running(bot["id"]):
            raise BotError(f"Server पर एक साथ {self.cfg.max_running_total} से ज़्यादा Bots नहीं चल सकते. कोई Bot Stop करें.")
        size = dir_size(bot["project_dir"])
        if size > self.cfg.disk_limit_mb * 1048576:
            raise BotError(f"Project बहुत बड़ा है ({human_size(size)}); Limit {self.cfg.disk_limit_mb} MB है. Backup/Logs/बेकार फाइलें हटाएँ.")

    def _launch(self, bot):
        self._check_capacity(bot)
        analysis = self.analysis_of(bot)
        env = self.tokens.build_env(bot, analysis)
        root = Path(bot["project_dir"])
        self.runner.prepare_project_dir(root)
        if bot["runtime"] == "node":
            argv = self.runner.node_argv(root, bot["entry_file"])
        else:
            argv = self.runner.python_argv(root, "-u", bot["entry_file"])
        self.logs.snapshot(bot)
        cname = self.runner.start(bot["id"], root, argv, env)
        now = time.time()
        self.db.update_status(bot["id"], state="running", container_name=cname, started_at=iso_now(),
                              last_started_ts=now, last_exit_code=None, pid=self.runner.pid(bot["id"]))
        self.db.update_bot(bot["id"], status="running", desired_state="running")
        self.logs.event(bot["id"], "info", "Bot शुरू किया")
        self._changed()

    def _observe(self, bot_id: int, seconds: int) -> tuple[bool, str]:
        end = time.time() + seconds
        while time.time() < end:
            time.sleep(1)
            if not self.runner.is_running(bot_id):
                return False, "exited"
        return True, "alive"

    def _start_and_observe(self, bot_id: int, seconds=None) -> tuple[bool, str]:
        bot = self.db.get_bot(bot_id)
        with self.lock(bot_id):
            try:
                self._launch(bot)
            except (BotError, RunnerError) as e:
                self.db.update_bot(bot_id, status="failed")
                self.db.update_status(bot_id, last_error=str(e))
                return False, str(e)
            return self._observe(bot_id, seconds or self.cfg.startup_observe_sec)

    def _collect_failure(self, bot_id) -> error_handler.ErrorReport:
        bot = self.db.get_bot(bot_id)
        st = self.runner.state(bot_id) if hasattr(self.runner, "state") else {}
        text = self.logs.get_logs(bot, tail=80)
        rep = error_handler.classify(text, exit_code=st.get("exit_code"), oom=st.get("oom"), runtime=bot["runtime"])
        return rep

    def _after_start_report(self, bot_id: int, alive: bool, detail: str):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        owner, name = bot["owner_id"], esc(bot["name"])
        secrets = self.secrets(bot)
        if alive:
            # चलता दिख रहा है, पर Logs में गंभीर Error तो नहीं?
            tail = self.logs.get_logs(bot, tail=60)
            rep = error_handler.classify(tail, runtime=bot["runtime"])
            if rep.kind in ("invalid_token", "conflict", "missing_config"):
                self.runner.stop(bot_id)
                self._mark_failed(bot_id, rep)
                self.n(owner, error_handler.format_report_html(rep, tail[-1200:], secrets, bot["name"]))
                return
            self.db.update_bot(bot_id, status="running", desired_state="running")
            if getattr(self._tl, "quiet", False):
                self.n(owner, f"♻️ <b>{name}</b> Hosting Restart के बाद अपने-आप वापस चालू हो गया.")
                return
            st = self.db.get_status(bot_id)
            lines = [f"✅ <b>{name}</b> Host हो गया और चल रहा है!",
                     f"🆔 Bot ID: <code>{bot_id}</code> | PID: <code>{self.runner.pid(bot_id) or '—'}</code>"]
            ti = self.tokens.token_info(bot_id, owner)
            if ti and ti.get("username"):
                lines.append(f"🤖 Telegram Bot: @{esc(ti['username'])}")
            analysis = self.analysis_of(bot)
            cmds = analysis.get("commands", [])
            if cmds:
                lines.append("⌨️ पहचाने गए Commands: " + esc(" ".join("/" + c["name"] for c in cmds[:20])))
                menu = command_detector.menu_payload(cmds)
                tok = self.tokens.get_bot_token(bot_id, owner)
                if tok and menu:
                    okm, msgm = self.tokens.set_my_commands(tok, menu)
                    lines.append(("📋 " if okm else "ℹ️ ") + esc(msgm) + " (सिर्फ़ Code में मिले Commands)")
            else:
                lines.append("⌨️ Script में कोई Command नहीं मिला.")
            lines.append("📊 Logs देखने के लिए Menu → Live Logs.")
            self.n(owner, "\n".join(lines), [[("📜 Live Logs", f"act:logs:{bot_id}"), ("📊 Status", f"act:status:{bot_id}")]])
            return
        # बंद हो गया
        st = self.runner.state(bot_id) if hasattr(self.runner, "state") else {}
        rep = self._collect_failure(bot_id)
        tail = self.logs.get_logs(bot, tail=40)
        code = st.get("exit_code")
        if code == 0 and rep.kind in ("unknown",):
            self.db.update_bot(bot_id, status="finished", desired_state="stopped")
            self.db.update_status(bot_id, state="finished", last_exit_code=0)
            self.n(owner, f"ℹ️ <b>{name}</b> चला और ठीक से खत्म हो गया (exit code 0). यह Script लगातार चलने वाली नहीं लगती.\n" +
                   (pre(sec.redact(tail, secrets), 1200) if tail.strip() else ""))
            return
        # सुरक्षित Fix: जाना-पहचाना Missing Module
        if rep.fix and rep.fix.get("known") and self._autofix.get(bot_id, 0) < 2:
            self._autofix[bot_id] = self._autofix.get(bot_id, 0) + 1
            eco = "npm" if rep.fix["action"] == "install_npm" else "pip"
            self.db.set_dep(bot_id, eco, rep.fix["name"], "", "confirmed", "confirmed", "Error से पहचाना (जाना-पहचाना package)")
            self.n(owner, f"🔧 <b>{name}</b>: '{esc(rep.fix['name'])}' नहीं मिला — यह जाना-पहचाना package है, Install करके दोबारा कोशिश कर रहा हूँ.")
            self.finalize_again(bot_id)
            return
        self._mark_failed(bot_id, rep, code)
        extra = None
        if rep.fix and not rep.fix.get("known"):
            eco = "npm" if rep.fix["action"] == "install_npm" else "pip"
            self.db.set_dep(bot_id, eco, rep.fix["name"], "", "import", "pending_confirm", "Error से पहचाना (अनजान नाम)")
            extra = [[(f"✅ '{rep.fix['name']}' Install करो", f"inst:{bot_id}:{rep.fix['name']}:y")]]
        self.n(owner, error_handler.format_report_html(rep, tail, secrets, bot["name"]), extra)

    def finalize_again(self, bot_id):
        with self._glock:
            self._busy.discard(bot_id)
        self.run_bg(self.finalize, bot_id)

    def _mark_failed(self, bot_id, rep, code=None):
        self.db.update_bot(bot_id, status="failed", desired_state="stopped")
        self.db.update_status(bot_id, state="failed", last_error=sec.redact(f"{rep.title}: {rep.detail}"[:500]), last_exit_code=code)
        self.logs.event(bot_id, "error", f"{rep.title}: {rep.detail}", self.secrets(self.db.get_bot(bot_id)))

    # ====================================================== CONTROL (public)
    def start_bot(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        if bot["status"] in ("blocked",):
            raise BotError("यह Bot सुरक्षा कारण से रोका गया था; फाइलें हटाई जा चुकी हैं.")
        if bot["status"] in ("awaiting_config", "awaiting_confirm", "analyzing", "installing"):
            raise BotError("यह Bot अभी तैयार हो रहा है (Config/Install बाकी). Upload के Messages देखें.")
        if self.runner.is_running(bot_id):
            return "ℹ️ Bot पहले से चल रहा है."
        if not (Path(bot["project_dir"]) / (bot["entry_file"] or "_")).exists():
            raise BotError("Entry फाइल नहीं मिली; Bot दोबारा Upload करें.")
        self.run_bg(self._start_job, bot_id)
        return "▶️ Start हो रहा है…"

    def _start_job(self, bot_id):
        bot = self.db.get_bot(bot_id)
        ok, detail = self._start_and_observe(bot_id, seconds=min(10, self.cfg.startup_observe_sec))
        self._after_start_report(bot_id, ok, detail)

    def stop_bot(self, actor: int, bot_id: int, quiet=False) -> str:
        bot = self.get_for(actor, bot_id, allow_owner_admin=True)
        with self.lock(bot_id):
            self.logs.snapshot(bot)
            self.runner.stop(bot_id)
            self.db.update_bot(bot_id, desired_state="stopped", status="stopped" if bot["status"] in ("running", "stopped", "finished", "failed") else bot["status"])
            self.db.update_status(bot_id, state="stopped", pid=None)
            self.logs.event(bot_id, "info", "Bot रोका गया")
        self._changed()
        return "⏹ Bot रोक दिया गया."

    def restart_bot(self, actor: int, bot_id: int) -> str:
        self.get_for(actor, bot_id)
        self.run_bg(self._restart_job, bot_id)
        return "🔄 Restart हो रहा है…"

    def _restart_job(self, bot_id):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        self.stop_bot(bot["owner_id"], bot_id, quiet=True)
        ok, detail = self._start_and_observe(bot_id, seconds=min(10, self.cfg.startup_observe_sec))
        self._after_start_report(bot_id, ok, detail)

    def delete_bot(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        with self.lock(bot_id):
            self.runner.stop(bot_id)
            self.runner.remove(bot_id)
            shutil.rmtree(self.bot_root(bot["owner_id"], bot_id), ignore_errors=True)
            self.db.delete_bot(bot_id)
        self._changed()
        return f"🗑 '{bot['name']}' हमेशा के लिए हटा दिया गया."

    def rename_bot(self, actor: int, bot_id: int, new_name: str) -> str:
        bot = self.get_for(actor, bot_id)
        new_name = re.sub(r"\s+", " ", (new_name or "").strip())
        if not (1 <= len(new_name) <= 40) or re.search(r"[<>\x00-\x1f]", new_name):
            raise BotError("नाम 1 से 40 अक्षर का होना चाहिए (< > नहीं).")
        if any(b["name"].lower() == new_name.lower() and b["id"] != bot_id for b in self.db.list_bots(actor)):
            raise BotError("इस नाम का आपका एक Bot पहले से है.")
        self.db.update_bot(bot_id, name=new_name)
        self._changed()
        return f"✏️ नाम बदलकर '{new_name}' कर दिया."

    def toggle_auto_restart(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        new = 0 if bot["auto_restart"] else 1
        self.db.update_bot(bot_id, auto_restart=new)
        return "🔁 Auto Restart चालू." if new else "🔁 Auto Restart बंद."

    def clear_logs(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        self.logs.clear(bot)
        return "🧹 Logs साफ़ कर दिए."

    # ============================================================ REPORTS
    def status_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        st = self.db.get_status(bot_id)
        running = self.runner.is_running(bot_id)
        icon = {"running": "🟢", "stopped": "🔴", "failed": "❌", "finished": "⚪", "blocked": "⛔"}.get(bot["status"], "🟡")
        if bot["status"] == "running" and not running:
            icon = "🟠"
        L = [f"{icon} <b>{esc(bot['name'])}</b> (ID {bot_id})",
             f"स्थिति: <b>{esc(bot['status'])}</b>" + (" (अभी Process चल रहा है)" if running else "")]
        L.append(f"Runtime: {esc(bot['runtime'] or '—')} | Entry: <code>{esc(bot['entry_file'] or '—')}</code>")
        if bot["framework"]:
            L.append(f"Framework: {esc(bot['framework'])}")
        if running:
            up = time.time() - (st.get("last_started_ts") or time.time())
            stt = self.runner.stats(bot_id)
            L.append(f"⏱ Uptime: {human_duration(up)} | PID: <code>{self.runner.pid(bot_id) or '—'}</code>")
            if stt:
                L.append(f"💻 CPU: {stt.get('cpu', 0):.1f}% | 🧠 RAM: {esc(stt.get('mem_text', '—'))}")
        L.append(f"🔁 Restart गिनती: {st.get('restart_count') or 0} | Auto Restart: {'चालू' if bot['auto_restart'] else 'बंद'}")
        L.append(f"🕒 आखिरी Start: {esc(st.get('started_at') or '—')} ({esc(ago(st.get('started_at')))})")
        if st.get("last_exit_code") is not None:
            L.append(f"🚪 आखिरी Exit code: {st['last_exit_code']}")
        if st.get("last_error"):
            L.append("⚠️ आखिरी Error: " + esc(sec.redact(st["last_error"], self.secrets(bot))[:300]))
        return "\n".join(L)

    def logs_text(self, actor: int, bot_id: int, tail=40) -> str:
        bot = self.get_for(actor, bot_id)
        text = self.logs.get_logs(bot, tail=tail)
        return f"📜 <b>{esc(bot['name'])}</b> — Logs\n" + (pre(text, 3300) if text.strip() else "अभी कोई Log नहीं है.")

    def error_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        st = self.db.get_status(bot_id)
        text = self.logs.get_logs(bot, tail=80)
        stt = self.runner.state(bot_id) if hasattr(self.runner, "state") else {}
        rep = error_handler.classify(text, exit_code=stt.get("exit_code") if not stt.get("running") else None, oom=stt.get("oom"), runtime=bot["runtime"])
        if rep.kind == "unknown" and not (st.get("last_error") or text.strip()):
            return f"✅ <b>{esc(bot['name'])}</b>: कोई Error दर्ज नहीं है."
        if rep.kind == "unknown" and st.get("last_error"):
            return f"⚠️ <b>{esc(bot['name'])}</b> का आखिरी Error:\n" + pre(sec.redact(st["last_error"], self.secrets(bot)), 800)
        return error_handler.format_report_html(rep, "\n".join(text.splitlines()[-15:]), self.secrets(bot), bot["name"])

    def commands_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        cmds = self.analysis_of(bot).get("commands", [])
        if not cmds:
            return f"⌨️ <b>{esc(bot['name'])}</b>: Script में कोई Command नहीं मिला."
        rows = [f"/{c['name']} — {esc(c['source'])} ({esc(c['file'])}:{c['line']})" + ("" if c.get("menu_ok") else " ⚠️ Menu में नहीं (छोटे अक्षर चाहिए)") for c in cmds]
        return f"⌨️ <b>{esc(bot['name'])}</b> के Commands (Code में मिले):\n" + "\n".join(rows)

    def apply_commands_menu(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        cmds = self.analysis_of(bot).get("commands", [])
        tok = self.tokens.get_bot_token(bot_id, actor)
        if not tok:
            return "इस Bot का Token सेट नहीं है, इसलिए Menu सेट नहीं हो सकता."
        ok, msg = self.tokens.set_my_commands(tok, command_detector.menu_payload(cmds))
        return ("✅ " if ok else "ℹ️ ") + msg

    def reanalyze_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        root = Path(bot["project_dir"])
        info = project_detector.scan_project(root, self.runner.runtimes())
        a = file_analyzer.analyze_project(root, info, js_syntax_checker=self._js_syntax_check)
        findings = sec.static_scan(root)
        old = self.analysis_of(bot)
        ad = a.to_dict()
        # पुरानी स्थिति (patched/verified flags) बनाए रखो
        oc = {c["name"]: c for c in old.get("config", [])}
        for c in ad["config"]:
            if c["name"] in oc and oc[c["name"]]["method"] == "patched":
                c["method"] = "patched"
        ad["findings"] = [f.to_dict() for f in findings[:40]]
        ad["info"] = old.get("info", {})
        self.save_analysis(bot_id, ad)
        return file_analyzer.format_analysis_html(a, info, findings, self.secrets(bot))

    def analyze_only(self, owner_id: int, stored_path: str, filename: str) -> str:
        """सिर्फ़ विश्लेषण (Host नहीं). अस्थायी folder में, बाद में हटाया जाता है."""
        import tempfile
        ftype = project_detector.detect_file_type(filename)
        tmp = Path(tempfile.mkdtemp(prefix="an_", dir=str(self.cfg.data_dir / "tmp")))
        try:
            if ftype["kind"] == "zip":
                sec.safe_extract_zip(stored_path, tmp, max_files=self.cfg.max_zip_files, max_total_bytes=self.cfg.max_zip_uncompressed_mb * 1048576)
                sec.flatten_single_root(tmp)
            elif ftype["kind"] in ("python", "javascript"):
                shutil.copy2(stored_path, tmp / sec.safe_filename(filename))
            else:
                return f"ℹ️ {esc(ftype['label'])} — सिर्फ़ पहचान: यह Hosting योग्य Script/ZIP नहीं है."
            info = project_detector.scan_project(tmp, self.runner.runtimes())
            a = file_analyzer.analyze_project(tmp, info, js_syntax_checker=self._js_syntax_check)
            return file_analyzer.format_analysis_html(a, info, sec.static_scan(tmp))
        except sec.SecurityError as e:
            return "⛔ " + esc(str(e))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def files_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        root = Path(bot["project_dir"])
        rows = []
        for p in sorted(sec.iter_project_files(root, limit=400)):
            rel = str(p.relative_to(root))
            if rel.startswith((".om_backup", ".venv")) or rel == ".om_requirements.txt":
                continue
            try:
                rows.append(f"{rel}  ({human_size(p.stat().st_size)})")
            except OSError:
                pass
        total = human_size(dir_size(root))
        shown = "\n".join(rows[:40]) + (f"\n… और {len(rows) - 40} files" if len(rows) > 40 else "")
        return f"📂 <b>{esc(bot['name'])}</b> — {len(rows)} files, कुल {total}\n" + pre(shown or "(खाली)", 3000)

    def deps_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        rows = self.db.list_deps(bot_id)
        if not rows:
            return f"📦 <b>{esc(bot['name'])}</b>: अभी कोई Dependency दर्ज नहीं."
        icon = {"installed": "✅", "detected": "🔎", "failed": "❌", "blocked": "🚫", "pending_confirm": "❓", "confirmed": "👍"}
        L = [f"{icon.get(r['status'], '•')} {esc(r['name'])}{esc(r['spec'])} ({r['ecosystem']}) — {esc(r['status'])}" + (f": {esc(r['detail'])}" if r['detail'] else "") for r in rows[:40]]
        return f"📦 <b>{esc(bot['name'])}</b> की Dependencies:\n" + "\n".join(L)

    def config_text(self, actor: int, bot_id: int) -> str:
        bot = self.get_for(actor, bot_id)
        analysis = self.analysis_of(bot)
        L = [f"🔑 <b>{esc(bot['name'])}</b> — Token / API Settings"]
        ti = self.tokens.token_info(bot_id, actor)
        if ti:
            L.append(f"Telegram Token: {esc(ti['masked'])}" + (f" (@{esc(ti['username'])})" if ti["username"] else "") + (" ✅ जाँचा हुआ" if ti["validated"] else ""))
        else:
            L.append("Telegram Token: सेट नहीं")
        for c in self.tokens.config_status(bot, analysis):
            if c["kind"] == "token":
                continue
            st = {"set": "✅ सेट", "missing": "❌ बाकी", "source": "Code/.env में", "optional": "वैकल्पिक"}[c["status"]]
            L.append(f"{esc(c['name'])}: {st}")
        L.append("🔒 Values कभी वापस नहीं दिखाई जातीं.")
        return "\n".join(L)

    # ============================================================== ATTACH
    def attach_file(self, owner_id: int, bot_id: int, stored_path: str, filename: str) -> str:
        bot = self.get_for(owner_id, bot_id)
        ftype = project_detector.detect_file_type(filename)
        safe = sec.safe_filename(filename)
        if ftype["kind"] == "env_example":
            safe = ".env.example"
        if ftype["kind"] == "dotenv":
            raise BotError("'.env' में Secrets होते हैं; इसे सीधे न भेजें. Token/Keys 'API / Token Settings' से दें.")
        if ftype["kind"] not in ("requirements", "package_json", "env_example", "json", "text", "data"):
            raise BotError("यह फाइल Attach नहीं हो सकती.")
        dest = sec.safe_join(bot["project_dir"], safe)
        shutil.copy2(stored_path, dest)
        self.db.add_upload(owner_id, bot_id, filename, stored_path, os.path.getsize(stored_path), _sha256(stored_path), ftype["kind"])
        if ftype["kind"] in ("requirements", "package_json", "env_example"):
            self.reanalyze_text(owner_id, bot_id)
            was_running = self.runner.is_running(bot_id)
            if was_running:
                self.stop_bot(owner_id, bot_id, quiet=True)
            self.run_bg(self._continue, bot_id)
            return f"📎 {esc(safe)} जोड़ दी. Analysis दोबारा हो रहा है…"
        return f"📎 {esc(safe)} Project में जोड़ दी (Bot का Code नहीं बदला)."

    # ============================================================ MONITOR
    def handle_crash(self, bot_id: int) -> None:
        """Monitor से बुलाया जाता है जब चलना चाहिए वाला Bot बंद मिले."""
        bot = self.db.get_bot(bot_id)
        if not bot or bot["desired_state"] != "running":
            return
        with self.lock(bot_id):
            if self.runner.is_running(bot_id):
                return
            st = self.db.get_status(bot_id)
            state = self.runner.state(bot_id) if hasattr(self.runner, "state") else {}
            code = state.get("exit_code")
            self.logs.snapshot(bot)
            text = self.logs.get_logs(bot, tail=80)
            rep = error_handler.classify(text, exit_code=code, oom=state.get("oom"), runtime=bot["runtime"])
            self.db.update_status(bot_id, last_exit_code=code, last_error=sec.redact(f"{rep.title}: {rep.detail}"[:500]), state="crashed")
            owner = bot["owner_id"]
            name = esc(bot["name"])
            if code == 0 and rep.kind == "unknown":
                self.db.update_bot(bot_id, status="finished", desired_state="stopped")
                self.n(owner, f"ℹ️ <b>{name}</b> ख़ुद खत्म हो गया (exit code 0).")
                return
            now = time.time()
            times = [t for t in json.loads(st.get("restart_times") or "[]") if now - t < self.cfg.restart_window_sec]
            if not bot["auto_restart"] or not rep.recoverable or len(times) >= self.cfg.restart_max_in_window:
                self._mark_failed(bot_id, rep, code)
                why = ("Auto Restart बंद है" if not bot["auto_restart"] else
                       "यह Error Restart से ठीक नहीं होगा" if not rep.recoverable else
                       f"{self.cfg.restart_window_sec // 60} मिनट में {self.cfg.restart_max_in_window} बार Restart हो चुका")
                self.n(owner, f"🛑 <b>{name}</b> बंद हो गया और दोबारा Start नहीं किया गया ({why}).\n" +
                       error_handler.format_report_html(rep, "\n".join(text.splitlines()[-12:]), self.secrets(bot), bot["name"]),
                       [[("▶️ Start", f"act:start:{bot_id}"), ("📜 Logs", f"act:logs:{bot_id}")]])
                return
            times.append(now)
            self.db.update_status(bot_id, restart_count=(st.get("restart_count") or 0) + 1, restart_times=json.dumps(times))
            try:
                self._launch(bot)
            except (BotError, RunnerError) as e:
                self._mark_failed(bot_id, error_handler.ErrorReport("crash", "Restart नहीं हो सका", str(e)), code)
                self.n(owner, f"🛑 <b>{name}</b> Restart नहीं हो सका: {esc(str(e))}")
                return
            if len(times) == 1:
                self.n(owner, f"🔁 <b>{name}</b> अचानक बंद हुआ ({esc(rep.title)}). Auto Restart कर दिया.")
            self.logs.event(bot_id, "warn", f"Crash के बाद Auto Restart (#{len(times)}): {rep.title}")

    def _needs_install(self, bot) -> bool:
        """Render में Restart पर venv/node_modules मिट जाते हैं; Dependencies हों तो दोबारा Install चाहिए."""
        root = Path(bot["project_dir"])
        eco = "npm" if bot["runtime"] == "node" else "pip"
        saved = any(r["ecosystem"] == eco and r["status"] in ("installed", "confirmed") for r in self.db.list_deps(bot["id"]))
        if bot["runtime"] == "node":
            return (root / "package.json").exists() and not (root / "node_modules").exists() or (saved and not (root / "node_modules").exists())
        return (((root / "requirements.txt").exists() or saved) and not (root / ".venv" / "bin" / "python").exists())

    def recover_all(self) -> dict:
        """Hosting Bot/Server Restart के बाद: जो Bots चलने चाहिए थे उन्हें वापस चालू करना (Auto Recovery)."""
        res = {"adopted": 0, "restarted": 0, "failed": 0, "reinstalling": 0}
        for bot in self.db.list_bots():
            if bot["desired_state"] != "running":
                continue
            if self.runner.is_running(bot["id"]):
                res["adopted"] += 1
                continue
            if self.runner.name == "process" and self._needs_install(bot):
                with self._glock:
                    self._busy.add(bot["id"])
                self.db.update_bot(bot["id"], status="installing")
                res["reinstalling"] += 1
                self.run_bg(self.finalize, bot["id"], True, True)
                continue
            try:
                with self.lock(bot["id"]):
                    self._launch(bot)
                res["restarted"] += 1
                self.logs.event(bot["id"], "info", "Hosting Restart के बाद Auto Recovery")
            except Exception as e:
                res["failed"] += 1
                self.db.update_bot(bot["id"], status="failed")
                self.db.update_status(bot["id"], last_error=f"Recovery नहीं हुई: {e}")
        return res

    def enforce_memory_limits(self):
        """PROCESS mode में Docker की RAM-सीमा नहीं होती; RSS देखकर सीमा पार करने वाले Bot को रोकते हैं."""
        if self.runner.name != "process":
            return
        for bot in self.db.list_bots():
            if bot["status"] != "running" or not self.runner.is_running(bot["id"]):
                continue
            mem = (self.runner.stats(bot["id"]) or {}).get("mem_mb", 0)
            if mem > self.cfg.mem_limit_mb:
                self.stop_bot(bot["owner_id"], bot["id"], quiet=True)
                self.db.update_bot(bot["id"], status="failed")
                self.db.update_status(bot["id"], last_error=f"RAM सीमा पार: {mem:.0f} MB > {self.cfg.mem_limit_mb} MB")
                self.logs.event(bot["id"], "error", f"RAM सीमा पार ({mem:.0f} MB) - रोका गया")
                self.n(bot["owner_id"], f"🛑 <b>{esc(bot['name'])}</b> रोका गया: RAM {mem:.0f} MB हो गई (सीमा {self.cfg.mem_limit_mb} MB). "
                                        "Code हल्का करें; Render Free में कुल RAM सिर्फ़ 512 MB है.")

    def enforce_disk_limits(self):
        for bot in self.db.list_bots():
            if bot["status"] != "running":
                continue
            size = dir_size(bot["project_dir"])
            if size > self.cfg.disk_limit_mb * 1048576:
                self.stop_bot(bot["owner_id"], bot["id"], quiet=True)
                self.db.update_bot(bot["id"], status="failed")
                self.db.update_status(bot["id"], last_error=f"Disk limit पार: {human_size(size)}")
                self.n(bot["owner_id"], f"💾 <b>{esc(bot['name'])}</b> रोका गया: Project {human_size(size)} हो गया (Limit {self.cfg.disk_limit_mb} MB).")


def _sha256(path) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


def _slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", name)[:20] or "x"


def _unique_name(db, owner_id, base) -> str:
    base = re.sub(r"[^\w\-. ]+", "", base)[:30] or "bot"
    names = {b["name"].lower() for b in db.list_bots(owner_id)}
    if base.lower() not in names:
        return base
    i = 2
    while f"{base}_{i}".lower() in names:
        i += 1
    return f"{base}_{i}"
