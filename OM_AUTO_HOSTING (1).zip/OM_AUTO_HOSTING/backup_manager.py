"""backup_manager.py - Database Backup/Restore और हर User के Bots का Backup/Restore.

Backup में Tokens सिर्फ़ Encrypted रूप में जाते हैं (SECRET_KEY के बिना बेकार).
⚠️ SECRET_KEY का अलग सुरक्षित Backup रखें; वह खो गई तो Tokens वापस नहीं मिलेंगे.
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path

import security_manager as sec
from utils import human_size, iso_now

SKIP_DIRS = {".venv", "node_modules", "__pycache__", ".git", ".om_backup"}


class BackupError(Exception):
    pass


class BackupManager:
    def __init__(self, cfg, db, manager, tokens):
        self.cfg, self.db, self.manager, self.tokens = cfg, db, manager, tokens
        for d in ("db", "users"):
            p = cfg.backups_dir / d
            p.mkdir(parents=True, exist_ok=True)
            os.chmod(p, 0o700)

    # ---------------------------------------------------------------- DB
    def backup_db(self, note="") -> dict:
        ts = time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time() * 1000) % 1000:03d}"
        dest = self.cfg.backups_dir / "db" / f"om_db_{ts}.db"
        self.db.backup_to(dest)
        os.chmod(dest, 0o600)
        bid = self.db.x("INSERT INTO backups(owner_id,kind,path,size,created_at,note) VALUES(0,'db',?,?,?,?)",
                        (str(dest), dest.stat().st_size, iso_now(), note))
        self._prune(0, "db")
        return {"id": bid, "path": str(dest), "size": dest.stat().st_size}

    def restore_db(self, backup_id: int) -> str:
        row = self.db.q1("SELECT * FROM backups WHERE id=? AND kind='db'", (backup_id,))
        if not row or not Path(row["path"]).is_file():
            raise BackupError("यह Database Backup नहीं मिला.")
        src = Path(row["path"])
        try:
            con = sqlite3.connect(str(src))
            ok = con.execute("PRAGMA integrity_check").fetchone()[0]
            con.close()
        except sqlite3.DatabaseError:
            ok = "bad"
        if ok != "ok":
            raise BackupError("Backup फाइल खराब है (integrity check फेल).")
        self.backup_db(note="restore से पहले का safety backup")
        for ext in ("-wal", "-shm"):
            Path(str(self.db.path) + ext).unlink(missing_ok=True)
        shutil.copy2(src, self.db.path)
        os.chmod(self.db.path, 0o600)
        return "Database Restore हो गया. Hosting Bot Restart होना चाहिए."

    # -------------------------------------------------------------- user
    def backup_user(self, owner_id: int) -> dict:
        bots = self.db.list_bots(owner_id)
        if not bots:
            raise BackupError("आपका कोई Bot नहीं है, Backup किसका लूँ?")
        udir = self.cfg.backups_dir / "users" / str(owner_id)
        udir.mkdir(parents=True, exist_ok=True)
        os.chmod(udir, 0o700)
        ts = time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time() * 1000) % 1000:03d}"
        dest = udir / f"user_{owner_id}_{ts}.zip"
        meta = {"version": 1, "owner_id": owner_id, "created": iso_now(), "bots": []}
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
            for b in bots:
                root = Path(b["project_dir"])
                entry = {k: b[k] for k in ("id", "name", "runtime", "entry_file", "framework", "auto_restart", "desired_state", "analysis_json")}
                trow = self.db.q1("SELECT token_enc,tg_bot_id,bot_username,validated FROM bot_tokens WHERE bot_id=?", (b["id"],))
                entry["token"] = trow
                entry["api"] = self.db.q("SELECT key_name,value_enc FROM api_configurations WHERE bot_id=? AND owner_id=?", (b["id"], owner_id))
                entry["deps"] = [{k: d[k] for k in ("ecosystem", "name", "spec", "source")} for d in self.db.list_deps(b["id"])
                                 if d["status"] in ("installed", "confirmed")]
                meta["bots"].append(entry)
                if root.exists():
                    for p in sec.iter_project_files(root):
                        rel = p.relative_to(root)
                        if any(part in SKIP_DIRS for part in rel.parts) or rel.name == ".om_requirements.txt":
                            continue
                        z.write(p, f"bots/{b['id']}/{rel}")
            z.writestr("meta.json", json.dumps(meta, ensure_ascii=False))
        os.chmod(dest, 0o600)
        bid = self.db.x("INSERT INTO backups(owner_id,kind,path,size,created_at,note) VALUES(?,?,?,?,?,?)",
                        (owner_id, "user", str(dest), dest.stat().st_size, iso_now(), f"{len(bots)} bots"))
        self._prune(owner_id, "user")
        return {"id": bid, "path": str(dest), "size": dest.stat().st_size}

    def restore_user(self, owner_id: int, backup_id: int) -> list[int]:
        """Backup से Bots को नए Bots के रूप में वापस लाना (मौजूदा Bots को छूता नहीं)."""
        row = self.db.q1("SELECT * FROM backups WHERE id=? AND kind='user' AND owner_id=?", (backup_id, owner_id))
        if not row or not Path(row["path"]).is_file():
            raise BackupError("यह Backup नहीं मिला.")
        tmp = Path(tempfile.mkdtemp(prefix="restore_", dir=str(self.cfg.data_dir / "tmp")))
        new_ids = []
        try:
            sec.safe_extract_zip(row["path"], tmp, max_files=20000, max_total_bytes=self.cfg.disk_limit_mb * 1048576 * 6)
            meta = json.loads((tmp / "meta.json").read_text("utf-8"))
            if meta.get("owner_id") != owner_id:
                raise BackupError("यह Backup किसी और User का है.")
            if len(self.db.list_bots(owner_id)) + len(meta["bots"]) > self.cfg.max_bots_per_user:
                raise BackupError(f"Restore के बाद Bots की संख्या {self.cfg.max_bots_per_user} से ज़्यादा हो जाएगी. पहले कुछ Bots Delete करें.")
            key_ok = True
            for e in meta["bots"]:
                if e.get("token"):
                    try:
                        self.tokens.dec(e["token"]["token_enc"])
                    except Exception:
                        key_ok = False
            for e in meta["bots"]:
                name = self.manager_unique(owner_id, e["name"])
                bid = self.db.create_bot(owner_id, name, "x", e["runtime"], e["entry_file"], e["framework"])
                root = self.manager.bot_root(owner_id, bid)
                project = root / "project"
                project.mkdir(parents=True, exist_ok=True)
                os.chmod(root, 0o700)
                src = tmp / "bots" / str(e["id"])
                if src.exists():
                    for item in src.iterdir():
                        shutil.move(str(item), str(project / item.name))
                self.db.update_bot(bid, project_dir=str(project), status="stopped", desired_state="stopped",
                                   auto_restart=e["auto_restart"], analysis_json=e["analysis_json"])
                if e.get("token") and key_ok:
                    t = e["token"]
                    self.db.x("INSERT OR REPLACE INTO bot_tokens(bot_id,owner_id,token_enc,tg_bot_id,bot_username,validated,set_at) VALUES(?,?,?,?,?,?,?)",
                              (bid, owner_id, t["token_enc"], t["tg_bot_id"], t["bot_username"], t["validated"], iso_now()))
                if key_ok:
                    for a in e.get("api", []):
                        self.db.x("INSERT OR REPLACE INTO api_configurations(owner_id,bot_id,key_name,value_enc,set_at) VALUES(?,?,?,?,?)",
                                  (owner_id, bid, a["key_name"], a["value_enc"], iso_now()))
                for d in e.get("deps", []):
                    self.db.set_dep(bid, d["ecosystem"], d["name"], d["spec"], d["source"], "confirmed" if d["source"] in ("manual", "confirmed") else "detected")
                new_ids.append(bid)
            if not key_ok:
                raise_note = "SECRET_KEY बदल गई थी: Tokens/Keys Restore नहीं हुए, दोबारा देने होंगे."
                self.db.set_setting(f"restore_note_{owner_id}", raise_note)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        return new_ids

    def manager_unique(self, owner_id, base):
        names = {b["name"].lower() for b in self.db.list_bots(owner_id)}
        if base.lower() not in names:
            return base
        i = 2
        while f"{base}_restored{i if i > 2 else ''}".lower() in names:
            i += 1
        return f"{base}_restored{i if i > 2 else ''}"

    # -------------------------------------------------------------- list
    def list_backups(self, owner_id: int, kind: str):
        return self.db.q("SELECT * FROM backups WHERE owner_id=? AND kind=? ORDER BY id DESC LIMIT 10", (owner_id, kind))

    def get_backup(self, owner_id: int, backup_id: int, kind: str):
        return self.db.q1("SELECT * FROM backups WHERE id=? AND owner_id=? AND kind=?", (backup_id, owner_id, kind))

    def _prune(self, owner_id, kind):
        rows = self.db.q("SELECT * FROM backups WHERE owner_id=? AND kind=? ORDER BY id DESC", (owner_id, kind))
        for r in rows[self.cfg.backup_keep:]:
            Path(r["path"]).unlink(missing_ok=True)
            self.db.x("DELETE FROM backups WHERE id=?", (r["id"],))
