#!/usr/bin/env python3
"""render_main.py - Render (Free) पर शुरुआत.

क्रम: (1) तुरंत Health URL खोलो (Render को Port चाहिए)  (2) GitHub से पुराना Snapshot Restore
      (3) Hosting Bot चालू + Auto Recovery  (4) Snapshot Thread  (5) बंद होते समय आख़िरी Snapshot.
"""
from __future__ import annotations

import logging
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from config import Config
from logs_manager import setup_system_logging


class _Health(BaseHTTPRequestHandler):
    def _ok(self, body=True):
        if self.path.split("?")[0] in ("/", "/health", "/healthz"):
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            if body:
                self.wfile.write(b"ok")
        else:
            self.send_response(404)
            self.end_headers()

    def do_GET(self):
        self._ok(True)

    def do_HEAD(self):
        self._ok(False)

    def log_message(self, *a):
        pass


def start_health_server(port: int, host="0.0.0.0") -> HTTPServer:
    srv = HTTPServer((host, port), _Health)
    threading.Thread(target=srv.serve_forever, daemon=True, name="health").start()
    return srv


def run(cfg=None, store=None) -> int:
    cfg = cfg or Config.from_env()
    cfg.health_port = 0
    problems = cfg.validate()
    if problems:
        print("❌ Configuration में समस्या:\n" + "\n".join(" • " + p for p in problems), file=sys.stderr)
        return 2
    cfg.ensure_dirs()
    setup_system_logging(cfg)
    log = logging.getLogger("om.render")
    start_health_server(cfg.port)
    log.info("Health URL port %s पर चालू", cfg.port)

    from snapshot_manager import Snapshotter
    snap = None
    if cfg.github_data_token and cfg.data_repo or store is not None:
        from github_store import GithubStore
        store = store or GithubStore(cfg.github_data_token, cfg.data_repo, cfg.data_branch)
        snap = Snapshotter(cfg, None, store)
        state = snap.restore()
        log.info("Snapshot Restore स्थिति: %s", state)
        if state == "error":
            log.error("पुराना Data पढ़ नहीं सका (%s). खाली Data से शुरू करने पर असली Snapshot मिट सकता था, इसलिए रुक रहा हूँ; Render दोबारा कोशिश करेगा.", snap.last_error)
            return 3
    else:
        log.warning("⚠️ GitHub Snapshot बंद है: हर Restart पर सारे Bots और Tokens मिट जाएँगे.")

    def before_recover(ctx):
        if snap is not None:
            snap.db = ctx.db
            ctx.snapshotter = snap
            ctx.manager.on_change = snap.kick

    def on_ready(ctx):
        if snap is not None:
            snap.start()

    def on_shutdown(ctx):
        if snap is not None:
            snap.stop()
            r = snap.snapshot_now(force=True)
            log.info("आख़िरी Snapshot: %s", r)

    import main as hosting_main
    return hosting_main.main(hooks={"before_recover": before_recover, "on_ready": on_ready, "on_shutdown": on_shutdown}, cfg=cfg)


if __name__ == "__main__":
    sys.exit(run())
