"""error_handler.py - Logs/Exit code से Error का कारण पहचानना और आसान Hindi Report बनाना."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from file_analyzer import IMPORT_TO_PIP, KNOWN_PIP, KNOWN_NPM
from security_manager import norm_pkg, redact
from utils import esc, pre


@dataclass
class ErrorReport:
    kind: str = "unknown"
    title: str = "अज्ञात Error"
    detail: str = ""
    module: str = ""
    suggestion: str = ""
    fix: dict | None = None          # {'action': 'install_pip'|'install_npm', 'name':..., 'known': bool}
    recoverable: bool = True         # Auto-restart से ठीक हो सकता है?

    def to_dict(self):
        return self.__dict__.copy()


_TB_LAST = re.compile(r"^([A-Za-z_][\w.]*(?:Error|Exception|Exit|Interrupt|Warning))\s*:?\s*(.*)$")


def last_error_line(text: str) -> str:
    """Traceback की आखिरी Error लाइन (या Node का Error)."""
    lines = [l.rstrip() for l in (text or "").splitlines() if l.strip()]
    for l in reversed(lines):
        if _TB_LAST.match(l.strip()):
            return l.strip()[:300]
        if re.match(r"^(Error|TypeError|ReferenceError|SyntaxError|RangeError):", l.strip()):
            return l.strip()[:300]
    return lines[-1][:300] if lines else ""


def classify(text: str, exit_code=None, oom=False, runtime="python") -> ErrorReport:
    t = text or ""
    low = t.lower()
    last = last_error_line(t)

    if oom or (exit_code == 137 and "killed" in low) or "memoryerror" in low or "heap out of memory" in low:
        return ErrorReport("oom", "RAM की सीमा पार हो गई", last,
                           suggestion="Bot ज़्यादा Memory ले रहा है. Code हल्का करें या Owner से BOT_MEM_LIMIT_MB बढ़ाने को कहें.", recoverable=False)

    m = re.search(r"No module named '([\w.\-]+)'", t)
    if m:
        mod = m.group(1).split(".")[0]
        pip = IMPORT_TO_PIP.get(mod.lower()) or mod
        known = norm_pkg(pip) in KNOWN_PIP
        return ErrorReport("missing_module", f"Python Module नहीं मिला: {mod}", last, module=mod,
                           suggestion=f"Package '{pip}' इंस्टॉल करना होगा." + ("" if known else " (यह नाम अनजान है, इंस्टॉल से पहले आपकी अनुमति लगेगी.)"),
                           fix={"action": "install_pip", "name": pip, "known": known}, recoverable=False)

    m = re.search(r"Cannot find module '([^']+)'", t)
    if m:
        mod = m.group(1)
        if mod.startswith((".", "/")):
            return ErrorReport("missing_file", f"Node file नहीं मिली: {mod}", last, suggestion="Project में वह फाइल मौजूद होनी चाहिए (ZIP में पूरा project भेजें).", recoverable=False)
        pkg = "/".join(mod.split("/")[:2]) if mod.startswith("@") else mod.split("/")[0]
        return ErrorReport("missing_module", f"Node Package नहीं मिला: {pkg}", last, module=pkg,
                           suggestion=f"npm package '{pkg}' इंस्टॉल करना होगा.",
                           fix={"action": "install_npm", "name": pkg, "known": pkg in KNOWN_NPM}, recoverable=False)

    if re.search(r"(IndentationError|TabError|SyntaxError)", t):
        m2 = re.search(r'File "([^"]+)", line (\d+)', t)
        where = f" ({m2.group(1).split('/')[-1]} लाइन {m2.group(2)})" if m2 else ""
        return ErrorReport("syntax", "Code में Syntax गलती" + where, last,
                           suggestion="Code की उस लाइन को ठीक करके फाइल दोबारा भेजें. Hosting Bot आपका Code खुद नहीं बदलता.", recoverable=False)

    if re.search(r"cannot import name|ImportError", t):
        return ErrorReport("dependency", "Library का version Code से मेल नहीं खा रहा", last,
                           suggestion="requirements.txt में सही version लिखें (जैसे python-telegram-bot==13.15 पुराने Code के लिए), फिर Dependency Manager से दोबारा Install करें.",
                           recoverable=False)

    if re.search(r"InvalidToken|Unauthorized|TokenValidationError|Token is invalid|ETELEGRAM: 401|error_code['\"]?:\s*401|\b401\b.*(Unauthorized|Not Found)|Invalid token", t, re.I) or \
            re.search(r"ApiTelegramException.*(401|404)", t):
        return ErrorReport("invalid_token", "Telegram Token गलत है", last,
                           suggestion="Menu → API / Token Settings में सही Token दें (@BotFather से). पुराना Token Revoke हो गया हो सकता है.", recoverable=False)

    if re.search(r"Conflict: terminated by other getUpdates|ETELEGRAM: 409|\b409\b.*Conflict", t, re.I):
        return ErrorReport("conflict", "इसी Token से कोई और Bot भी चल रहा है (409 Conflict)", last,
                           suggestion="एक Token से एक ही जगह Bot चल सकता है. दूसरी जगह वाला Bot बंद करें, फिर यहाँ Restart करें.", recoverable=False)

    m = re.search(r"KeyError: ['\"]([A-Z][A-Z0-9_]{2,})['\"]", t)
    if m or re.search(r"(not set|is missing|missing .*(env|variable|config)|environment variable)", low):
        name = m.group(1) if m else ""
        return ErrorReport("missing_config", f"Configuration नहीं मिली{(': ' + name) if name else ''}", last, module=name,
                           suggestion=("Menu → API / Token Settings में '" + name + "' की value दें.") if name else "Script को जो Environment Variable चाहिए वह API / Token Settings में जोड़ें.",
                           recoverable=False)

    if "EOFError" in t:
        return ErrorReport("interactive", "Script input() माँग रही है", last,
                           suggestion="Hosted Bot में कीबोर्ड input नहीं हो सकता. Token/Keys को Environment Variable से पढ़ें (API / Token Settings).", recoverable=False)

    if re.search(r"Read-only file system|Errno 30|EACCES|PermissionError", t):
        return ErrorReport("permission", "फाइल लिखने की अनुमति नहीं", last,
                           suggestion="Container में सिर्फ़ Project folder (/work) और /tmp में लिख सकते हैं. Code में फाइल इन्हीं जगहों पर बनाएँ.", recoverable=False)

    if re.search(r"EADDRINUSE|Address already in use", t):
        return ErrorReport("port", "Port पहले से इस्तेमाल में है", last, suggestion="Code में Port बदलें; वैसे भी Hosted Bots के Port बाहर नहीं खुलते.", recoverable=False)

    if re.search(r"FileNotFoundError|ENOENT", t):
        m3 = re.search(r"No such file or directory: ['\"]([^'\"]+)['\"]", t)
        return ErrorReport("missing_file", "ज़रूरी फाइल नहीं मिली" + (f": {m3.group(1)}" if m3 else ""), last,
                           suggestion="वह फाइल Project में जोड़ें (ZIP में भेजें) या Code में सही path दें.", recoverable=False)

    if re.search(r"ConnectionError|ConnectTimeout|ReadTimeout|NetworkError|Temporary failure in name resolution|getaddrinfo|ENOTFOUND|ECONNREFUSED|ECONNRESET|ETIMEDOUT|ClientConnectorError|TimeoutError", t, re.I):
        return ErrorReport("connection", "Network/Connection समस्या", last,
                           suggestion="Internet या Telegram तक पहुँच में दिक्कत. Bot खुद दोबारा कोशिश करेगा; बार-बार हो तो Server का Network जाँचें.", recoverable=True)

    if "Traceback" in t or re.search(r"^(Error|TypeError|ReferenceError):", t, re.M):
        return ErrorReport("crash", "Script में Error आया", last, suggestion="नीचे का Error पढ़कर Code ठीक करें और फाइल दोबारा भेजें.", recoverable=True)

    if exit_code not in (None, 0):
        return ErrorReport("crash", f"Script Exit code {exit_code} के साथ बंद हुई", last or "", suggestion="Live Logs देखें.", recoverable=True)
    return ErrorReport("unknown", "कोई साफ़ Error नहीं मिला", last, recoverable=True)


def format_report_html(rep: ErrorReport, logs_tail: str = "", secrets=(), bot_name: str = "") -> str:
    L = [f"🚨 <b>Error Report</b>" + (f" — {esc(bot_name)}" if bot_name else "")]
    L.append(f"<b>{esc(rep.title)}</b>")
    if rep.detail:
        L.append(pre(redact(rep.detail, secrets), 600))
    if rep.suggestion:
        L.append("💡 " + esc(rep.suggestion))
    if logs_tail:
        L.append("📜 आखिरी Logs:")
        L.append(pre(redact(logs_tail, secrets), 1500))
    return "\n".join(L)
