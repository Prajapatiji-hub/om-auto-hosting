"""github_store.py - Render की files हर Restart में मिटती हैं, इसलिए Data एक private GitHub repo में रखते हैं.

हर Snapshot एक नया "parentless" commit बनकर branch को force-update करता है, इसलिए repo का history बढ़ता नहीं.
Snapshot पहले से Encrypted (Fernet, SECRET_KEY) होता है; repo private है फिर भी Plain data नहीं जाता.
"""
from __future__ import annotations

import base64
import logging
import time

import requests

log = logging.getLogger("om.store")
FILE_NAME = "snapshot.bin"


class StoreError(Exception):
    pass


class GithubStore:
    def __init__(self, token: str, repo: str, branch: str = "main", api_base: str = "https://api.github.com", session=None):
        self.token, self.repo, self.branch = token, repo, branch
        self.api = api_base.rstrip("/")
        self.s = session or requests.Session()

    def _h(self, raw=False):
        return {"Authorization": f"Bearer {self.token}",
                "Accept": "application/vnd.github.raw+json" if raw else "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "om-auto-hosting"}

    def _req(self, method, path, **kw):
        try:
            return self.s.request(method, f"{self.api}/repos/{self.repo}{path}", headers=kw.pop("headers", self._h()), timeout=60, **kw)
        except requests.RequestException as e:
            raise StoreError(f"GitHub से जुड़ नहीं सका: {type(e).__name__}")

    # ------------------------------------------------------------ read
    def get_snapshot(self):
        """bytes या None (कुछ सहेजा नहीं गया). Error पर StoreError (यानी 'अनजान', खाली नहीं!)."""
        r = self._req("GET", f"/contents/{FILE_NAME}", params={"ref": self.branch}, headers=self._h(raw=True))
        if r.status_code == 404:
            return None
        if r.status_code in (401, 403):
            raise StoreError("GitHub ने Token नहीं माना/Permission नहीं (Fine-grained token में Contents: Read and write चाहिए).")
        if r.status_code != 200:
            raise StoreError(f"Snapshot पढ़ने में GitHub Error {r.status_code}")
        return r.content

    # ----------------------------------------------------------- write
    def put_snapshot(self, data: bytes, message: str = "snapshot") -> None:
        if len(data) > 90 * 1024 * 1024:
            raise StoreError("Snapshot 90 MB से बड़ा है; Bots की फाइलें छोटी रखें.")
        blob = self._req("POST", "/git/blobs", json={"content": base64.b64encode(data).decode(), "encoding": "base64"})
        self._ok(blob, "blob")
        tree = self._req("POST", "/git/trees", json={"tree": [{"path": FILE_NAME, "mode": "100644", "type": "blob", "sha": blob.json()["sha"]}]})
        self._ok(tree, "tree")
        commit = self._req("POST", "/git/commits", json={"message": f"{message} {time.strftime('%Y-%m-%d %H:%M:%S')}", "tree": tree.json()["sha"], "parents": []})
        self._ok(commit, "commit")
        sha = commit.json()["sha"]
        ref = self._req("PATCH", f"/git/refs/heads/{self.branch}", json={"sha": sha, "force": True})
        if ref.status_code in (404, 422):
            ref = self._req("POST", "/git/refs", json={"ref": f"refs/heads/{self.branch}", "sha": sha})
        self._ok(ref, "ref")

    @staticmethod
    def _ok(r, what):
        if r.status_code in (401, 403):
            raise StoreError("GitHub Token को Write की अनुमति नहीं (Contents: Read and write चाहिए).")
        if r.status_code >= 300:
            raise StoreError(f"GitHub {what} Error {r.status_code}")
