"""process_monitor.py - बैकग्राउंड Thread: बंद हुए Bots को पकड़ना, Auto Restart, Disk/Backup जाँच."""
from __future__ import annotations

import logging
import threading
import time

log = logging.getLogger("om.monitor")


class ProcessMonitor(threading.Thread):
    def __init__(self, cfg, db, runner, manager, backups=None):
        super().__init__(daemon=True, name="process-monitor")
        self.cfg, self.db, self.runner, self.manager, self.backups = cfg, db, runner, manager, backups
        self._stop_evt = threading.Event()
        self._inflight: set[int] = set()
        self._last_disk = 0.0
        self._last_backup = time.time()
        self._lock = threading.Lock()
        self._seen_write: dict[int, float] = {}

    def stop(self):
        self._stop_evt.set()

    def run(self):
        while not self._stop_evt.is_set():
            try:
                self.tick()
            except Exception:
                log.exception("monitor tick failed")
            self._stop_evt.wait(self.cfg.monitor_interval_sec)

    def tick(self, now=None):
        now = now or time.time()
        for bot in self.db.list_bots():
            if bot["status"] != "running" or bot["desired_state"] != "running":
                continue
            bid = bot["id"]
            st = self.db.get_status(bid)
            if now - (st.get("last_started_ts") or 0) < self.cfg.startup_observe_sec + 5:
                continue  # Start की प्रक्रिया खुद देख रही है
            if bid in self.manager._busy:
                continue
            if self.runner.is_running(bid):
                if now - self._seen_write.get(bid, 0) > 600:  # DB को बार-बार न बदलें (Snapshot हर बार 'बदला हुआ' न दिखे)
                    self._seen_write[bid] = now
                    self.db.update_status(bid, last_seen_running=time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
                continue
            with self._lock:
                if bid in self._inflight:
                    continue
                self._inflight.add(bid)
            threading.Thread(target=self._handle, args=(bid,), daemon=True).start()
        try:
            self.manager.enforce_memory_limits()
        except Exception:
            log.exception("memory enforcement failed")
        if now - self._last_disk > 300:
            self._last_disk = now
            self.manager.enforce_disk_limits()
        if self.backups and self.cfg.auto_backup_hours > 0 and now - self._last_backup > self.cfg.auto_backup_hours * 3600:
            self._last_backup = now
            try:
                self.backups.backup_db(note="auto")
            except Exception:
                log.exception("auto backup failed")

    def _handle(self, bid):
        try:
            self.manager.handle_crash(bid)
        except Exception:
            log.exception("handle_crash failed for %s", bid)
        finally:
            with self._lock:
                self._inflight.discard(bid)
