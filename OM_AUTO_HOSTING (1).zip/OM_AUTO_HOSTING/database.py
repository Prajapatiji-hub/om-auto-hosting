"""database.py - SQLite Database (Restart के बाद भी सब बना रहता है).

हर query में owner_id का इस्तेमाल होता है ताकि एक User का Data दूसरे को न दिखे.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

from utils import iso_now

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, role TEXT DEFAULT 'friend',
    is_blocked INTEGER DEFAULT 0, first_seen TEXT, last_seen TEXT, state TEXT DEFAULT '', state_data TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS allowed_friends (
    user_id INTEGER PRIMARY KEY, added_by INTEGER, added_at TEXT, note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS hosted_bots (
    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, name TEXT NOT NULL,
    runtime TEXT, entry_file TEXT, framework TEXT DEFAULT '', project_dir TEXT NOT NULL,
    status TEXT DEFAULT 'draft', desired_state TEXT DEFAULT 'stopped', auto_restart INTEGER DEFAULT 1,
    analysis_json TEXT DEFAULT '{}', created_at TEXT, updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_bots_owner ON hosted_bots(owner_id);
CREATE TABLE IF NOT EXISTS uploaded_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, bot_id INTEGER, original_name TEXT,
    stored_path TEXT, size INTEGER, sha256 TEXT, file_type TEXT, uploaded_at TEXT
);
CREATE TABLE IF NOT EXISTS bot_tokens (
    bot_id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, token_enc TEXT NOT NULL,
    tg_bot_id INTEGER, bot_username TEXT, validated INTEGER DEFAULT 0, set_at TEXT
);
CREATE TABLE IF NOT EXISTS api_configurations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, bot_id INTEGER DEFAULT 0,
    key_name TEXT NOT NULL, value_enc TEXT NOT NULL, set_at TEXT, UNIQUE(owner_id, bot_id, key_name)
);
CREATE TABLE IF NOT EXISTS bot_status (
    bot_id INTEGER PRIMARY KEY, state TEXT DEFAULT 'stopped', container_name TEXT, pid INTEGER,
    started_at TEXT, last_exit_code INTEGER, last_error TEXT DEFAULT '', restart_count INTEGER DEFAULT 0,
    last_started_ts REAL DEFAULT 0, logs_since REAL DEFAULT 0, restart_times TEXT DEFAULT '[]',
    last_seen_running TEXT
);
CREATE TABLE IF NOT EXISTS bot_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, bot_id INTEGER, ts TEXT, level TEXT, message TEXT
);
CREATE INDEX IF NOT EXISTS idx_logs_bot ON bot_logs(bot_id);
CREATE TABLE IF NOT EXISTS bot_dependencies (
    id INTEGER PRIMARY KEY AUTOINCREMENT, bot_id INTEGER NOT NULL, ecosystem TEXT, name TEXT, spec TEXT DEFAULT '',
    source TEXT, status TEXT, detail TEXT DEFAULT '', UNIQUE(bot_id, ecosystem, name)
);
CREATE TABLE IF NOT EXISTS backups (
    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER DEFAULT 0, kind TEXT, path TEXT, size INTEGER,
    created_at TEXT, note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS system_settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS firebase_urls (
    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, url TEXT NOT NULL, label TEXT DEFAULT '',
    authorized_at TEXT, last_checked TEXT, last_result_json TEXT DEFAULT '', UNIQUE(owner_id, url)
);
"""


class Database:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self.conn() as c:
            c.executescript(SCHEMA)
            c.execute("PRAGMA journal_mode=WAL")
        try:
            import os
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    @contextmanager
    def conn(self):
        with self._lock:
            c = sqlite3.connect(self.path, timeout=30)
            c.row_factory = sqlite3.Row
            try:
                yield c
                c.commit()
            except Exception:
                c.rollback()
                raise
            finally:
                c.close()

    def q(self, sql, params=()):
        with self.conn() as c:
            return [dict(r) for r in c.execute(sql, params).fetchall()]

    def q1(self, sql, params=()):
        rows = self.q(sql, params)
        return rows[0] if rows else None

    def x(self, sql, params=()):
        with self.conn() as c:
            cur = c.execute(sql, params)
            return cur.lastrowid

    # ------------------------------------------------------------ users
    def upsert_user(self, uid, username="", first_name="", role=None):
        now = iso_now()
        row = self.q1("SELECT * FROM users WHERE user_id=?", (uid,))
        if row is None:
            self.x("INSERT INTO users(user_id,username,first_name,role,first_seen,last_seen) VALUES(?,?,?,?,?,?)",
                   (uid, username or "", first_name or "", role or "friend", now, now))
        else:
            if role:
                self.x("UPDATE users SET role=? WHERE user_id=?", (role, uid))
            self.x("UPDATE users SET username=?, first_name=?, last_seen=? WHERE user_id=?",
                   (username or row["username"], first_name or row["first_name"], now, uid))

    def get_user(self, uid):
        return self.q1("SELECT * FROM users WHERE user_id=?", (uid,))

    def list_users(self):
        return self.q("SELECT * FROM users ORDER BY first_seen")

    def set_blocked(self, uid, blocked: bool):
        self.upsert_user(uid)
        self.x("UPDATE users SET is_blocked=? WHERE user_id=?", (1 if blocked else 0, uid))

    def is_blocked(self, uid) -> bool:
        r = self.get_user(uid)
        return bool(r and r["is_blocked"])

    def set_state(self, uid, state="", data=None):
        self.upsert_user(uid)
        self.x("UPDATE users SET state=?, state_data=? WHERE user_id=?", (state, json.dumps(data or {}), uid))

    def get_state(self, uid):
        r = self.get_user(uid)
        if not r:
            return "", {}
        try:
            return r["state"] or "", json.loads(r["state_data"] or "{}")
        except ValueError:
            return r["state"] or "", {}

    # ---------------------------------------------------------- friends
    def add_friend(self, uid, added_by, note=""):
        self.x("INSERT OR REPLACE INTO allowed_friends(user_id,added_by,added_at,note) VALUES(?,?,?,?)",
               (uid, added_by, iso_now(), note))
        self.upsert_user(uid, role="friend")

    def remove_friend(self, uid) -> bool:
        n = self.q1("SELECT COUNT(*) n FROM allowed_friends WHERE user_id=?", (uid,))["n"]
        self.x("DELETE FROM allowed_friends WHERE user_id=?", (uid,))
        return bool(n)

    def is_friend(self, uid) -> bool:
        return self.q1("SELECT 1 x FROM allowed_friends WHERE user_id=?", (uid,)) is not None

    def list_friends(self):
        return self.q("SELECT * FROM allowed_friends ORDER BY added_at")

    # ------------------------------------------------------------- bots
    def create_bot(self, owner_id, name, project_dir, runtime=None, entry=None, framework=""):
        now = iso_now()
        bid = self.x("INSERT INTO hosted_bots(owner_id,name,runtime,entry_file,framework,project_dir,status,created_at,updated_at)"
                     " VALUES(?,?,?,?,?,?,?,?,?)", (owner_id, name, runtime, entry, framework, str(project_dir), "analyzing", now, now))
        self.x("INSERT OR IGNORE INTO bot_status(bot_id) VALUES(?)", (bid,))
        return bid

    def get_bot(self, bot_id, owner_id=None):
        """owner_id देने पर सिर्फ़ उसी Owner का Bot मिलता है (User Separation)."""
        if owner_id is None:
            return self.q1("SELECT * FROM hosted_bots WHERE id=?", (bot_id,))
        return self.q1("SELECT * FROM hosted_bots WHERE id=? AND owner_id=?", (bot_id, owner_id))

    def list_bots(self, owner_id=None):
        if owner_id is None:
            return self.q("SELECT * FROM hosted_bots ORDER BY id")
        return self.q("SELECT * FROM hosted_bots WHERE owner_id=? ORDER BY id", (owner_id,))

    def update_bot(self, bot_id, **fields):
        if not fields:
            return
        fields["updated_at"] = iso_now()
        cols = ", ".join(f"{k}=?" for k in fields)
        self.x(f"UPDATE hosted_bots SET {cols} WHERE id=?", (*fields.values(), bot_id))

    def delete_bot(self, bot_id):
        for t in ("bot_tokens", "bot_status", "bot_logs", "bot_dependencies", "uploaded_files"):
            col = "bot_id"
            self.x(f"DELETE FROM {t} WHERE {col}=?", (bot_id,))
        self.x("DELETE FROM api_configurations WHERE bot_id=?", (bot_id,))
        self.x("DELETE FROM hosted_bots WHERE id=?", (bot_id,))

    # ----------------------------------------------------------- status
    def get_status(self, bot_id):
        self.x("INSERT OR IGNORE INTO bot_status(bot_id) VALUES(?)", (bot_id,))
        return self.q1("SELECT * FROM bot_status WHERE bot_id=?", (bot_id,))

    def update_status(self, bot_id, **fields):
        self.x("INSERT OR IGNORE INTO bot_status(bot_id) VALUES(?)", (bot_id,))
        if fields:
            cols = ", ".join(f"{k}=?" for k in fields)
            self.x(f"UPDATE bot_status SET {cols} WHERE bot_id=?", (*fields.values(), bot_id))

    # ------------------------------------------------------------ files
    def add_upload(self, owner_id, bot_id, name, path, size, sha, ftype):
        return self.x("INSERT INTO uploaded_files(owner_id,bot_id,original_name,stored_path,size,sha256,file_type,uploaded_at)"
                      " VALUES(?,?,?,?,?,?,?,?)", (owner_id, bot_id, name, str(path), size, sha, ftype, iso_now()))

    def list_uploads(self, owner_id):
        return self.q("SELECT * FROM uploaded_files WHERE owner_id=? ORDER BY id DESC", (owner_id,))

    # ------------------------------------------------------------- logs
    def add_log(self, bot_id, level, message):
        self.x("INSERT INTO bot_logs(bot_id,ts,level,message) VALUES(?,?,?,?)", (bot_id, iso_now(), level, message[:2000]))

    def get_logs(self, bot_id, limit=30):
        return list(reversed(self.q("SELECT * FROM bot_logs WHERE bot_id=? ORDER BY id DESC LIMIT ?", (bot_id, limit))))

    def clear_logs(self, bot_id):
        self.x("DELETE FROM bot_logs WHERE bot_id=?", (bot_id,))

    # ----------------------------------------------------- dependencies
    def set_dep(self, bot_id, eco, name, spec="", source="", status="detected", detail=""):
        self.x("INSERT INTO bot_dependencies(bot_id,ecosystem,name,spec,source,status,detail) VALUES(?,?,?,?,?,?,?)"
               " ON CONFLICT(bot_id,ecosystem,name) DO UPDATE SET spec=excluded.spec, source=excluded.source,"
               " status=excluded.status, detail=excluded.detail", (bot_id, eco, name, spec, source, status, detail[:500]))

    def list_deps(self, bot_id):
        return self.q("SELECT * FROM bot_dependencies WHERE bot_id=? ORDER BY ecosystem, name", (bot_id,))

    # --------------------------------------------------------- settings
    def get_setting(self, key, default=None):
        r = self.q1("SELECT value FROM system_settings WHERE key=?", (key,))
        return r["value"] if r else default

    def set_setting(self, key, value):
        self.x("INSERT INTO system_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (key, str(value)))

    # --------------------------------------------------------- firebase
    def add_firebase_url(self, owner_id, url, label=""):
        self.x("INSERT INTO firebase_urls(owner_id,url,label,authorized_at) VALUES(?,?,?,?)"
               " ON CONFLICT(owner_id,url) DO UPDATE SET authorized_at=excluded.authorized_at", (owner_id, url, label, iso_now()))

    def list_firebase_urls(self, owner_id):
        return self.q("SELECT * FROM firebase_urls WHERE owner_id=? ORDER BY id", (owner_id,))

    def get_firebase_url(self, owner_id, url):
        return self.q1("SELECT * FROM firebase_urls WHERE owner_id=? AND url=?", (owner_id, url))

    def save_firebase_result(self, owner_id, url, result: dict):
        self.x("UPDATE firebase_urls SET last_checked=?, last_result_json=? WHERE owner_id=? AND url=?",
               (iso_now(), json.dumps(result, ensure_ascii=False), owner_id, url))

    def remove_firebase_url(self, owner_id, fid):
        self.x("DELETE FROM firebase_urls WHERE owner_id=? AND id=?", (owner_id, fid))

    # -------------------------------------------------------------- misc
    def counts(self) -> dict:
        def n(sql):
            return self.q1(sql)["n"]
        return {
            "users": n("SELECT COUNT(*) n FROM users"),
            "friends": n("SELECT COUNT(*) n FROM allowed_friends"),
            "blocked": n("SELECT COUNT(*) n FROM users WHERE is_blocked=1"),
            "files": n("SELECT COUNT(*) n FROM uploaded_files"),
            "bots": n("SELECT COUNT(*) n FROM hosted_bots"),
            "running": n("SELECT COUNT(*) n FROM hosted_bots WHERE status='running'"),
            "stopped": n("SELECT COUNT(*) n FROM hosted_bots WHERE status IN ('stopped','finished')"),
            "failed": n("SELECT COUNT(*) n FROM hosted_bots WHERE status IN ('failed','blocked')"),
        }

    def active_users(self, hours=24):
        return self.q1("SELECT COUNT(*) n FROM users WHERE last_seen >= datetime('now', ?)", (f"-{int(hours)} hours",))["n"]

    def backup_to(self, dest_path):
        """SQLite का सुरक्षित backup (चलते हुए DB पर भी ठीक)."""
        dest = sqlite3.connect(str(dest_path))
        try:
            with self.conn() as c:
                c.backup(dest)
        finally:
            dest.close()
