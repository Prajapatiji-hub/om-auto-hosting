#!/usr/bin/env bash
# Sandbox network (om-br0) के Containers को Host और Cloud-metadata/निजी networks तक पहुँचने से रोकता है.
# systemd (om-firewall.service) Docker के बाद इसे हर Boot पर चलाता है. असली VM पर टेस्ट ज़रूरी है.
set -euo pipefail
BR=om-br0
ipt() { iptables "$@"; }

# Docker का DOCKER-USER chain मौजूद होना चाहिए
ipt -N DOCKER-USER 2>/dev/null || true
ipt -N OM-SANDBOX 2>/dev/null || true
ipt -F OM-SANDBOX
ipt -A OM-SANDBOX -d 169.254.0.0/16 -j DROP     # Cloud metadata (credentials चोरी रोकना)
ipt -A OM-SANDBOX -d 10.0.0.0/8 -j DROP         # निजी (VCN) networks
ipt -A OM-SANDBOX -d 172.16.0.0/12 -j DROP
ipt -A OM-SANDBOX -d 192.168.0.0/16 -j DROP
ipt -A OM-SANDBOX -j RETURN
ipt -D DOCKER-USER -i "$BR" -j OM-SANDBOX 2>/dev/null || true
ipt -I DOCKER-USER -i "$BR" -j OM-SANDBOX

# Containers खुद Host (SSH, Manager आदि) से नया connection न खोल सकें
ipt -C INPUT -i "$BR" -m conntrack --ctstate NEW -j DROP 2>/dev/null || ipt -I INPUT -i "$BR" -m conntrack --ctstate NEW -j DROP
echo "OM firewall rules लग गए ($BR)."
