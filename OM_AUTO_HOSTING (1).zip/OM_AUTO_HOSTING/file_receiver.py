"""file_receiver.py - Telegram से आई फाइल लेना, जाँचना, सहेजना और Pipeline शुरू करना."""
from __future__ import annotations

import logging
import os
import time
import zipfile
from pathlib import Path

import firebase_ui
import keyboards as K
import project_detector
import security_manager as sec
from access_control import require_allowed
from utils import esc, human_size

log = logging.getLogger("om.files")

SUPPORT_TEXT = ("📤 <b>फाइल भेजें</b> (Document के रूप में)\n"
                "✅ Host हो सकती हैं: <code>.py</code>, <code>.js</code>, <code>.zip</code> (पूरा Project)\n"
                "📎 Bot से जोड़ी जा सकती हैं: <code>requirements.txt</code>, <code>package.json</code>, <code>.env.example</code>, <code>.json</code>, <code>.txt</code>\n"
                "ℹ️ HTML/CSS/PHP/Java/C++/APK आदि की सिर्फ़ पहचान होती है; उन्हें चलाना इस System में समर्थित नहीं.\n"
                "📏 अधिकतम साइज़: {mb} MB (Telegram Bot की सीमा 20 MB)")


def save_upload(ctx, uid: int, data: bytes, filename: str) -> str:
    udir = sec.safe_join(ctx.cfg.users_dir, str(uid), "uploads")
    udir.mkdir(parents=True, exist_ok=True)
    os.chmod(udir.parent, 0o700)
    safe = sec.safe_filename(filename)
    path = udir / f"{int(time.time())}_{safe}"
    path.write_bytes(data)
    os.chmod(path, 0o600)
    return str(path)


def download_document(ctx, doc) -> bytes:
    info = ctx.tg.get_file(doc.file_id)
    return ctx.tg.download_file(info.file_path)


def handle_document(ctx, m):
    uid = m.from_user.id
    doc = m.document
    name = doc.file_name or "file"
    ftype = project_detector.detect_file_type(name, doc.file_size or 0)
    state, sdata = ctx.db.get_state(uid)
    max_bytes = min(ctx.cfg.max_upload_mb, 20) * 1048576
    if (doc.file_size or 0) > max_bytes:
        ctx.send(uid, f"❌ फाइल बहुत बड़ी है ({human_size(doc.file_size)}). सीमा {min(ctx.cfg.max_upload_mb, 20)} MB है.")
        return
    if ftype["kind"] == "dotenv":
        try:
            ctx.tg.delete_message(m.chat.id, m.message_id)
        except Exception:
            pass
        ctx.send(uid, "🔒 '.env' फाइल सीधे न भेजें (उसमें Secrets होते हैं). Token/Keys के लिए Menu → API / Token Settings इस्तेमाल करें. "
                      "आपकी भेजी फाइल मैंने मिटा दी और सहेजी नहीं.")
        return

    # Firebase TXT import
    if state == "await_fb_txt":
        if ftype["kind"] != "text":
            ctx.send(uid, "कृपया URLs वाली .txt फाइल भेजें (हर लाइन में एक URL).")
            return
        try:
            data = download_document(ctx, doc)
        except Exception as e:
            ctx.send(uid, "❌ फाइल डाउनलोड नहीं हुई: " + esc(str(e)[:100]))
            return
        firebase_ui.handle_txt(ctx, uid, data.decode("utf-8", "ignore"))
        return

    try:
        data = download_document(ctx, doc)
    except Exception as e:
        log.warning("download failed: %s", sec.redact(str(e)))
        ctx.send(uid, "❌ फाइल डाउनलोड नहीं हो सकी. दोबारा भेजें.")
        return
    if len(data) > max_bytes:
        ctx.send(uid, "❌ फाइल बहुत बड़ी है.")
        return
    stored = save_upload(ctx, uid, data, name)

    # सिर्फ़ विश्लेषण मोड
    if state == "await_analyze":
        ctx.db.set_state(uid, "", {})
        if ftype["kind"] == "zip" and not zipfile.is_zipfile(stored):
            ctx.send(uid, "❌ यह सही ZIP नहीं है.")
            return
        ctx.send(uid, "🔎 सिर्फ़ विश्लेषण कर रहा हूँ (Host नहीं करूँगा)…")
        ctx.manager.run_bg(lambda: ctx.send(uid, ctx.manager.analyze_only(uid, stored, name)))
        return

    if ftype["kind"] in ("python", "javascript", "zip"):
        if ftype["kind"] == "zip" and not zipfile.is_zipfile(stored):
            ctx.send(uid, "❌ यह सही ZIP फाइल नहीं है.")
            return
        ctx.db.set_state(uid, "", {})
        ctx.manager.run_bg(ctx.manager.create_from_file, uid, stored, name)
        return

    if ftype["kind"] in ("requirements", "package_json", "env_example", "json", "text", "data"):
        bots = ctx.db.list_bots(uid)
        if not bots:
            ctx.send(uid, f"📎 {esc(ftype['label'])} मिली, पर आपका कोई Bot नहीं है. पहले .py/.js/.zip भेजें.")
            return
        ctx.db.set_state(uid, "await_attach", {"path": stored, "name": name})
        ctx.send(uid, f"📎 <b>{esc(name)}</b> ({esc(ftype['label'])}) किस Bot में जोड़ूँ?",
                 [[(f"{b['name']} (#{b['id']})", f"att:{b['id']}")] for b in bots] + [[("❌ रहने दो", "noop")]])
        return

    if ftype["kind"] == "other_language":
        ctx.send(uid, f"ℹ️ <b>{esc(name)}</b> — पहचान: {esc(ftype['label'])}.\n"
                      "इस System में सिर्फ़ Python और Node.js Bots चलाने के Runtime हैं, इसलिए इसे Host नहीं किया जा सकता. फाइल सहेजी नहीं गई.")
        try:
            os.remove(stored)
        except OSError:
            pass
        return
    ctx.send(uid, f"ℹ️ {esc(name)} — यह प्रकार पहचाना नहीं गया ({esc(ftype['label'])}). Host नहीं हो सकता.")
    try:
        os.remove(stored)
    except OSError:
        pass


def register(ctx):
    tg = ctx.tg

    @tg.message_handler(content_types=["document"])
    @require_allowed(ctx)
    def _doc(m):
        try:
            handle_document(ctx, m)
        except Exception:
            log.exception("document handler failed")
            ctx.send(m.from_user.id, "❌ फाइल संभालते समय अंदरूनी समस्या हुई. दोबारा कोशिश करें.")
