# Render Free Mode — पूरी गाइड (बिना Card, बिना Termux)

## यह कैसे चलता है
```
Telegram ⇄ Render (Free Web Service, ek hi) ── Hosting Bot + आपके Bots (अलग-अलग Process)
                         ▲ UptimeRobot हर 5 मिनट ping (सोने से बचाता है)
                         └ GitHub private repo "om-hosting-data" में Encrypted Snapshot
```
Render पर Files हर Restart में मिट जाती हैं, इसलिए Bots/Tokens का Encrypted Snapshot GitHub में सुरक्षित होता है और Restart पर वापस आ जाता है
(Libraries दोबारा Install होती हैं, 1–3 मिनट).

## सीमाएँ (ईमानदारी से)
- 512 MB RAM → 2–3 छोटे Bots. हर Bot की RAM-सीमा (डिफ़ॉल्ट 128 MB) Monitor लागू करता है.
- Docker नहीं → Isolation: हर Bot का अलग uid + 700 folder (Root पर), साफ़ Environment, ulimit. Network पर रोक नहीं. सिर्फ़ भरोसेमंद दोस्त.
- 24/7 की गारंटी नहीं: Render/UptimeRobot/GitHub की शर्तें बदल सकती हैं. 750 घंटे/महीना = सिर्फ़ एक Service.
- Snapshot हर ~10 मिनट (या बदलाव के ~20 सेकंड बाद). बीच में Render अचानक मरे तो आख़िरी कुछ मिनट का बदलाव खो सकता है.

## Environment Variables (Render Dashboard → Environment)
| नाम | क्या |
|---|---|
| BOT_TOKEN | Hosting Bot का Token (@BotFather) |
| OWNER_ID | आपका Telegram ID |
| FRIEND_IDS | दोस्तों के ID, comma से |
| GITHUB_DATA_TOKEN | om-hosting-data का Fine-grained token (Contents: Read and write) |
| DATA_REPO | `username/om-hosting-data` |
| SECRET_KEY | कोई भी लंबा गुप्त शब्द (Render खुद बना सकता है). **इसे अलग सुरक्षित जगह रखें** |
| BOT_MEM_LIMIT_MB / MAX_RUNNING_TOTAL / MAX_BOTS_PER_USER | 128 / 3 / 3 |

## दो तरीके Code पहुँचाने के
**तरीका A (फोन से आसान): ZIP वाला repo.** `om-auto-hosting` repo में सिर्फ़ दो फाइलें: `Dockerfile` (render_repo/Dockerfile) और `OM_AUTO_HOSTING.zip`.
GitHub → repo → Add file → Upload files → ZIP चुनें → Commit. (Dockerfile Claude डाल देगा.)
**तरीका B:** पूरा code repo में (render.yaml + Dockerfile.render), Render में Blueprint.

## बाद के Steps
1. Render → New Web Service → repo चुनें → Language: Docker → Instance Type: **Free**.
2. ऊपर वाले Variables भरें → Create. Build 5–10 मिनट.
3. Service का URL (…onrender.com) कॉपी करें, `…/health` खोलकर "ok" दिखे.
4. UptimeRobot में HTTP monitor: URL = `…/health`, हर 5 मिनट.
5. Telegram में Hosting Bot पर `/start`.
