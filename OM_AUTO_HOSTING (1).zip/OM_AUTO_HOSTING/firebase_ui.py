"""firebase_ui.py - Hosting Bot के अंदर Firebase Checker का Telegram Interface."""
from __future__ import annotations

import io
import logging

import firebase_checker as fb
import keyboards as K
from security_manager import redact
from utils import esc

log = logging.getLogger("om.firebase")

AUTH_NAME = "FIREBASE_AUTH"
DISCLAIMER = ("⚖️ <b>अनुमति की पुष्टि</b>\nमैं सिर्फ़ उन्हीं Firebase Databases को जाँचूँगा जिनकी जाँच करने का अधिकार आपके पास है "
              "(आपका अपना Project या जिसकी लिखित अनुमति हो). Security Rules/Authentication को Bypass नहीं किया जाता.")


def menu(ctx, uid):
    urls = ctx.db.list_firebase_urls(uid)
    has_auth = ctx.tokens.get_api_value(uid, 0, AUTH_NAME) is not None
    ctx.send(uid, "🔥 <b>Firebase Checker</b>\n"
                  f"मेरे अधिकृत URLs: {len(urls)} | Auth token: {'सेट ✅' if has_auth else 'सेट नहीं'}\n"
                  "सिर्फ़ आपके दिए (और पुष्टि किए) URLs जाँचे जाते हैं.", K.firebase_menu_buttons())


def _auth_for(ctx, uid):
    return ctx.tokens.get_api_value(uid, 0, AUTH_NAME)


def _run(ctx, uid, urls):
    auth = _auth_for(ctx, uid)
    results = fb.check_many(urls, auth_for=lambda u: auth)
    for r in results:
        if ctx.db.get_firebase_url(uid, r["url"]):
            ctx.db.save_firebase_result(uid, r["url"], r)
    ctx.fb_last[uid] = results
    for r in results[:10]:
        ctx.send(uid, fb.result_html(r))
    if len(results) > 10:
        ctx.send(uid, f"… और {len(results) - 10} URLs के नतीजे Export में हैं.")
    ctx.send(uid, f"✅ {len(results)} URL की जाँच पूरी. Report Export करें:", K.export_buttons())


def start_check(ctx, uid, urls: list[str]):
    """URLs को पुष्टि के बाद जाँचना. नए URL हों तो पहले अनुमति पूछो."""
    good, bad, new = [], [], []
    for u in urls[:fb.MAX_URLS]:
        ok, val = fb.normalize_url(u)
        if not ok:
            bad.append((u, val))
            continue
        good.append(val)
        if not ctx.db.get_firebase_url(uid, val):
            new.append(val)
    if bad:
        ctx.send(uid, "⚠️ ये URL मान्य नहीं:\n" + "\n".join(f"• {esc(redact(u)[:80])} — {esc(why)}" for u, why in bad[:8]))
    if not good:
        return
    if new:
        ctx.db.set_state(uid, "fb_confirm", {"urls": good})
        shown = "\n".join(f"• <code>{esc(u)}</code>" for u in new[:10]) + (f"\n… और {len(new) - 10}" if len(new) > 10 else "")
        ctx.send(uid, DISCLAIMER + "\n\nनए URLs:\n" + shown, [[("✅ हाँ, मैं अधिकृत हूँ", "fb:ok"), ("❌ रद्द", "noop")]])
        return
    ctx.manager.run_bg(lambda: _run(ctx, uid, good))
    ctx.send(uid, f"🔍 {len(good)} URL जाँच रहा हूँ…")


def handle_txt(ctx, uid, text: str):
    ctx.db.set_state(uid, "", {})
    urls = fb.parse_url_list(text)
    if not urls:
        ctx.send(uid, "फाइल में कोई URL नहीं मिला.")
        return
    if len(urls) > fb.MAX_URLS:
        ctx.send(uid, f"⚠️ अधिकतम {fb.MAX_URLS} URLs एक बार में; पहले {fb.MAX_URLS} लिए जाएँगे.")
    start_check(ctx, uid, urls)


def handle_text_state(ctx, m, state, sdata) -> bool:
    uid = m.from_user.id
    if state in ("await_fb_url", "fb_confirm"):
        ctx.db.set_state(uid, "", {})
        start_check(ctx, uid, [m.text.strip()])
        return True
    if state == "await_fb_auth":
        ctx.db.set_state(uid, "", {})
        try:
            ctx.tg.delete_message(m.chat.id, m.message_id)
        except Exception:
            pass
        val = m.text.strip()
        if val.lower() in ("hatao", "remove", "delete"):
            ctx.tokens.delete_api_value(uid, 0, AUTH_NAME)
            ctx.send(uid, "🗑 Firebase Auth token हटा दिया.")
        elif len(val) < 8 or len(val) > 4000 or any(c.isspace() for c in val):
            ctx.send(uid, "❌ यह Token जैसा नहीं लगा. (हटाने के लिए 'remove' लिखें)")
        else:
            ctx.tokens.save_api_value(uid, 0, AUTH_NAME, val)
            ctx.send(uid, "🔐 Auth token Encrypted रखा गया और आपका संदेश मिटा दिया. यह सिर्फ़ आपकी जाँचों में लगेगा.")
        return True
    return False


def on_callback(ctx, call) -> bool:
    data = call.data
    if not data.startswith("fb:"):
        return False
    uid = call.from_user.id
    parts = data.split(":")
    act = parts[1]
    if act == "single":
        ctx.db.set_state(uid, "await_fb_url", {})
        ctx.send(uid, "🔥 जाँचने के लिए Firebase Realtime Database URL भेजें\n(जैसे <code>https://myapp-default-rtdb.firebaseio.com</code>)")
    elif act == "all":
        urls = [r["url"] for r in ctx.db.list_firebase_urls(uid)]
        if not urls:
            ctx.send(uid, "अभी कोई अधिकृत URL सेव नहीं है. 'Single URL' या 'TXT Import' से जोड़ें.")
        else:
            ctx.send(uid, f"🔍 {len(urls)} URL जाँच रहा हूँ…")
            ctx.manager.run_bg(lambda: _run(ctx, uid, urls))
    elif act == "import":
        ctx.db.set_state(uid, "await_fb_txt", {})
        ctx.send(uid, "📄 .txt फाइल भेजें, हर लाइन में एक Firebase URL (# से शुरू लाइन छोड़ दी जाती है).")
    elif act == "auth":
        ctx.db.set_state(uid, "await_fb_auth", {})
        ctx.send(uid, "🔐 अगर आपका Database Private है और आपके पास वैध Auth token/secret है तो अभी भेजें (संदेश मिटा दिया जाएगा). हटाने के लिए 'remove' लिखें.")
    elif act == "ok":
        state, sd = ctx.db.get_state(uid)
        if state != "fb_confirm":
            ctx.send(uid, "यह अनुरोध पुराना हो गया, URL दोबारा भेजें.")
            return True
        ctx.db.set_state(uid, "", {})
        for u in sd.get("urls", []):
            ctx.db.add_firebase_url(uid, u)
        ctx.send(uid, f"🔍 {len(sd.get('urls', []))} URL जाँच रहा हूँ…")
        ctx.manager.run_bg(lambda: _run(ctx, uid, sd.get("urls", [])))
    elif act == "remove":
        rows = ctx.db.list_firebase_urls(uid)
        if not rows:
            ctx.send(uid, "कोई URL सेव नहीं है.")
        else:
            ctx.send(uid, "कौन सा URL हटाएँ?", [[(r["url"][8:50], f"fb:rm:{r['id']}")] for r in rows[:20]])
    elif act == "rm":
        ctx.db.remove_firebase_url(uid, int(parts[2]))
        ctx.send(uid, "🗑 हटा दिया.")
    elif act == "exp":
        res = ctx.fb_last.get(uid)
        if not res:
            ctx.send(uid, "पहले कोई जाँच चलाएँ, फिर Export करें.")
            return True
        kind = parts[2]
        fn = {"json": fb.export_json, "txt": fb.export_txt, "csv": fb.export_csv}.get(kind)
        if fn is None:
            return True
        bio = io.BytesIO(fn(res))
        bio.name = f"firebase_report.{kind}"
        ctx.tg.send_document(uid, bio, caption=f"Firebase Report ({kind.upper()})")
    return True
