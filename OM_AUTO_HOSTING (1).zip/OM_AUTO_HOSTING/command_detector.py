"""command_detector.py - अपलोड की गई Bot Script में असली Commands पहचानना.

सिर्फ़ वही Commands दिखाए जाते हैं जो Code में सच में मिलें. कोई काल्पनिक Command नहीं जोड़ा जाता.
"""
from __future__ import annotations

import ast
import re

CMD_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,31}$")
MENU_NAME = re.compile(r"^[a-z][a-z0-9_]{0,31}$")  # Telegram Menu में सिर्फ़ छोटे अक्षर चलते हैं

_STD_DESC = {
    "start": "Bot शुरू करें",
    "help": "मदद",
    "settings": "Settings",
    "status": "Status",
    "stats": "Statistics",
    "admin": "Admin",
    "export": "Export",
    "menu": "Menu",
    "about": "About",
}


def _consts(node):
    """Constant str या list/tuple of str से नाम निकालो."""
    out = []
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        out.append(node.value)
    elif isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        for e in node.elts:
            if isinstance(e, ast.Constant) and isinstance(e.value, str):
                out.append(e.value)
    return out


def _clean(name: str) -> str | None:
    name = name.strip().lstrip("/")
    name = name.split("@")[0].split()[0] if name else ""
    return name if CMD_NAME.match(name) else None


def _func_name(call: ast.Call) -> str:
    f = call.func
    if isinstance(f, ast.Name):
        return f.id
    if isinstance(f, ast.Attribute):
        return f.attr
    return ""


def detect_python_commands(tree: ast.AST, rel_file: str) -> list[dict]:
    found: list[dict] = []

    def add(name, source, node):
        n = _clean(name or "")
        if n:
            found.append({"name": n, "source": source, "file": rel_file, "line": getattr(node, "lineno", 0)})

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            fn = _func_name(node)
            # telebot / aiogram v2 : commands=[...]
            for kw in node.keywords:
                if kw.arg == "commands":
                    for c in _consts(kw.value):
                        add(c, "commands=", node)
            # python-telegram-bot
            if fn == "CommandHandler" and node.args:
                for c in _consts(node.args[0]):
                    add(c, "CommandHandler", node)
            for kw in node.keywords:
                if fn == "CommandHandler" and kw.arg == "command":
                    for c in _consts(kw.value):
                        add(c, "CommandHandler", node)
            # aiogram v3 : Command("x", "y"), CommandStart()
            if fn == "Command":
                for a in node.args:
                    for c in _consts(a):
                        add(c, "aiogram Command", node)
            if fn == "CommandStart":
                add("start", "aiogram CommandStart", node)
            # pyrogram : filters.command("x") / filters.command(["a","b"])
            if isinstance(node.func, ast.Attribute) and node.func.attr == "command" and node.args:
                base = node.func.value
                if isinstance(base, ast.Name) and base.id in ("filters", "Filters", "f"):
                    for c in _consts(node.args[0]):
                        add(c, "pyrogram filters.command", node)
            # telethon : events.NewMessage(pattern=...)
            if fn == "NewMessage":
                for kw in node.keywords:
                    if kw.arg == "pattern":
                        for pat in _consts(kw.value):
                            for m in re.findall(r"/([A-Za-z][A-Za-z0-9_]{0,31})", pat.replace("\\/", "/")):
                                add(m, "telethon pattern", node)
        elif isinstance(node, ast.Compare):
            # message.text == '/start'
            for c in [node.left] + list(node.comparators):
                if isinstance(c, ast.Constant) and isinstance(c.value, str) and re.match(r"^/[A-Za-z][A-Za-z0-9_]{0,31}$", c.value):
                    add(c.value, "text तुलना", node)
    return found


def detect_js_commands(text: str, rel_file: str) -> list[dict]:
    found: list[dict] = []

    def add(name, source, pos):
        n = _clean(name)
        if n:
            found.append({"name": n, "source": source, "file": rel_file, "line": text.count("\n", 0, pos) + 1})

    for m in re.finditer(r"onText\(\s*/\^?\\?/([A-Za-z][A-Za-z0-9_]*)", text):
        add(m.group(1), "node-telegram-bot-api onText", m.start())
    for m in re.finditer(r"\.command\(\s*(\[[^\]]*\]|['\"][^'\"]+['\"])", text):
        for name in re.findall(r"['\"]([A-Za-z][A-Za-z0-9_]*)['\"]", m.group(1)):
            add(name, "command()", m.start())
    for m in re.finditer(r"\b(?:bot|composer)\.(start|help|settings)\s*\(", text):
        add(m.group(1), f"bot.{m.group(1)}()", m.start())
    return found


def merge_commands(items: list[dict]) -> list[dict]:
    seen, out = set(), []
    for it in items:
        key = it["name"].lower()
        if key in seen:
            continue
        seen.add(key)
        it = dict(it)
        it["menu_ok"] = bool(MENU_NAME.match(it["name"]))
        out.append(it)
    out.sort(key=lambda x: (x["name"] != "start", x["name"] != "help", x["name"]))
    return out


def menu_payload(commands: list[dict]) -> list[dict]:
    """setMyCommands के लिए सिर्फ़ पहचाने गए और Telegram-समर्थित Commands."""
    res = []
    for c in commands:
        if not c.get("menu_ok"):
            continue
        desc = _STD_DESC.get(c["name"], f"/{c['name']} चलाएँ")
        res.append({"command": c["name"], "description": desc[:200]})
    return res[:100]
