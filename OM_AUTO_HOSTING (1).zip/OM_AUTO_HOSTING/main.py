#!/usr/bin/env python3
"""main.py - OM AUTO HOSTING BOT का शुरुआती बिंदु."""
from __future__ import annotations

import logging
import os
import signal
import sys
import threading

from config import Config
from logs_manager import setup_system_logging


def main(hooks=None, cfg=None) -> int:
    hooks = hooks or {}
    cfg = cfg or Config.from_env()
    problems = cfg.validate()
    if problems:
        print("❌ Configuration में समस्या:\n" + "\n".join(" • " + p for p in problems), file=sys.stderr)
        print("\n.env फाइल ठीक करें (नमूना: .env.example) और दोबारा चलाएँ.", file=sys.stderr)
        return 2
    cfg.ensure_dirs()
    setup_system_logging(cfg)
    log = logging.getLogger("om.main")

    import telebot  # देर से import ताकि config की गलती पहले दिखे
    import admin_panel
    import file_receiver
    import handlers
    from context import build_context

    ctx = build_context(cfg)
    ctx.tg = telebot.TeleBot(cfg.bot_token, parse_mode=None, threaded=True, num_threads=8)
    ctx.send = handlers.make_sender(ctx)
    ctx.reply_text = lambda uid, text: ctx.send(uid, text)
    ctx.manager.set_notifier(ctx.send)

    ok, msg = ctx.runner.available()
    log.info("Runner: %s (%s)", ctx.runner.name, msg)
    if ctx.runner.name == "docker":
        if ok:
            ctx.runner.ensure_network()
            if not ctx.runner.image_exists():
                log.warning("Sandbox image '%s' नहीं मिली. `docker build -t %s .` चलाएँ (install.sh यह करता है).", cfg.sandbox_image, cfg.sandbox_image)
        else:
            log.error("Docker उपलब्ध नहीं: %s — Bots Host नहीं हो पाएँगे.", msg)
    elif ctx.runner.name == "process":
        log.warning("PROCESS mode: Docker के बिना, कमज़ोर Isolation. सिर्फ़ भरोसेमंद Users के Bots.")
    else:
        log.warning("⚠️ LOCAL (असुरक्षित) Runner चालू है. सिर्फ़ टेस्ट के लिए!")

    # handlers: commands/documents पहले, generic text आखिर में
    admin_panel.register(ctx)
    file_receiver.register(ctx)
    handlers.register(ctx)

    try:
        from telebot.types import BotCommand
        ctx.tg.set_my_commands([BotCommand(c, d) for c, d in [
            ("start", "शुरू करें"), ("menu", "मुख्य Menu"), ("help", "मदद"), ("upload", "नया Bot Upload"),
            ("mybots", "मेरे Bots"), ("status", "Bot Status"), ("running", "चल रहे Bots"), ("startbot", "Bot Start"),
            ("stopbot", "Bot Stop"), ("restartbot", "Bot Restart"), ("logs", "Live Logs"), ("errors", "Error Report"),
            ("commands", "Bot के Commands"), ("firebase", "Firebase Checker"), ("server", "Server Status"),
            ("backup", "Backup/Restore"), ("settings", "Token/API Settings"), ("admin", "Admin Panel (Owner)")]])
    except Exception as e:
        log.warning("Commands menu सेट नहीं हुआ: %s", e)

    if hooks.get("before_recover"):
        hooks["before_recover"](ctx)
    res = ctx.manager.recover_all()
    log.info("Auto Recovery: %s", res)
    ctx.monitor.start()
    if hooks.get("on_ready"):
        hooks["on_ready"](ctx)

    if cfg.health_port:
        _start_health_server(cfg.health_port, log)

    def _term(signum, frame):
        log.info("Signal %s मिला, बंद हो रहा हूँ", signum)
        try:
            ctx.tg.stop_polling()
        except Exception:
            pass
    signal.signal(signal.SIGTERM, _term)
    signal.signal(signal.SIGINT, _term)

    try:
        ctx.send(cfg.owner_id, f"✅ <b>OM AUTO HOSTING BOT चालू</b>\nAuto Recovery: {res['adopted']} चल रहे मिले, {res['restarted']} दोबारा शुरू, {res.get('reinstalling', 0)} Libraries दोबारा लगाकर शुरू हो रहे, {res['failed']} फेल.")
    except Exception as e:
        log.warning("Owner को Start संदेश नहीं गया (Owner ने बॉट पर /start नहीं भेजा?): %s", e)

    log.info("Polling शुरू")
    ctx.tg.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)
    ctx.monitor.stop()
    if hooks.get("on_shutdown"):
        try:
            hooks["on_shutdown"](ctx)
        except Exception:
            log.exception("on_shutdown fail")
    if ctx.restart_requested:
        log.info("Restart के लिए खुद को दोबारा चला रहा हूँ")
        os.execv(sys.executable, [sys.executable] + sys.argv)
    return 0


def _start_health_server(port, log):
    """वैकल्पिक: सिर्फ़ 'ok' लौटाने वाला छोटा HTTP server (Flask की जरूरत नहीं). 24/7 की गारंटी नहीं देता."""
    from http.server import BaseHTTPRequestHandler, HTTPServer

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OM AUTO HOSTING BOT ok")

        def log_message(self, *a):
            pass

    srv = HTTPServer(("0.0.0.0", port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log.info("Health endpoint: port %s", port)


if __name__ == "__main__":
    sys.exit(main())
