"""docker_runner.py - Hosted Bots को Docker Container में चलाना (Isolation का मुख्य हिस्सा).

DockerRunner  : असली, सुरक्षित तरीका (non-root, cap-drop, read-only, CPU/RAM/PID limit, अलग network).
LocalRunner   : सिर्फ़ टेस्ट के लिए. कोई Isolation नहीं! ALLOW_UNSAFE_LOCAL_RUNNER=1 के बिना चालू नहीं होता.

Docker Socket कभी किसी Container में Mount नहीं होता. हर Bot के Container में सिर्फ़ उसी का Project folder (/work) जाता है.
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path


@dataclass
class RunResult:
    rc: int
    out: str
    err: str
    timed_out: bool = False

    @property
    def text(self) -> str:
        return (self.out or "") + (("\n" + self.err) if self.err else "")


class RunnerError(Exception):
    pass


def _safe_env_file_value(v: str) -> str:
    if "\n" in v or "\r" in v or "\x00" in v:
        raise RunnerError("Environment value में नई लाइन नहीं हो सकती.")
    return v


class BaseRunner:
    name = "base"
    supports_since = False

    def container_name(self, bot_id: int) -> str:
        return f"om_b{bot_id}"


# ============================================================== Docker
class DockerRunner(BaseRunner):
    name = "docker"
    supports_since = True

    def __init__(self, cfg):
        self.cfg = cfg
        self._runtimes: dict | None = None
        self._tmp = Path(cfg.data_dir) / "tmp"
        self._tmp.mkdir(parents=True, exist_ok=True)
        os.chmod(self._tmp, 0o700)

    # ---- low level
    def _docker(self, args, timeout=30) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout,
                                  encoding="utf-8", errors="ignore")
        except FileNotFoundError:
            raise RunnerError("Docker इंस्टॉल नहीं है (install.sh चलाएँ).")
        except subprocess.TimeoutExpired:
            raise RunnerError("Docker ने समय पर जवाब नहीं दिया.")

    def available(self) -> tuple[bool, str]:
        try:
            r = self._docker(["info", "--format", "{{.ServerVersion}}"], timeout=15)
        except RunnerError as e:
            return False, str(e)
        if r.returncode != 0:
            msg = (r.stderr or r.stdout or "").strip().splitlines()[-1:] or ["अज्ञात"]
            return False, f"Docker चल नहीं रहा/Permission नहीं: {msg[0]}"
        return True, f"Docker {r.stdout.strip()}"

    def image_exists(self) -> bool:
        r = self._docker(["image", "inspect", self.cfg.sandbox_image])
        return r.returncode == 0

    def build_image(self, context_dir) -> tuple[bool, str]:
        r = self._docker(["build", "-t", self.cfg.sandbox_image, str(context_dir)], timeout=1800)
        return r.returncode == 0, (r.stderr or r.stdout)[-1500:]

    def ensure_network(self) -> tuple[bool, str]:
        net = self.cfg.sandbox_network
        if not net or net == "bridge":
            return True, "default bridge"
        if self._docker(["network", "inspect", net]).returncode == 0:
            return True, net
        r = self._docker(["network", "create", "--driver", "bridge",
                          "-o", "com.docker.network.bridge.enable_icc=false",
                          "-o", "com.docker.network.bridge.name=om-br0", net])
        return r.returncode == 0, (r.stderr or r.stdout).strip()

    def runtimes(self) -> dict:
        if self._runtimes is None:
            res = {"python": False, "node": False}
            if self.available()[0] and self.image_exists():
                r = self.run_oneshot(Path(self._tmp), ["sh", "-c", "python3 --version; node --version"], network=False, timeout=60, mount=False)
                res["python"] = "Python 3" in r.text
                res["node"] = "\nv" in ("\n" + r.text)
            self._runtimes = res
        return self._runtimes

    def _uid_gid(self) -> tuple[int, int]:
        if hasattr(os, "getuid") and os.getuid() != 0:
            return os.getuid(), os.getgid()
        return 10001, 10001

    def prepare_project_dir(self, project_dir):
        """Root से चल रहे Manager पर Project folder को non-root uid का बनाना."""
        if hasattr(os, "getuid") and os.getuid() == 0:
            uid, gid = self._uid_gid()
            for dp, dns, fns in os.walk(project_dir):
                try:
                    os.chown(dp, uid, gid)
                    for fn in fns:
                        os.chown(os.path.join(dp, fn), uid, gid)
                except OSError:
                    pass

    # ---- args
    def _common(self, name, project_dir, env_file, network, mem_mb, cpus, tmp_mb, mount=True) -> list[str]:
        uid, gid = self._uid_gid()
        a = ["--name", name, "--user", f"{uid}:{gid}",
             "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
             "--read-only", "--tmpfs", f"/tmp:rw,size={tmp_mb}m",
             "--pids-limit", str(self.cfg.pids_limit),
             "--memory", f"{mem_mb}m", "--memory-swap", f"{mem_mb}m", "--cpus", str(cpus),
             "--ulimit", "nofile=1024:1024", "--ulimit", "core=0",
             "--label", "om.managed=1",
             "-e", "HOME=/tmp", "-e", "PYTHONUNBUFFERED=1", "-e", "PYTHONDONTWRITEBYTECODE=1",
             "-e", "PIP_NO_CACHE_DIR=1", "-e", "NPM_CONFIG_CACHE=/tmp/npm-cache", "-e", "NO_UPDATE_NOTIFIER=1"]
        if network:
            net = self.cfg.sandbox_network
            if net:
                a += ["--network", net]
            a += ["--dns", "1.1.1.1", "--dns", "8.8.8.8"]
        else:
            a += ["--network", "none"]
        if mount:
            a += ["--mount", f"type=bind,src={Path(project_dir).resolve()},dst=/work", "-w", "/work"]
        if env_file:
            a += ["--env-file", str(env_file)]
        return a

    def _write_env_file(self, env: dict | None) -> Path | None:
        if not env:
            return None
        fd, p = tempfile.mkstemp(prefix="env_", dir=self._tmp)
        with os.fdopen(fd, "w") as f:
            for k, v in env.items():
                f.write(f"{k}={_safe_env_file_value(str(v))}\n")
        os.chmod(p, 0o600)
        return Path(p)

    # ---- argv builders (Container के अंदर के path)
    def venv_python(self, project_dir) -> str:
        return "/work/.venv/bin/python" if (Path(project_dir) / ".venv" / "bin" / "python").exists() else "python3"

    def python_argv(self, project_dir, *args) -> list[str]:
        return [self.venv_python(project_dir), *args]

    def node_argv(self, project_dir, *args) -> list[str]:
        return ["node", *args]

    # ---- one-shot (install / syntax check)
    def run_oneshot(self, project_dir, argv, env=None, network=True, timeout=60, mem_mb=None, mount=True,
                    tmp_mb=512) -> RunResult:
        name = f"om_task_{uuid.uuid4().hex[:10]}"
        env_file = self._write_env_file(env)
        mem = mem_mb or max(self.cfg.mem_limit_mb, 512)
        cmd = ["run", "--rm", *self._common(name, project_dir, env_file, network, mem, max(self.cfg.cpu_limit, 1.0), tmp_mb, mount),
               self.cfg.sandbox_image, *argv]
        try:
            r = subprocess.run(["docker", *cmd], capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="ignore")
            return RunResult(r.returncode, r.stdout, r.stderr)
        except subprocess.TimeoutExpired as e:
            subprocess.run(["docker", "rm", "-f", name], capture_output=True)
            return RunResult(124, (e.stdout or b"").decode("utf-8", "ignore") if isinstance(e.stdout, bytes) else (e.stdout or ""),
                             "Timeout: काम तय समय में पूरा नहीं हुआ.", True)
        except FileNotFoundError:
            raise RunnerError("Docker इंस्टॉल नहीं है.")
        finally:
            if env_file:
                env_file.unlink(missing_ok=True)

    def ensure_venv(self, project_dir, timeout=120) -> RunResult:
        if (Path(project_dir) / ".venv" / "bin" / "python").exists():
            return RunResult(0, "venv पहले से है", "")
        return self.run_oneshot(project_dir, ["python3", "-m", "venv", "/work/.venv"], network=False, timeout=timeout)

    # ---- long running
    def start(self, bot_id, project_dir, argv, env=None) -> str:
        name = self.container_name(bot_id)
        self._docker(["rm", "-f", name])
        env_file = self._write_env_file(env)
        try:
            args = ["run", "-d", *self._common(name, project_dir, env_file, True, self.cfg.mem_limit_mb, self.cfg.cpu_limit, 64),
                    "--restart", "no", "--log-driver", "json-file", "--log-opt", "max-size=5m", "--log-opt", "max-file=2",
                    "--label", f"om.bot={bot_id}", self.cfg.sandbox_image, *argv]
            r = self._docker(args, timeout=120)
        finally:
            if env_file:
                env_file.unlink(missing_ok=True)
        if r.returncode != 0:
            raise RunnerError("Container शुरू नहीं हुआ: " + (r.stderr or r.stdout).strip()[-400:])
        return r.stdout.strip()[:12]

    def state(self, bot_id) -> dict:
        r = self._docker(["inspect", "-f", "{{.State.Running}}|{{.State.ExitCode}}|{{.State.OOMKilled}}|{{.State.Pid}}|{{.State.StartedAt}}",
                          self.container_name(bot_id)])
        if r.returncode != 0:
            return {"exists": False, "running": False, "exit_code": None, "oom": False, "pid": None}
        p = r.stdout.strip().split("|")
        return {"exists": True, "running": p[0] == "true", "exit_code": int(p[1]) if p[1].lstrip("-").isdigit() else None,
                "oom": p[2] == "true", "pid": int(p[3]) if p[3].isdigit() and int(p[3]) > 0 else None, "started": p[4] if len(p) > 4 else ""}

    def is_running(self, bot_id) -> bool:
        return self.state(bot_id)["running"]

    def exit_code(self, bot_id):
        return self.state(bot_id)["exit_code"]

    def pid(self, bot_id):
        return self.state(bot_id)["pid"]

    def logs(self, bot_id, tail=200, since_ts: float = 0) -> str:
        args = ["logs", "--tail", str(tail)]
        if since_ts:
            args += ["--since", str(int(since_ts))]
        r = self._docker(args + [self.container_name(bot_id)], timeout=30)
        if r.returncode != 0:
            return ""
        return (r.stdout or "") + (r.stderr or "")

    def clear_logs(self, bot_id, project_dir=None):
        pass  # Docker में since-marker इस्तेमाल होता है

    def stats(self, bot_id) -> dict:
        r = self._docker(["stats", "--no-stream", "--format", "{{.CPUPerc}}|{{.MemUsage}}", self.container_name(bot_id)], timeout=20)
        if r.returncode != 0 or "|" not in r.stdout:
            return {}
        cpu, mem = r.stdout.strip().split("|", 1)
        try:
            cpu_v = float(cpu.strip().rstrip("%"))
        except ValueError:
            cpu_v = 0.0
        return {"cpu": cpu_v, "mem_text": mem.split("/")[0].strip(), "mem_mb": _parse_mem(mem.split("/")[0])}

    def stop(self, bot_id, timeout=10):
        self._docker(["stop", "-t", str(timeout), self.container_name(bot_id)], timeout=timeout + 20)

    def remove(self, bot_id):
        self._docker(["rm", "-f", self.container_name(bot_id)])

    def list_running(self) -> set[int]:
        r = self._docker(["ps", "--filter", "label=om.managed=1", "--format", "{{.Label \"om.bot\"}}"])
        return {int(x) for x in r.stdout.split() if x.isdigit()}


def _parse_mem(s: str) -> float:
    s = s.strip().lower()
    try:
        for unit, mul in (("gib", 1024), ("mib", 1), ("kib", 1 / 1024), ("gb", 1000), ("mb", 1), ("kb", 0.001), ("b", 1 / 1048576)):
            if s.endswith(unit):
                return float(s[: -len(unit)]) * mul
    except ValueError:
        pass
    return 0.0


# ================================================================ Local
class LocalRunner(BaseRunner):
    """⚠️ असुरक्षित - सिर्फ़ Development/Test के लिए. कोई Isolation नहीं."""
    name = "local"
    supports_since = False

    def __init__(self, cfg):
        if not cfg.allow_unsafe_local:
            raise RunnerError("LocalRunner असुरक्षित है. सिर्फ़ टेस्ट के लिए ALLOW_UNSAFE_LOCAL_RUNNER=1 लगाएँ.")
        self.cfg = cfg
        self.dir = Path(cfg.data_dir) / "local_runtime"
        self.dir.mkdir(parents=True, exist_ok=True)
        self._procs: dict[int, subprocess.Popen] = {}

    def available(self):
        return True, "LOCAL (असुरक्षित, सिर्फ़ टेस्ट)"

    def image_exists(self):
        return True

    def ensure_network(self):
        return True, "local"

    def runtimes(self) -> dict:
        return {"python": True, "node": shutil.which("node") is not None}

    def prepare_project_dir(self, project_dir):
        pass

    # ---- Subclass hooks (ProcessRunner में काम आते हैं)
    def _limits(self) -> str:
        return ""

    def _priv_prefix(self, project_dir) -> list:
        return []

    def _clean_env(self, project_dir, env):
        e = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": str(project_dir), "LANG": "C.UTF-8",
             "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1"}
        e.update({k: str(v) for k, v in (env or {}).items()})
        return e

    def venv_python(self, project_dir) -> str:
        p = Path(project_dir) / ".venv" / "bin" / "python"
        return str(p) if p.exists() else sys.executable

    def python_argv(self, project_dir, *args):
        return [self.venv_python(project_dir), *args]

    def node_argv(self, project_dir, *args):
        return [shutil.which("node") or "node", *args]

    def run_oneshot(self, project_dir, argv, env=None, network=True, timeout=60, mem_mb=None, mount=True, tmp_mb=0) -> RunResult:
        # Container के path (/work/...) को असली path में बदलो
        argv = [a.replace("/work/", str(Path(project_dir)) + "/") if isinstance(a, str) else a for a in argv]
        if self._limits() or self._priv_prefix(project_dir):
            argv = ["sh", "-c", self._limits() + 'exec "$@"', "sh", *self._priv_prefix(project_dir), *argv]
        try:
            p = subprocess.Popen(argv, cwd=project_dir, env=self._clean_env(project_dir, env), stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="ignore", start_new_session=True)
        except FileNotFoundError as e:
            return RunResult(127, "", str(e))
        try:
            out, err = p.communicate(timeout=timeout)
            return RunResult(p.returncode, out, err)
        except subprocess.TimeoutExpired:
            _kill_group(p.pid)
            out, err = p.communicate()
            return RunResult(124, out or "", (err or "") + "\nTimeout: काम तय समय में पूरा नहीं हुआ.", True)

    def ensure_venv(self, project_dir, timeout=120) -> RunResult:
        if (Path(project_dir) / ".venv" / "bin" / "python").exists():
            return RunResult(0, "venv पहले से है", "")
        return self.run_oneshot(project_dir, [sys.executable, "-m", "venv", str(Path(project_dir) / ".venv")], timeout=timeout)

    # ---- long running
    def _meta(self, bot_id) -> Path:
        return self.dir / f"{bot_id}.json"

    def _read_meta(self, bot_id):
        try:
            return json.loads(self._meta(bot_id).read_text())
        except (OSError, ValueError):
            return None

    def start(self, bot_id, project_dir, argv, env=None) -> str:
        self.stop(bot_id, timeout=3)
        log = self.dir / f"{bot_id}.log"
        exitf = self.dir / f"{bot_id}.exit"
        exitf.unlink(missing_ok=True)
        wrapper = ["sh", "-c", self._limits() + '"$@"; echo $? > "$0"', str(exitf), *self._priv_prefix(project_dir), *argv]
        lf = open(log, "ab", buffering=0)
        p = subprocess.Popen(wrapper, cwd=project_dir, env=self._clean_env(project_dir, env), stdout=lf, stderr=subprocess.STDOUT,
                             stdin=subprocess.DEVNULL, start_new_session=True)
        lf.close()
        self._procs[bot_id] = p
        self._meta(bot_id).write_text(json.dumps({"pid": p.pid, "started": time.time(), "log": str(log), "exit": str(exitf)}))
        return f"pid{p.pid}"

    def _alive(self, bot_id) -> bool:
        import psutil
        m = self._read_meta(bot_id)
        if not m:
            return False
        proc = self._procs.get(bot_id)
        if proc is not None:
            if proc.poll() is not None:
                return False
            return True
        try:
            ps = psutil.Process(m["pid"])
            return ps.is_running() and ps.status() != psutil.STATUS_ZOMBIE and abs(ps.create_time() - m["started"]) < 30
        except psutil.NoSuchProcess:
            return False

    def is_running(self, bot_id) -> bool:
        return self._alive(bot_id)

    def state(self, bot_id) -> dict:
        m = self._read_meta(bot_id)
        running = self._alive(bot_id)
        return {"exists": m is not None, "running": running, "exit_code": None if running else self.exit_code(bot_id),
                "oom": False, "pid": m["pid"] if m and running else None}

    def exit_code(self, bot_id):
        m = self._read_meta(bot_id)
        if not m:
            return None
        try:
            return int(Path(m["exit"]).read_text().strip())
        except (OSError, ValueError):
            proc = self._procs.get(bot_id)
            return proc.poll() if proc else None

    def pid(self, bot_id):
        m = self._read_meta(bot_id)
        return m["pid"] if m and self._alive(bot_id) else None

    def logs(self, bot_id, tail=200, since_ts=0) -> str:
        m = self._read_meta(bot_id)
        if not m:
            return ""
        try:
            data = Path(m["log"]).read_bytes()[-200_000:].decode("utf-8", "ignore")
        except OSError:
            return ""
        return "\n".join(data.splitlines()[-tail:])

    def clear_logs(self, bot_id, project_dir=None):
        m = self._read_meta(bot_id)
        if m:
            try:
                open(m["log"], "wb").close()
            except OSError:
                pass

    def stats(self, bot_id) -> dict:
        import psutil
        m = self._read_meta(bot_id)
        if not m or not self._alive(bot_id):
            return {}
        try:
            root = psutil.Process(m["pid"])
            procs = [root, *root.children(recursive=True)]
            rss = sum(p.memory_info().rss for p in procs if p.is_running())
            cpu = sum(p.cpu_percent(interval=0.1) for p in procs if p.is_running())
            return {"cpu": cpu, "mem_mb": rss / 1048576, "mem_text": f"{rss / 1048576:.1f}MiB"}
        except psutil.Error:
            return {}

    def stop(self, bot_id, timeout=10):
        m = self._read_meta(bot_id)
        if not m:
            return
        if self._alive(bot_id):
            _kill_group(m["pid"], grace=min(timeout, 5))
        proc = self._procs.pop(bot_id, None)
        if proc is not None:
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass

    def remove(self, bot_id):
        self.stop(bot_id, timeout=3)
        for ext in (".json", ".log", ".exit"):
            (self.dir / f"{bot_id}{ext}").unlink(missing_ok=True)

    def list_running(self) -> set[int]:
        out = set()
        for p in self.dir.glob("*.json"):
            if p.stem.isdigit() and self._alive(int(p.stem)):
                out.add(int(p.stem))
        return out


def _kill_group(pid: int, grace: float = 3.0):
    try:
        pgid = os.getpgid(pid)
    except (ProcessLookupError, PermissionError):
        return
    try:
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return
    end = time.time() + grace
    while time.time() < end:
        try:
            os.killpg(pgid, 0)
        except ProcessLookupError:
            return
        time.sleep(0.1)
    try:
        os.killpg(pgid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


class ProcessRunner(LocalRunner):
    """Render (Free) के लिए: Docker नहीं, हर Bot अलग Process.

    Isolation Docker से कमज़ोर है. जितना संभव है:
    - साफ़ Environment (Manager के Secrets Bot को नहीं मिलते),
    - Root हो तो हर Bot का अपना uid (setpriv) + 700 वाला folder → Bots एक-दूसरे की और Manager की files/Secrets नहीं पढ़ सकते,
    - ulimit से फाइल-साइज़ सीमा, core dump बंद; RAM की सीमा Monitor RSS देखकर लागू करता है.
    Network पर कोई रोक नहीं. सिर्फ़ भरोसेमंद लोगों के Bots के लिए.
    """
    name = "process"

    def __init__(self, cfg):
        if not (cfg.render_mode or cfg.allow_process_runner):
            raise RunnerError("ProcessRunner सिर्फ़ Render पर (RENDER=true) या ALLOW_PROCESS_RUNNER=1 के साथ चलता है.")
        self.cfg = cfg
        self.dir = Path(cfg.data_dir) / "local_runtime"
        self.dir.mkdir(parents=True, exist_ok=True)
        os.chmod(self.dir, 0o700)
        self._procs = {}
        self.is_root = hasattr(os, "getuid") and os.getuid() == 0

    def available(self):
        extra = "root: हर Bot का अलग uid" if self.is_root else "non-root: सभी Bots एक ही uid (कमज़ोर Isolation)"
        return True, f"PROCESS mode ({extra})"

    def _limits(self) -> str:
        blocks = max(1, int(self.cfg.fsize_limit_mb) * 2048)  # 512-byte blocks
        return f"ulimit -f {blocks} 2>/dev/null; ulimit -c 0 2>/dev/null; ulimit -n 1024 2>/dev/null; "

    @staticmethod
    def bot_id_of(project_dir):
        parts = Path(project_dir).resolve().parts
        try:
            i = parts.index("bots")
            return int(parts[i + 1])
        except (ValueError, IndexError):
            return None

    def uid_of(self, project_dir):
        bid = self.bot_id_of(project_dir)
        return self.cfg.bot_uid_base + bid if bid is not None else None

    def _priv_prefix(self, project_dir) -> list:
        if not self.is_root:
            return []
        uid = self.uid_of(project_dir)
        if uid is None:
            return []
        return ["setpriv", "--reuid", str(uid), "--regid", str(uid), "--clear-groups", "--no-new-privs"]

    def prepare_project_dir(self, project_dir):
        """Root हो तो Bot के folder को उसके uid का और 700 बनाओ; ऊपर के folders सिर्फ़ 'गुज़रने' लायक (711)."""
        if not self.is_root:
            return
        uid = self.uid_of(project_dir)
        if uid is None:
            return
        root = Path(project_dir).resolve().parent
        data = Path(self.cfg.data_dir).resolve()
        cur = root.parent
        while cur != data.parent and data in (cur, *cur.parents):
            try:
                os.chmod(cur, 0o711)
            except OSError:
                pass
            cur = cur.parent
        try:
            st = os.stat(root)
            need = st.st_uid != uid
        except OSError:
            return
        if need:
            for dp, dns, fns in os.walk(root):
                for n in [dp] + [os.path.join(dp, f) for f in fns]:
                    try:
                        os.chown(n, uid, uid)
                    except OSError:
                        pass
        try:
            os.chmod(root, 0o700)
        except OSError:
            pass


def make_runner(cfg):
    if cfg.runner_mode == "local":
        return LocalRunner(cfg)
    if cfg.runner_mode == "process":
        return ProcessRunner(cfg)
    return DockerRunner(cfg)
