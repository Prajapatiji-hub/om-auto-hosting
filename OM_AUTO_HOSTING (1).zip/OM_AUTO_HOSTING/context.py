"""context.py - सारे हिस्सों को जोड़ने वाला AppContext (Telegram से अलग, इसलिए टेस्ट हो सकता है)."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from access_control import AccessControl
from backup_manager import BackupManager
from bot_manager import BotManager
from config import Config
from database import Database
from dependency_manager import DependencyManager
from logs_manager import LogsManager
from process_monitor import ProcessMonitor
from token_manager import TokenManager
from docker_runner import make_runner


@dataclass
class AppContext:
    cfg: Config
    db: Database
    runner: Any
    tokens: TokenManager
    deps: DependencyManager
    logs: LogsManager
    manager: BotManager
    access: AccessControl
    backups: BackupManager
    monitor: ProcessMonitor | None = None
    tg: Any = None                       # telebot.TeleBot (main.py में सेट)
    restart_requested: bool = False
    fb_last: dict = field(default_factory=dict)
    snapshotter: Any = None
    reply_text: Callable = field(default=lambda uid, text: None)

    def send(self, uid, text, buttons=None):
        """Manager का notifier: buttons = [[(label, callback_data), ...], ...]"""
        raise NotImplementedError


def build_context(cfg: Config, runner=None, http_get=None, http_post=None) -> AppContext:
    cfg.ensure_dirs()
    (cfg.data_dir / "tmp").mkdir(parents=True, exist_ok=True)
    db = Database(cfg.db_path)
    db.upsert_user(cfg.owner_id, role="owner")
    runner = runner or make_runner(cfg)
    tokens = TokenManager(cfg, db, http_get=http_get, http_post=http_post)
    deps = DependencyManager(cfg, db, runner)
    logs = LogsManager(cfg, db, runner, tokens)
    manager = BotManager(cfg, db, runner, tokens, deps, logs)
    access = AccessControl(cfg, db)
    backups = BackupManager(cfg, db, manager, tokens)
    ctx = AppContext(cfg, db, runner, tokens, deps, logs, manager, access, backups)
    ctx.monitor = ProcessMonitor(cfg, db, runner, manager, backups)
    return ctx
