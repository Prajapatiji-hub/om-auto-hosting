# OM AUTO HOSTING BOT — पूरी गाइड (हिंदी)

सिर्फ़ आप और आपके 2–3 चुने हुए दोस्त Telegram पर `.py` / `.js` / `.zip` फाइल भेजें → Bot खुद जाँचे, Libraries लगाए, Token माँगे, Test करे और Host करे।
**किसी भी AI API (FreeModel/Claude/OpenAI/Gemini) की जरूरत नहीं।** विश्लेषण सिर्फ़ Python `ast`, regex और `package.json` पढ़कर होता है।

---

## 1. पुराने कोड (`hostingbotsrc.py`) का विश्लेषण

**फाइल पढ़कर जो मिला (1245 लाइन):**

| पहले से था (रखा/सुधारा) | खराब या अधूरा था (बदला) |
|---|---|
| File Upload, Check Files, Start/Stop, Logs | **Hosting Bot का Token सीधे Code में लिखा था** (इसे तुरंत Revoke करें, नीचे देखें) |
| Bot Speed, Statistics, Broadcast, Lock/Unlock, Admin Panel | Uploaded Scripts **Host Server पर ही** `subprocess.Popen` से चलती थीं — कोई Isolation नहीं (Script आपका Token/Database पढ़ सकती थी) |
| SQLite Database | `pip install` सीधे Host के Python में, बिना venv, किसी भी नाम का Package |
| Entry Files (main.py, bot.py, app.py, index.js…) की पहचान | Subscription सिस्टम और Dictionary में (Memory में) Users की जानकारी |
| `.py`, `.js`, `.zip` Upload | बटनों में अनौपचारिक fields (`icon_custom_emoji_id`) — सब Telegram Clients पर नहीं चलते |
| Flask Keep-Alive | Process List Memory में थी → Restart पर खो जाती थी |

**मुझे आपकी दूसरी फाइल `firebase url check.py` अपलोड में नहीं मिली**, इसलिए Firebase Checker आपकी बताई सुविधाओं (Spec) के आधार पर नया बनाया है। वह फाइल भेज दें तो उसके बचे हुए फीचर मिलाए जा सकते हैं।

**नया क्या जोड़ा:** Docker Isolation, हर Project का अलग venv, Static Security Scan, Token Manager (Encrypted), Command Detector, Dependency Safety, Auto Restart/Recovery, Backup/Restore, Firebase Checker, Owner/Friends Access Control, Server Monitor, Install Script।

**ज़रूरी Libraries:** `pyTelegramBotAPI`, `psutil`, `requests`, `cryptography`, `python-dotenv` (Manager के लिए) + Docker। Hosted Bots की Libraries Sandbox में अलग लगती हैं।

> 🔴 **अभी करें:** पुरानी फाइल में जो Token था वह इस चैट/फाइल में आ चुका है। अगर वह असली था तो Telegram में **@BotFather → /mybots → वह Bot → API Token → Revoke current token** करें और नया Token इस्तेमाल करें। `backup_original/hostingbotsrc.py.txt` में मैंने Token हटाकर Backup रखा है; असली मूल फाइल आपके पास है।

---

## 2. क्या-क्या है (Files)

```
OM_AUTO_HOSTING/
 main.py              शुरुआत, सब कुछ जोड़ता है
 config.py            .env से Settings
 database.py          SQLite (11+ Tables)
 keyboards.py         22 बटन वाला Menu + Inline बटन
 handlers.py          Menu, Commands, Callbacks
 access_control.py    सिर्फ़ Owner + Friends
 file_receiver.py     फाइल लेना/जाँचना/सहेजना
 project_detector.py  फाइल/Project का प्रकार, Entry चुनना
 file_analyzer.py     Imports, Framework, Token/API config, Errors (बिना AI)
 command_detector.py  Code में असली Commands
 dependency_manager.py Packages पहचानना/जाँचना/Install
 token_manager.py     Token/Keys Encrypted, getMe जाँच
 security_manager.py  Static Scan, ZIP सुरक्षा, Redaction
 docker_runner.py     Docker में चलाना (+ सिर्फ़ टेस्ट वाला Local Runner)
 bot_manager.py       Upload→Analysis→Install→Host पूरा Pipeline
 process_monitor.py   Crash पकड़ना, Auto Restart
 logs_manager.py      Logs (Secrets छिपे)
 error_handler.py     Error का कारण + Hindi Report
 firebase_checker.py  Firebase जाँच (+ firebase_ui.py Telegram हिस्सा)
 admin_panel.py       Owner Panel
 backup_manager.py    Backup/Restore
 server_monitor.py    CPU/RAM/Disk/Docker
 Dockerfile           Sandbox image (Python+Node)
 docker-compose.yml   (वैकल्पिक, टेस्ट नहीं हुई)
 install.sh / start.sh  Server Setup / चलाना
 deploy/              systemd + firewall files
 tests/               टेस्ट + TEST_REPORT.md
```

---

## 3. Free Server — Oracle Cloud (पहली पसंद)

### ⚠️ पहले सच जान लें
- **24/7 Uptime की गारंटी नहीं।** Free Server कभी भी बंद/हटाया जा सकता है।
- Oracle ने हाल में Always Free **Ampere A1** की सीमा **4 CPU/24 GB से घटाकर 2 CPU/12 GB** कर दी है (कई रिपोर्ट्स और Oracle के दस्तावेज़ में यही दिखता है; जून–अगस्त 2026 के बीच लागू बताया गया)। सीमाएँ बदलती रहती हैं — Sign-up से पहले Oracle का *Always Free Resources* पेज खुद देखें।
- कई Regions में Ampere की **"Out of capacity"** आती है; दिन/Region बदलकर कोशिश करनी पड़ती है।
- Idle या सीमा से ज़्यादा इस्तेमाल वाले Free Instances को Oracle रोक/हटा सकता है। Account बनाते समय आमतौर पर Card Verification माँगा जाता है।
- **1 GB RAM वाली AMD Micro VM** में यह System बहुत तंग चलेगा (Docker + Bots)। Ampere A1 (2 CPU/12 GB तक) बेहतर है।

### अगर Oracle Free नहीं मिला तो
- **Google Cloud e2-micro (Always Free):** सिर्फ़ चुनिंदा US Regions, बहुत छोटी (RAM कम), Network की सीमाएँ — बहुत कम Bots ही चलेंगे। शर्तें बदलती रहती हैं, खुद जाँचें।
- **Render/Railway/Fly जैसी Free सेवाएँ:** इनमें आम तौर पर **Docker चलाने की अनुमति (Docker Socket) नहीं होती**, इसलिए यह पूरा Isolation वाला System वहाँ नहीं चलेगा। (Local Runner वहाँ चलाना **असुरक्षित** है — मैं सलाह नहीं देता।)
- **Android फोन में Termux:** Docker नहीं चलता → यह System नहीं चलेगा।
- सबसे भरोसेमंद विकल्प: कोई सस्ता (लगभग $3–5/माह) VPS।

---

## 4. Android फोन से Setup (बिना PC)

### चरण A — Telegram में तैयारी (5 मिनट)
1. **@BotFather** → `/newbot` → नाम दें → **Token** मिलेगा। यही **Hosting Bot का Token** है। (कहीं सार्वजनिक न करें।)
2. **@userinfobot** पर `/start` भेजें → आपका **User ID** (सिर्फ़ नंबर) मिलेगा। दोस्तों से भी उनके ID माँगें।

### चरण B — Oracle में VM बनाना (फोन के Browser में, "Desktop site" चालू करें)
1. cloud.oracle.com पर Free Account बनाएँ।
2. **Compute → Instances → Create instance**।
3. Image: **Canonical Ubuntu 22.04 या 24.04**। Shape: **VM.Standard.A1.Flex** (2 OCPU, 12 GB) — न मिले तो *Out of capacity* के बारे में ऊपर देखें; या `VM.Standard.E2.1.Micro`।
4. **SSH keys:** "Generate a key pair for me" चुनकर **Private key (.key) Download** करें और संभालकर रखें।
5. Create दबाएँ। कुछ मिनट बाद **Public IP** दिखेगा।

### चरण C — फोन से Server में Login (SSH)
**Termux** (F-Droid से) इंस्टॉल करें। फिर:
```bash
pkg update && pkg install openssh -y
termux-setup-storage          # Storage की अनुमति दें
cp ~/storage/downloads/ssh-key-*.key ~/oracle.key
chmod 600 ~/oracle.key
ssh -i ~/oracle.key ubuntu@आपका_PUBLIC_IP
```
(सीधा App चाहें तो *Termius* भी चलेगा: Key Import करके User `ubuntu` से जुड़ें।)

### चरण D — Project को Server पर पहुँचाना
**तरीका 1 (आसान):** इस Project की ZIP को Termux से भेजें:
```bash
# Termux में (Server से बाहर निकलकर):
scp -i ~/oracle.key ~/storage/downloads/OM_AUTO_HOSTING.zip ubuntu@आपका_PUBLIC_IP:~
# फिर Server में:
sudo apt-get install -y unzip && unzip OM_AUTO_HOSTING.zip && cd OM_AUTO_HOSTING
```
**तरीका 2:** अपने **Private** GitHub repo में Project डालें और Server पर `git clone` करें। ⚠️ `.env` कभी GitHub पर न डालें (`.gitignore` में है)।

### चरण E — Install
```bash
chmod +x install.sh start.sh
./install.sh
```
Script खुद पूछेगी: Hosting Bot का Token, आपका User ID, दोस्तों के ID। यह Docker, Python, Node, Sandbox image, Firewall और Auto-start (systemd) सब लगाती है (पहली बार 10–15 मिनट)।
अंत में अगर "permission denied (docker)" दिखे तो `exit` करके दोबारा SSH करें।

### चरण F — चलाकर देखें
Telegram में अपने Hosting Bot पर `/start`। Menu दिखेगा। फिर कोई `.py` फाइल भेजें।

> **SECRET_KEY बचाएँ:** `.env` में `SECRET_KEY=` वाली लाइन किसी सुरक्षित जगह (जैसे Password Manager) में रख लें। वह खो गई तो सेव किए Tokens वापस नहीं पढ़े जा सकेंगे।

---

## 5. इस्तेमाल कैसे करें

1. **Upload New Bot** → फाइल (Document) भेजें।
2. Bot **Analysis Report** दिखाएगा: Runtime, Entry, Framework, जरूरी Token/Keys, Commands, चेतावनियाँ।
3. Token चाहिए तो वह **इसी निजी चैट** में भेजें → संदेश अपने-आप मिट जाता है, Token Encrypted रहता है।
4. अनजान Library हो तो **अनुमति का बटन** आएगा (सुरक्षा के लिए)।
5. Install → Start → 20 सेकंड जाँच → सफल हो तो **Host** + Commands की सूची।
6. बाद में **My Hosted Bots** से Start/Stop/Restart/Logs/Status/Rename/Delete।

**जो मैं अपने-आप नहीं करता:** आपका Code नहीं बदलता। अपवाद: अगर Script में Token की जगह `"YOUR_TOKEN"` जैसा placeholder लिखा है और वह Environment से नहीं पढ़ती, तो सिर्फ़ उसी एक लाइन को बदलने की **आपसे अनुमति** माँगता हूँ (मूल फाइल `.om_backup/` में रहती है)।

**Owner:** `/addfriend ID`, `/removefriend ID`, `/users`, `/stats`, `/broadcast संदेश`, `/block ID`, `/unblock ID`, `/backupdb`, `/restartserver` (यह सिर्फ़ Hosting Bot को Restart करता है, पूरे VM को नहीं), या **Admin Panel** बटन।

**Limits (.env में बदल सकते हैं):** हर Bot 256 MB RAM, 0.5 CPU, 128 Processes, 500 MB Disk; हर User के 5 Bots; कुल 10 एक साथ; फाइल ≤ 20 MB (Telegram Bot की सीमा)।

---

## 6. सुरक्षा — क्या है और क्या नहीं

**लागू है:** हर Bot अलग Docker Container (non-root, सारी Linux Capabilities बंद, `no-new-privileges`, Read-only फाइल सिस्टम, सिर्फ़ अपना Project folder, CPU/RAM/PID Limit); Docker Socket किसी Bot को नहीं; Bots एक-दूसरे से Network पर बात नहीं कर सकते; Firewall नियम Host/Cloud-metadata तक रोकते हैं; ZIP में Zip-Slip/Symlink/Zip-Bomb सुरक्षा; Static Scan (खतरनाक पैटर्न मिलने पर Code चलता ही नहीं); Packages सिर्फ़ PyPI/npm नामों से (URL/Git नहीं), typosquat जाँच, npm में `--ignore-scripts`; Tokens Fernet से Encrypted; Logs/Reports में Secrets छिपे; हर Query में Owner की जाँच।

**सीमाएँ (ईमानदारी से):**
- Docker Isolation पक्की सुरक्षा नहीं है; Kernel की गंभीर कमज़ोरी में बच निकलना संभव है। इसलिए सिर्फ़ **भरोसेमंद दोस्तों** को दें।
- Static Scan हर खतरनाक Code नहीं पकड़ सकता।
- Bots को Internet मिलता है (Telegram के लिए जरूरी) — वे बाहर कुछ भी भेज सकते हैं।
- अगर आप Source में Token लिखवाने की अनुमति देते हैं, तो वह उस Project फाइल और उसके Backup में Plain दिखेगा (Backup फाइलें सिर्फ़ आपके पास 0600 अनुमति में हैं)।
- Disk Limit Container के अंदर लागू नहीं होती; Monitor हर 5 मिनट में जाँचकर Bot रोकता है।

---

## 7. कमांड जो काम आएँगे (Server पर)
```bash
sudo systemctl status om-hosting      # चल रहा है?
sudo journalctl -u om-hosting -f      # लाइव Logs
sudo systemctl restart om-hosting     # Restart
docker ps                             # चल रहे Bot Containers
cd ~/OM_AUTO_HOSTING && .venv/bin/python tests/run_tests.py   # टेस्ट
```

## 8. Troubleshooting
| समस्या | हल |
|---|---|
| Bot जवाब नहीं देता | `journalctl -u om-hosting -f` देखें; `.env` में `BOT_TOKEN`, `OWNER_ID` जाँचें; Owner ने Bot पर `/start` भेजा? |
| "Docker उपलब्ध नहीं" | `sudo systemctl start docker`; Logout/Login करें (docker group) |
| "Sandbox image नहीं मिली" | `sudo docker build -t om-sandbox:latest .` |
| Bot बार-बार बंद | Menu → Error Report; Missing Module/Token/Config का कारण वहीं लिखा होगा |
| `409 Conflict` | उसी Token से कोई और जगह भी Bot चल रहा है; उसे बंद करें |
| RAM खत्म / Bot "Killed" | `BOT_MEM_LIMIT_MB` बढ़ाएँ या Swap बनाएँ (install.sh पूछती है) |
| Token "गलत" बताता है | @BotFather से नया Token लें; पुराना Revoke हो चुका होगा |
| Tokens नहीं खुल रहे | `SECRET_KEY` बदल गई है; पुरानी Key वापस रखें |

---

## 9. क्या टेस्ट हुआ, क्या नहीं (सच)
`tests/run_tests.py` चलाने पर `TEST_REPORT.md` बनती है।

**टेस्ट हुआ (Sandbox में, असली Processes के साथ):** Python Script, ZIP Project, JavaScript Script, Syntax Error (Python+JS), Missing Config, Crash, Stop/Start, Auto-Restart, Server-Restart Recovery, दो Users का Separation और दूसरे के Bot पर पहुँचने की कोशिशें, अनजान User, Menu के सभी 22 बटन, सभी Commands और Owner Permissions, Token Encrypt/Redact/Delete-message, Token Patch (अनुमति के साथ/बिना), Zip-Slip/Symlink/Zip-Bomb, खतरनाक Code का Block, Backup/Restore, Firebase (Public/Permission Denied/Auth/गलत URL, Export) — **Firebase नकली (Mock) Server पर**।

**यहाँ टेस्ट नहीं हो सका (आपके Server पर पहली बार जाँचें):**
- **Docker असली में** (इस Sandbox में Docker नहीं था). इसलिए Container Flags बनते हैं यह जाँचा गया, पर Container चलाकर Isolation नहीं जाँची गई। `install.sh`, `docker-compose.yml`, `om-firewall.sh`, systemd Units सिर्फ़ Syntax-जाँचे गए, चलाए नहीं गए।
- **असली Telegram** (getMe/setMyCommands/Polling) — नकली जवाबों से टेस्ट हुआ। असली `pyTelegramBotAPI` की जगह नकली `telebot` से Handlers चलाए गए।
- **असली Libraries** (TeleBot, python-telegram-bot, aiogram, node-telegram-bot-api) के साथ चलना — टेस्ट में इनके नकली Stub थे; असली से Framework/Commands की पहचान का विश्लेषण-हिस्सा चेक हुआ, पर असली Library से चलना नहीं।
- **असली pip/npm Install** (Internet बंद था); सिर्फ़ "Install फेल होने पर साफ़ संदेश" जाँचा गया।
- **असली Firebase**, Oracle Cloud, Android/Termux पर पूरा Setup।

पहली बार चलाने के बाद एक छोटा Python Bot और एक TeleBot Bot Upload करके देखें; कुछ अटके तो Error Report/Logs यहाँ भेजें।
