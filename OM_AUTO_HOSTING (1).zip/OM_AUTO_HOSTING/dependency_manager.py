"""dependency_manager.py - Dependencies पहचानना, जाँचना और (Container के अंदर) Install करना.

सुरक्षा नियम:
- सिर्फ़ PyPI/npm के नाम (+version). URL, Git, Local path, -r/-e/--index-url जैसे options नहीं.
- Typosquat जैसे नाम और अनजान Import-नाम बिना आपकी अनुमति के Install नहीं होते.
- pip कभी Host पर नहीं चलता; हमेशा Sandbox Container में, हर Project के अपने venv (/work/.venv) में.
- npm हमेशा --ignore-scripts के साथ (install-time scripts नहीं चलतीं).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from file_analyzer import KNOWN_NPM, KNOWN_PIP
from security_manager import (PIP_NAME_FIX, check_npm_dependency, check_requirement_line, norm_pkg,
                              typosquat_suspect, POPULAR_NPM)

SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,44}$")
SAFE_NPM_NAME = re.compile(r"^(@[a-z0-9-~][a-z0-9-._~]*/)?[a-z0-9-~][a-z0-9-._~]*$")
REQ_FILE = ".om_requirements.txt"


@dataclass
class DepItem:
    name: str
    spec: str = ""
    source: str = ""          # requirements | import | pin | manual | package.json
    status: str = "ok"        # ok | confirm | blocked
    reason: str = ""
    marker: str = ""

    def line(self) -> str:
        return f"{self.name}{self.spec}{(' ' + self.marker) if self.marker else ''}"


@dataclass
class DepPlan:
    ecosystem: str
    items: list = field(default_factory=list)
    notes: list = field(default_factory=list)

    def ok_items(self):
        return [i for i in self.items if i.status == "ok"]

    def pending(self):
        return [i for i in self.items if i.status == "confirm"]

    def blocked(self):
        return [i for i in self.items if i.status == "blocked"]


@dataclass
class DepResult:
    ok: bool
    message: str = ""
    failed: list = field(default_factory=list)
    conflicts: list = field(default_factory=list)
    log: str = ""


class DependencyManager:
    def __init__(self, cfg, db, runner):
        self.cfg, self.db, self.runner = cfg, db, runner

    # ================================================================ Python
    def plan_python(self, bot: dict, analysis: dict) -> DepPlan:
        root = Path(bot["project_dir"])
        plan = DepPlan("pip")
        by_name: dict[str, DepItem] = {}

        def put(item: DepItem):
            key = norm_pkg(item.name)
            old = by_name.get(key)
            if old is None:
                by_name[key] = item
                return
            if old.spec and item.spec and old.spec != item.spec and item.source != "pin":
                plan.notes.append(f"Version टकराव: {item.name} के लिए '{old.spec}' और '{item.spec}' दोनों हैं; '{old.spec}' रखा गया.")
            elif item.source == "pin":
                by_name[key] = item
            elif not old.spec and item.spec:
                by_name[key] = item

        req = root / "requirements.txt"
        if req.exists():
            for line in req.read_text("utf-8", "ignore").splitlines():
                chk = check_requirement_line(line)
                if chk is None:
                    continue
                if chk.ok:
                    put(DepItem(chk.name, chk.spec, "requirements", "ok", marker=chk.marker))
                elif chk.suggestion and norm_pkg(chk.name) in PIP_NAME_FIX:
                    put(DepItem(chk.suggestion, chk.spec, "requirements", "ok",
                                f"नाम सुधारा गया: {chk.name} → {chk.suggestion}", marker=chk.marker))
                elif chk.suggestion:
                    put(DepItem(chk.name, chk.spec, "requirements", "confirm", chk.reason))
                else:
                    put(DepItem(chk.name, chk.spec, "requirements", "blocked", chk.reason))

        saved = {norm_pkg(r["name"]): r for r in self.db.list_deps(bot["id"]) if r["ecosystem"] == "pip"}
        for m in analysis.get("missing", []):
            pip = m["pip"]
            key = norm_pkg(pip)
            if key in by_name:
                continue
            if not SAFE_NAME.match(pip):
                by_name[key] = DepItem(pip, "", "import", "blocked", "नाम असुरक्षित/गलत लगा")
                continue
            sus = typosquat_suspect(pip)
            row = saved.get(key)
            if row and row["status"] in ("confirmed", "installed", "manual") and row["source"] in ("confirmed", "manual"):
                put(DepItem(pip, row.get("spec", ""), row["source"], "ok"))
            elif m.get("known") and not sus:
                put(DepItem(pip, "", "import", "ok", "Code के import से पहचाना"))
            else:
                reason = "अनजान package नाम (PyPI पर असली है या नहीं, आपको तय करना होगा)"
                if sus:
                    reason = f"'{pip}' नाम '{sus}' से मिलता-जुलता है (typosquat का खतरा)"
                put(DepItem(pip, "", "import", "confirm", reason))
        # User के जोड़े हुए/Confirm किए packages
        for key, row in saved.items():
            if row["source"] in ("manual", "confirmed") and key not in by_name:
                put(DepItem(row["name"], row.get("spec", ""), row["source"], "ok"))
        for pin in analysis.get("pins", []):
            put(DepItem(pin["name"], pin["spec"], "pin", "ok", pin["reason"]))
        plan.items = list(by_name.values())
        return plan

    def _record(self, bot_id, eco, plan: DepPlan, installed: bool, detail=""):
        for it in plan.items:
            st = {"ok": "installed" if installed else "detected", "confirm": "pending_confirm", "blocked": "blocked"}[it.status]
            if it.source in ("manual", "confirmed") and it.status == "ok":
                st = "installed" if installed else "confirmed"
            self.db.set_dep(bot_id, eco, it.name, it.spec, it.source, st, it.reason or detail)

    def install_python(self, bot: dict, plan: DepPlan, progress=None) -> DepResult:
        root = Path(bot["project_dir"])
        items = plan.ok_items()
        self._record(bot["id"], "pip", plan, False)
        if not items:
            return DepResult(True, "कोई अतिरिक्त Python package install करने की जरूरत नहीं.")
        if progress:
            progress("🐍 Python virtual environment बन रहा है…")
        v = self.runner.ensure_venv(root, timeout=180)
        if v.rc != 0:
            return DepResult(False, "Virtual environment नहीं बन सका.", log=v.text[-1500:])
        req_file = root / REQ_FILE
        req_file.write_text("\n".join(i.line() for i in items) + "\n", "utf-8")
        if progress:
            progress(f"📦 {len(items)} package install हो रहे हैं (Sandbox में)…")
        argv = self.runner.python_argv(root, "-m", "pip", "install", "--no-input", "--disable-pip-version-check",
                                       "--prefer-binary", "-r", f"/work/{REQ_FILE}" if self.runner.name == "docker" else str(req_file))
        r = self.runner.run_oneshot(root, argv, network=True, timeout=self.cfg.install_timeout_sec)
        if r.timed_out:
            return DepResult(False, "Install में बहुत समय लगा (Timeout).", log=r.text[-1500:])
        if r.rc != 0:
            failed, conflicts = self._parse_pip_failure(r.text)
            for f in failed:
                self.db.set_dep(bot["id"], "pip", f, "", "install", "failed", "PyPI पर नहीं मिला/version उपलब्ध नहीं")
            msg = "Install नहीं हो सका."
            if failed:
                msg += " ये नहीं मिले: " + ", ".join(failed)
            if conflicts:
                msg += " Version टकराव मिला."
            return DepResult(False, msg, failed, conflicts, r.text[-2000:])
        self._record(bot["id"], "pip", plan, True)
        # conflicts जाँच
        chk = self.runner.run_oneshot(root, self.runner.python_argv(root, "-m", "pip", "check"), network=False, timeout=60)
        conflicts = [l.strip() for l in chk.text.splitlines() if l.strip() and "No broken requirements" not in l] if chk.rc != 0 else []
        msg = f"{len(items)} package तैयार."
        if conflicts:
            msg += f" ⚠️ pip check में {len(conflicts)} टकराव दिखे."
        return DepResult(True, msg, [], conflicts, r.text[-800:])

    @staticmethod
    def _parse_pip_failure(text: str):
        failed = []
        for m in re.finditer(r"(?:No matching distribution found for|Could not find a version that satisfies the requirement)\s+([A-Za-z0-9._\-]+)", text):
            if m.group(1) not in failed:
                failed.append(m.group(1))
        conflicts = []
        if "ResolutionImpossible" in text or "conflicting dependencies" in text.lower():
            conflicts = [l.strip() for l in text.splitlines() if "conflict" in l.lower() or "depends on" in l.lower()][:6]
        return failed, conflicts

    def pip_check(self, bot: dict) -> list[str]:
        root = Path(bot["project_dir"])
        r = self.runner.run_oneshot(root, self.runner.python_argv(root, "-m", "pip", "check"), network=False, timeout=60)
        if r.rc == 0:
            return []
        return [l.strip() for l in r.text.splitlines() if l.strip()][:15]

    # ================================================================== Node
    def plan_node(self, bot: dict, analysis: dict) -> DepPlan:
        root = Path(bot["project_dir"])
        plan = DepPlan("npm")
        declared = {}
        pj = root / "package.json"
        if pj.exists():
            try:
                data = json.loads(pj.read_text("utf-8", "ignore"))
                declared = dict(data.get("dependencies") or {})
            except ValueError:
                plan.items.append(DepItem("package.json", "", "package.json", "blocked", "package.json का JSON गलत है"))
        for name, spec in declared.items():
            chk = check_npm_dependency(name, str(spec))
            if chk.ok:
                plan.items.append(DepItem(name, str(spec), "package.json", "ok"))
            elif chk.suggestion:
                plan.items.append(DepItem(name, str(spec), "package.json", "confirm", chk.reason))
            else:
                plan.items.append(DepItem(name, str(spec), "package.json", "blocked", chk.reason))
        saved = {r["name"]: r for r in self.db.list_deps(bot["id"]) if r["ecosystem"] == "npm"}
        have = {i.name for i in plan.items}
        for m in analysis.get("missing", []):
            n = m["pip"]
            if n in have or not SAFE_NPM_NAME.match(n):
                continue
            sus = typosquat_suspect(n, POPULAR_NPM)
            row = saved.get(n)
            if row and row["source"] in ("confirmed", "manual"):
                plan.items.append(DepItem(n, "", row["source"], "ok"))
            elif m.get("known") and not sus:
                plan.items.append(DepItem(n, "", "import", "ok", "Code के require/import से पहचाना"))
            else:
                plan.items.append(DepItem(n, "", "import", "confirm", "अनजान npm package नाम" if not sus else f"'{n}' नाम '{sus}' से मिलता-जुलता है"))
        for n, row in saved.items():
            if row["source"] in ("manual", "confirmed") and n not in {i.name for i in plan.items}:
                plan.items.append(DepItem(n, "", row["source"], "ok"))
        return plan

    def install_node(self, bot: dict, plan: DepPlan, progress=None) -> DepResult:
        root = Path(bot["project_dir"])
        self._record(bot["id"], "npm", plan, False)
        if plan.blocked():
            return DepResult(False, "package.json में असुरक्षित/गलत dependency: " + "; ".join(f"{i.name} ({i.reason})" for i in plan.blocked()))
        base_flags = ["--ignore-scripts", "--no-audit", "--no-fund", "--no-progress"]
        # ZIP में पहले से मौजूद node_modules वाले packages दोबारा Install नहीं होते
        have = lambda i: (root / "node_modules" / i.name).exists()
        pj_items = [i for i in plan.ok_items() if i.source == "package.json" and not have(i)]
        extra = [i for i in plan.ok_items() if i.source != "package.json" and not have(i)]
        log = ""
        if pj_items:
            if progress:
                progress("🟠 npm install चल रहा है (scripts बंद)…")
            r = self.runner.run_oneshot(root, ["npm", "install", "--omit=dev", *base_flags], network=True, timeout=self.cfg.install_timeout_sec)
            log += r.text
            if r.rc != 0:
                return DepResult(False, "npm install नहीं हो सका.", log=r.text[-2000:])
        if extra:
            if progress:
                progress("🟠 अतिरिक्त npm packages: " + ", ".join(i.name for i in extra))
            r = self.runner.run_oneshot(root, ["npm", "install", "--no-save", *base_flags, *[i.name + (f"@{i.spec}" if i.spec else "") for i in extra]],
                                        network=True, timeout=self.cfg.install_timeout_sec)
            log += r.text
            if r.rc != 0:
                return DepResult(False, "अतिरिक्त npm packages install नहीं हुए.", log=r.text[-2000:])
        if not pj_items and not extra:
            self._record(bot["id"], "npm", plan, True)
            return DepResult(True, "कोई npm package install करने की जरूरत नहीं.")
        self._record(bot["id"], "npm", plan, True)
        return DepResult(True, f"{len(pj_items) + len(extra)} npm package तैयार (install scripts बंद रखी गईं).", log=log[-800:])

    # ============================================================== manual
    def check_manual_name(self, runtime: str, name: str) -> tuple[bool, str]:
        name = (name or "").strip()
        if runtime == "node":
            if not SAFE_NPM_NAME.match(name):
                return False, "npm package का नाम गलत है."
            sus = typosquat_suspect(name, POPULAR_NPM)
        else:
            if not SAFE_NAME.match(name):
                return False, "Package का नाम गलत है (सिर्फ़ अक्षर, अंक, - _ . चलते हैं; URL/Git नहीं)."
            if norm_pkg(name) in PIP_NAME_FIX and norm_pkg(name) in ("telebot", "telegram", "cv2", "pil", "bs4", "sklearn", "yaml", "dotenv"):
                return False, f"pip पर सही नाम है: {PIP_NAME_FIX[norm_pkg(name)]}"
            sus = typosquat_suspect(name)
        if sus:
            return False, f"'{name}' नाम '{sus}' से मिलता-जुलता है (typosquat का खतरा). क्या आपका मतलब '{sus}' था?"
        return True, "ठीक है."

    def add_manual(self, bot: dict, name: str, source="manual"):
        eco = "npm" if bot["runtime"] == "node" else "pip"
        self.db.set_dep(bot["id"], eco, name, "", source, "confirmed", "")
