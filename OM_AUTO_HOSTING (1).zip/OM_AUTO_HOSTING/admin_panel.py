"""admin_panel.py - सिर्फ़ Owner के लिए Admin Panel और Owner Commands."""
from __future__ import annotations

import logging
import time

import keyboards as K
import server_monitor
from access_control import require_owner, require_allowed
from logs_manager import tail_system_log
from utils import esc, human_size, pre

log = logging.getLogger("om.admin")


def stats_text(ctx) -> str:
    c = ctx.db.counts()
    return ("👑 <b>Admin Stats</b>\n"
            f"👥 Total Users: {c['users']} (दोस्त: {c['friends']}, Blocked: {c['blocked']})\n"
            f"🟢 Active Users (24 घंटे): {ctx.db.active_users(24)}\n"
            f"📁 Uploaded Files: {c['files']}\n"
            f"🤖 Hosted Bots: {c['bots']} | चल रहे: {c['running']} | बंद: {c['stopped']} | Failed: {c['failed']}\n"
            f"🔒 Hosting Lock: {'चालू' if ctx.db.get_setting('locked') == '1' else 'बंद'}\n" + snapshot_text(ctx))


def users_text(ctx) -> str:
    L = ["👥 <b>Users</b>"]
    for u in ctx.db.list_users():
        role = "👑" if ctx.access.is_owner(u["user_id"]) else ("🤝" if ctx.db.is_friend(u["user_id"]) else "🚫")
        blk = " ⛔Blocked" if u["is_blocked"] else ""
        nbots = len(ctx.db.list_bots(u["user_id"]))
        L.append(f"{role} <code>{u['user_id']}</code> {esc(u['first_name'] or '')} @{esc(u['username'] or '-')} — Bots: {nbots}{blk}")
    fr = [f["user_id"] for f in ctx.db.list_friends()]
    L.append(f"\nAllowed दोस्त: {', '.join(map(str, fr)) or 'कोई नहीं'}")
    return "\n".join(L)


def bots_text_and_buttons(ctx):
    bots = ctx.db.list_bots()
    if not bots:
        return "अभी कोई Hosted Bot नहीं.", None
    L = ["🤖 <b>सभी Hosted Bots</b>"]
    btns = []
    for b in bots[:30]:
        L.append(f"#{b['id']} {esc(b['name'])} — User <code>{b['owner_id']}</code> — {esc(b['status'])}")
        if b["status"] == "running":
            btns.append([(f"⏹ #{b['id']} {b['name'][:18]} रोकें", f"adm:stop:{b['id']}")])
    return "\n".join(L), btns or None


def _int(text):
    try:
        return int((text or "").strip())
    except ValueError:
        return None


def add_friend(ctx, owner_id, uid) -> str:
    if uid is None or uid <= 0:
        return "❌ सही Telegram User ID (सिर्फ़ नंबर) दें."
    if ctx.access.is_owner(uid):
        return "आप तो Owner हैं, पहले से Access है."
    ctx.db.add_friend(uid, owner_id)
    ctx.db.set_blocked(uid, False)
    return f"✅ <code>{uid}</code> को दोस्त के रूप में जोड़ दिया (समान Premium Access, कोई Approval नहीं). उन्हें Hosting Bot पर /start भेजने को कहें."


def _stop_all_bots_of(ctx, uid):
    n = 0
    for b in ctx.db.list_bots(uid):
        if b["status"] == "running" or ctx.runner.is_running(b["id"]):
            ctx.manager.stop_bot(ctx.cfg.owner_id, b["id"])
            n += 1
    return n


def remove_friend(ctx, uid) -> str:
    if uid is None:
        return "❌ सही User ID दें."
    if not ctx.db.remove_friend(uid):
        return "यह ID दोस्तों की सूची में नहीं है."
    n = _stop_all_bots_of(ctx, uid)
    return f"✅ <code>{uid}</code> को हटा दिया. उनके {n} चलते Bots रोक दिए गए (Data सुरक्षित है; दोबारा जोड़ने पर लौट आएगा)."


def block(ctx, uid) -> str:
    if uid is None:
        return "❌ सही User ID दें."
    if ctx.access.is_owner(uid):
        return "Owner को Block नहीं कर सकते."
    ctx.db.set_blocked(uid, True)
    n = _stop_all_bots_of(ctx, uid)
    return f"⛔ <code>{uid}</code> Block हुआ. उनके {n} चलते Bots रोक दिए गए."


def unblock(ctx, uid) -> str:
    if uid is None:
        return "❌ सही User ID दें."
    ctx.db.set_blocked(uid, False)
    return f"✅ <code>{uid}</code> Unblock हुआ."


def broadcast(ctx, text) -> str:
    ids = {ctx.cfg.owner_id} | {f["user_id"] for f in ctx.db.list_friends()}
    ids = [i for i in ids if not ctx.db.is_blocked(i)]
    ok = fail = 0
    for uid in ids:
        try:
            ctx.send(uid, "📢 <b>Owner का संदेश</b>\n" + esc(text))
            ok += 1
        except Exception:
            fail += 1
        time.sleep(0.05)
    return f"📢 भेजा: {ok} | नहीं पहुँचा: {fail}"


def toggle_lock(ctx) -> str:
    new = "0" if ctx.db.get_setting("locked") == "1" else "1"
    ctx.db.set_setting("locked", new)
    return "🔒 Hosting Lock हो गई (सिर्फ़ Owner चला सकता है)." if new == "1" else "🔓 Lock खुल गई."


def snapshot_text(ctx) -> str:
    sn = getattr(ctx, "snapshotter", None)
    if sn is None:
        return "💾 Snapshot: बंद (Render Mode नहीं)."
    import time as _t
    ago = "कभी नहीं" if not sn.last_ok_ts else f"{int((_t.time() - sn.last_ok_ts) // 60)} मिनट पहले"
    return f"💾 GitHub Snapshot: आख़िरी सफल: {ago}" + (f" | ⚠️ {esc(sn.last_error)}" if sn.last_error else "")


def health_text(ctx) -> str:
    h = server_monitor.health(ctx.cfg, ctx.db, ctx.runner)
    L = [("🟢 <b>Server Health: ठीक</b>" if h["ok"] else "🟠 <b>Server Health: ध्यान दें</b>"),
         f"CPU {h['cpu']:.0f}% | RAM {h['ram']:.0f}% | Disk {h['disk']:.0f}%"]
    L += ["• " + esc(p) for p in h["problems"]]
    L.append(snapshot_text(ctx))
    return "\n".join(L)


def request_restart(ctx):
    ctx.restart_requested = True
    try:
        ctx.tg.stop_polling()
    except Exception:
        pass


def register(ctx):
    tg = ctx.tg
    owner_only = lambda fn: require_allowed(ctx)(require_owner(ctx)(fn))

    @tg.message_handler(commands=["addfriend"])
    @owner_only
    def _addf(m):
        arg = (m.text or "").split(maxsplit=1)[1] if len((m.text or "").split()) > 1 else ""
        ctx.send(m.from_user.id, add_friend(ctx, m.from_user.id, _int(arg)) if arg else "उपयोग: /addfriend 123456789")

    @tg.message_handler(commands=["removefriend"])
    @owner_only
    def _remf(m):
        arg = (m.text or "").split(maxsplit=1)[1] if len((m.text or "").split()) > 1 else ""
        ctx.send(m.from_user.id, remove_friend(ctx, _int(arg)) if arg else "उपयोग: /removefriend 123456789")

    @tg.message_handler(commands=["users"])
    @owner_only
    def _users(m):
        ctx.send(m.from_user.id, users_text(ctx))

    @tg.message_handler(commands=["stats"])
    @owner_only
    def _stats(m):
        ctx.send(m.from_user.id, stats_text(ctx))

    @tg.message_handler(commands=["broadcast"])
    @owner_only
    def _bc(m):
        parts = (m.text or "").split(maxsplit=1)
        ctx.send(m.from_user.id, broadcast(ctx, parts[1]) if len(parts) > 1 else "उपयोग: /broadcast आपका संदेश")

    @tg.message_handler(commands=["block"])
    @owner_only
    def _blk(m):
        arg = (m.text or "").split(maxsplit=1)[1] if len((m.text or "").split()) > 1 else ""
        ctx.send(m.from_user.id, block(ctx, _int(arg)) if arg else "उपयोग: /block 123456789")

    @tg.message_handler(commands=["unblock"])
    @owner_only
    def _unblk(m):
        arg = (m.text or "").split(maxsplit=1)[1] if len((m.text or "").split()) > 1 else ""
        ctx.send(m.from_user.id, unblock(ctx, _int(arg)) if arg else "उपयोग: /unblock 123456789")

    @tg.message_handler(commands=["restartserver"])
    @owner_only
    def _rs(m):
        ctx.send(m.from_user.id, "⚠️ यह Hosting Bot (Manager) को Restart करेगा, पूरे VM को नहीं. चलते Hosted Bots Containers में चलते रहेंगे.",
                 K.confirm_buttons("adm:restart_yes"))

    @tg.message_handler(commands=["backupdb"])
    @owner_only
    def _bdb(m):
        _do_db_backup(ctx, m.from_user.id)


def _do_db_backup(ctx, uid):
    b = ctx.backups.backup_db(note="manual")
    ctx.send(uid, f"🗃 Database Backup बन गया ({human_size(b['size'])}).")
    try:
        with open(b["path"], "rb") as f:
            ctx.tg.send_document(uid, f, caption="DB Backup (Tokens Encrypted हैं; SECRET_KEY अलग संभालकर रखें)")
    except Exception as e:
        log.warning("db backup send failed: %s", e)


def on_callback(ctx, call) -> bool:
    """adm:* callbacks. True = संभाला."""
    uid = call.from_user.id
    data = call.data
    if not data.startswith("adm:"):
        return False
    if not ctx.access.is_owner(uid):
        ctx.send(uid, "🔒 सिर्फ़ Owner के लिए.")
        return True
    parts = data.split(":")
    act = parts[1]
    if act == "stats":
        ctx.send(uid, stats_text(ctx))
    elif act == "users":
        ctx.send(uid, users_text(ctx))
    elif act in ("addf", "remf", "block", "unblock", "bc"):
        prompts = {"addf": "जिस दोस्त को जोड़ना है उसका Telegram User ID भेजें.", "remf": "जिस दोस्त को हटाना है उसका User ID भेजें.",
                   "block": "Block करने के लिए User ID भेजें.", "unblock": "Unblock करने के लिए User ID भेजें.",
                   "bc": "सभी को भेजने वाला संदेश लिखें."}
        ctx.db.set_state(uid, f"adm_{act}", {})
        ctx.send(uid, "✍️ " + prompts[act])
    elif act == "lock":
        ctx.send(uid, toggle_lock(ctx))
    elif act == "bots":
        t, b = bots_text_and_buttons(ctx)
        ctx.send(uid, t, b)
    elif act == "stop" and len(parts) > 2:
        try:
            ctx.send(uid, ctx.manager.stop_bot(uid, int(parts[2])))
        except Exception as e:
            ctx.send(uid, "❌ " + esc(str(e)))
    elif act == "snap":
        sn = getattr(ctx, "snapshotter", None)
        if sn is None:
            ctx.send(uid, "Snapshot सिर्फ़ Render Mode में है.")
        else:
            r = sn.snapshot_now(force=True)
            ctx.send(uid, {"uploaded": "✅ Snapshot GitHub पर सुरक्षित हो गया.", "skipped": "⏳ Restore पूरा नहीं हुआ, इसलिए Upload रोका (खाली Data से असली Snapshot न मिटे).",
                           "error": "❌ Snapshot नहीं गया: " + esc(sn.last_error)}.get(r, r))
    elif act == "health":
        ctx.send(uid, health_text(ctx))
    elif act == "dbbk":
        _do_db_backup(ctx, uid)
    elif act == "dbrs":
        rows = ctx.backups.list_backups(0, "db")
        if not rows:
            ctx.send(uid, "कोई DB Backup नहीं है. पहले 'DB Backup' बनाएँ.")
        else:
            ctx.send(uid, "कौन सा Backup Restore करें? (Restore के बाद Hosting Bot Restart होगा)",
                     [[(f"#{r['id']} {r['created_at']} ({human_size(r['size'])})", f"adm:dbrs1:{r['id']}")] for r in rows[:8]])
    elif act == "dbrs1":
        ctx.send(uid, f"⚠️ Backup #{parts[2]} से Database बदल दिया जाएगा. पक्का?", K.confirm_buttons(f"adm:dbrs2:{parts[2]}"))
    elif act == "dbrs2":
        try:
            msg = ctx.backups.restore_db(int(parts[2]))
            ctx.send(uid, "✅ " + esc(msg))
            request_restart(ctx)
        except Exception as e:
            ctx.send(uid, "❌ " + esc(str(e)))
    elif act == "syslog":
        ctx.send(uid, "📜 <b>System Logs</b>\n" + pre(tail_system_log(ctx.cfg, 40) or "(खाली)", 3400))
    elif act == "restart":
        ctx.send(uid, "⚠️ Hosting Bot (Manager) Restart करूँ? चलते Hosted Bots चलते रहेंगे.", K.confirm_buttons("adm:restart_yes"))
    elif act == "restart_yes":
        ctx.send(uid, "🔁 Hosting Bot Restart हो रहा है… कुछ सेकंड में वापस आऊँगा.")
        request_restart(ctx)
    return True
