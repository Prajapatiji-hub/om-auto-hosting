"""config.py - सारी Settings सिर्फ .env / Environment से आती हैं.

Token, Secret या Owner ID कभी source code में नहीं लिखे जाते.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

try:  # python-dotenv है तो .env अपने-आप पढ़ो
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None

BASE_DIR = Path(__file__).resolve().parent
TOKEN_FORMAT = re.compile(r"^\d{6,12}:[A-Za-z0-9_-]{30,}$")


def fernet_from_secret(secret: str):
    """SECRET_KEY सही Fernet key हो तो वही; वरना किसी भी लंबे Secret से पक्की key बनती है (Render का generateValue चलता है)."""
    import base64
    import hashlib
    from cryptography.fernet import Fernet
    try:
        return Fernet(secret.encode())
    except Exception:
        key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest())
        return Fernet(key)


class ConfigError(Exception):
    """Configuration गलत या अधूरी है."""


def _int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        raise ConfigError(f"{name} में सिर्फ़ नंबर होना चाहिए (मिला: {raw!r})")


def _float(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        raise ConfigError(f"{name} में सिर्फ़ नंबर होना चाहिए (मिला: {raw!r})")


def _bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on", "haan", "ha")


def parse_ids(value: str) -> set[int]:
    ids: set[int] = set()
    for part in re.split(r"[,\s;]+", value or ""):
        if not part:
            continue
        if not part.lstrip("-").isdigit():
            raise ConfigError(f"Telegram User ID सिर्फ़ नंबर होना चाहिए (मिला: {part!r})")
        ids.add(int(part))
    return ids


@dataclass
class Config:
    bot_token: str = ""
    owner_id: int = 0
    friend_ids: set = field(default_factory=set)
    owner_username: str = ""
    data_dir: Path = BASE_DIR / "data"
    secret_key: str = ""

    runner_mode: str = "docker"          # docker | local (local सिर्फ़ टेस्ट के लिए)
    allow_unsafe_local: bool = False
    sandbox_image: str = "om-sandbox:latest"
    sandbox_network: str = "om_net"

    mem_limit_mb: int = 256
    cpu_limit: float = 0.5
    pids_limit: int = 128
    disk_limit_mb: int = 500
    max_upload_mb: int = 20
    max_zip_uncompressed_mb: int = 100
    max_zip_files: int = 2000
    startup_observe_sec: int = 20
    install_timeout_sec: int = 600
    task_timeout_sec: int = 60
    max_bots_per_user: int = 5
    max_running_total: int = 10

    restart_max_in_window: int = 5
    restart_window_sec: int = 600
    monitor_interval_sec: int = 10
    auto_backup_hours: int = 24
    backup_keep: int = 10
    health_port: int = 0                 # 0 = बंद (Flask Keep-Alive की जरूरत नहीं)
    log_level: str = "INFO"

    # ---- Render (Free, बिना Docker) Mode ----
    render_mode: bool = False            # Render अपने-आप RENDER=true सेट करता है
    allow_process_runner: bool = False   # Render के बाहर 'process' Runner टेस्ट के लिए
    github_data_token: str = ""          # सिर्फ़ om-hosting-data repo का Fine-grained token
    data_repo: str = ""                  # "username/om-hosting-data"
    data_branch: str = "main"
    snapshot_interval_sec: int = 600
    allow_no_persistence: bool = False
    fsize_limit_mb: int = 100            # हर Bot की एक फाइल की अधिकतम साइज़ (ulimit -f)
    port: int = 10000
    bot_uid_base: int = 20000

    @classmethod
    def from_env(cls, load_env_file: bool = True) -> "Config":
        if load_env_file and load_dotenv is not None:
            load_dotenv(BASE_DIR / ".env")
        c = cls()
        c.bot_token = os.environ.get("BOT_TOKEN", "").strip()
        c.owner_id = _int("OWNER_ID", 0)
        c.friend_ids = parse_ids(os.environ.get("FRIEND_IDS", ""))
        c.owner_username = os.environ.get("OWNER_USERNAME", "").strip().lstrip("@")
        c.data_dir = Path(os.environ.get("DATA_DIR", "") or (BASE_DIR / "data")).resolve()
        c.secret_key = os.environ.get("SECRET_KEY", "").strip()
        c.runner_mode = (os.environ.get("RUNNER_MODE", "docker") or "docker").strip().lower()
        c.allow_unsafe_local = _bool("ALLOW_UNSAFE_LOCAL_RUNNER", False)
        c.sandbox_image = os.environ.get("SANDBOX_IMAGE", c.sandbox_image).strip()
        c.sandbox_network = os.environ.get("SANDBOX_NETWORK", c.sandbox_network).strip()
        c.mem_limit_mb = _int("BOT_MEM_LIMIT_MB", c.mem_limit_mb)
        c.cpu_limit = _float("BOT_CPU_LIMIT", c.cpu_limit)
        c.pids_limit = _int("BOT_PIDS_LIMIT", c.pids_limit)
        c.disk_limit_mb = _int("BOT_DISK_LIMIT_MB", c.disk_limit_mb)
        c.max_upload_mb = _int("MAX_UPLOAD_MB", c.max_upload_mb)
        c.max_zip_uncompressed_mb = _int("MAX_ZIP_UNCOMPRESSED_MB", c.max_zip_uncompressed_mb)
        c.max_zip_files = _int("MAX_ZIP_FILES", c.max_zip_files)
        c.startup_observe_sec = _int("STARTUP_OBSERVE_SEC", c.startup_observe_sec)
        c.install_timeout_sec = _int("INSTALL_TIMEOUT_SEC", c.install_timeout_sec)
        c.task_timeout_sec = _int("TASK_TIMEOUT_SEC", c.task_timeout_sec)
        c.max_bots_per_user = _int("MAX_BOTS_PER_USER", c.max_bots_per_user)
        c.max_running_total = _int("MAX_RUNNING_TOTAL", c.max_running_total)
        c.restart_max_in_window = _int("RESTART_MAX_IN_WINDOW", c.restart_max_in_window)
        c.restart_window_sec = _int("RESTART_WINDOW_SEC", c.restart_window_sec)
        c.monitor_interval_sec = _int("MONITOR_INTERVAL_SEC", c.monitor_interval_sec)
        c.auto_backup_hours = _int("AUTO_BACKUP_HOURS", c.auto_backup_hours)
        c.backup_keep = _int("BACKUP_KEEP", c.backup_keep)
        c.health_port = _int("HEALTH_PORT", c.health_port)
        c.log_level = os.environ.get("LOG_LEVEL", "INFO").strip().upper()
        c.render_mode = os.environ.get("RENDER", "").strip().lower() == "true"
        c.allow_process_runner = _bool("ALLOW_PROCESS_RUNNER", False)
        c.github_data_token = os.environ.get("GITHUB_DATA_TOKEN", "").strip()
        c.data_repo = os.environ.get("DATA_REPO", "").strip()
        c.data_branch = os.environ.get("DATA_BRANCH", "main").strip() or "main"
        c.snapshot_interval_sec = _int("SNAPSHOT_INTERVAL_SEC", c.snapshot_interval_sec)
        c.allow_no_persistence = _bool("ALLOW_NO_PERSISTENCE", False)
        c.fsize_limit_mb = _int("FSIZE_LIMIT_MB", c.fsize_limit_mb)
        c.port = _int("PORT", c.port)
        if c.render_mode and not os.environ.get("RUNNER_MODE", "").strip():
            c.runner_mode = "process"
        return c

    # --- paths ---
    @property
    def db_path(self) -> Path:
        return self.data_dir / "om.db"

    @property
    def users_dir(self) -> Path:
        return self.data_dir / "users"

    @property
    def backups_dir(self) -> Path:
        return self.data_dir / "backups"

    @property
    def logs_dir(self) -> Path:
        return self.data_dir / "logs"

    def validate(self) -> list[str]:
        """Problem की list लौटाता है (खाली = सब ठीक)."""
        p: list[str] = []
        if not self.bot_token:
            p.append("BOT_TOKEN खाली है - @BotFather से मिला Hosting Bot का Token .env में डालें.")
        elif not TOKEN_FORMAT.match(self.bot_token):
            p.append("BOT_TOKEN का format गलत लग रहा है (123456789:ABC... जैसा होना चाहिए).")
        if self.owner_id <= 0:
            p.append("OWNER_ID खाली/गलत है - अपना Telegram User ID डालें (@userinfobot से मिलता है).")
        if self.secret_key and len(self.secret_key) < 16:
            p.append("SECRET_KEY बहुत छोटी है (कम से कम 16 अक्षर).")
        if not self.secret_key:
            p.append("SECRET_KEY खाली है - install.sh इसे अपने-आप बनाता है; या `python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\"` चलाएँ.")
        if self.runner_mode not in ("docker", "local", "process"):
            p.append("RUNNER_MODE सिर्फ़ docker, process (Render) या local हो सकता है.")
        if self.runner_mode == "process":
            if not (self.render_mode or self.allow_process_runner):
                p.append("RUNNER_MODE=process सिर्फ़ Render पर (RENDER=true) चलता है; टेस्ट के लिए ALLOW_PROCESS_RUNNER=1 लगाएँ.")
            if self.render_mode and not self.allow_no_persistence:
                if not self.github_data_token:
                    p.append("GITHUB_DATA_TOKEN खाली है - Render पर files हर Restart में मिट जाती हैं, इसलिए data repo का token जरूरी है.")
                if not re.match(r"^[\w.-]+/[\w.-]+$", self.data_repo or ""):
                    p.append("DATA_REPO 'username/om-hosting-data' जैसा होना चाहिए.")
        if self.runner_mode == "local" and not self.allow_unsafe_local:
            p.append("RUNNER_MODE=local असुरक्षित है (कोई Isolation नहीं). सिर्फ़ टेस्ट के लिए ALLOW_UNSAFE_LOCAL_RUNNER=1 लगाएँ.")
        if self.runner_mode == "docker" and hasattr(os, "getuid") and os.getuid() == 0:
            # root पर चलाना allowed है पर चेतावनी; runner containers को non-root uid पर चलाता है
            pass
        return p

    def ensure_dirs(self) -> None:
        for d in (self.data_dir, self.users_dir, self.backups_dir, self.logs_dir):
            d.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(d, 0o700)
            except OSError:
                pass


_current: Config | None = None


def get_config() -> Config:
    global _current
    if _current is None:
        _current = Config.from_env()
    return _current


def set_config(c: Config | None) -> None:
    """Tests के लिए: config बदलना."""
    global _current
    _current = c
