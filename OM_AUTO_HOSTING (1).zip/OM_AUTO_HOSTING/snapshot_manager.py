"""snapshot_manager.py - Data folder को Encrypted Snapshot में बदलना और वापस खोलना (Render Mode)."""
from __future__ import annotations

import hashlib
import io
import logging
import os
import shutil
import sqlite3
import tarfile
import tempfile
import threading
import time
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

from config import fernet_from_secret
from github_store import GithubStore, StoreError

log = logging.getLogger("om.snapshot")
SKIP_DIRS = {".venv", "node_modules", "__pycache__", ".git", "tmp", "logs", "backups", "local_runtime", "uploads", ".npm", ".cache"}
MAX_MEMBERS = 50000


def _filter_factory():
    def f(ti: tarfile.TarInfo):
        ti.mtime = 0
        ti.uid = ti.gid = 0
        ti.uname = ti.gname = ""
        return ti
    return f


def pack(cfg, db) -> tuple[bytes, str]:
    """(Encrypted bytes, plaintext-hash). Hash से पता चलता है कुछ बदला या नहीं."""
    data_dir = Path(cfg.data_dir)
    tmp = Path(tempfile.mkdtemp(prefix="snap_", dir=str(data_dir / "tmp") if (data_dir / "tmp").exists() else None))
    try:
        dbcopy = tmp / "om.db"
        db.backup_to(dbcopy)
        # DB में बदलते रहने वाले सिर्फ़ 'आख़िरी बार देखा' जैसे fields हैश में असर न डालें - पूरे DB का hash लेते हैं, पर
        # Monitor अब बार-बार नहीं लिखता.
        buf = io.BytesIO()
        flt = _filter_factory()
        with tarfile.open(fileobj=buf, mode="w:gz", compresslevel=6) as tf:
            tf.add(dbcopy, arcname="om.db", filter=flt)
            users = data_dir / "users"
            if users.exists():
                for dp, dns, fns in os.walk(users):
                    dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
                    for fn in sorted(fns):
                        full = Path(dp) / fn
                        if full.is_symlink() or not full.is_file():
                            continue
                        rel = full.relative_to(data_dir)
                        tf.add(full, arcname=str(Path("data") / rel), filter=flt)
        raw = buf.getvalue()
        key = fernet_from_secret(cfg.secret_key)
        return key.encrypt(raw), hashlib.sha256(raw).hexdigest()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def unpack(cfg, blob: bytes) -> int:
    """Snapshot को data_dir में खोलना (सुरक्षित). लौटाता है: files की संख्या."""
    try:
        raw = fernet_from_secret(cfg.secret_key).decrypt(blob)
    except InvalidToken:
        raise StoreError("Snapshot खुल नहीं रहा: SECRET_KEY बदल गई है (पुरानी Key वापस लगाएँ).")
    data_dir = Path(cfg.data_dir).resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    n = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tf:
        members = tf.getmembers()
        if len(members) > MAX_MEMBERS:
            raise StoreError("Snapshot में बहुत ज़्यादा files हैं.")
        for m in members:
            name = m.name
            if m.issym() or m.islnk() or m.isdev() or name.startswith("/") or ".." in Path(name).parts:
                raise StoreError(f"Snapshot में असुरक्षित entry: {name[:60]}")
            if name == "om.db":
                target = data_dir / "om.db"
            elif name.startswith("data/"):
                target = (data_dir / name[5:]).resolve()
            else:
                continue
            if target != data_dir and data_dir not in target.parents:
                raise StoreError("Snapshot path बाहर जा रहा है.")
            if m.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            if not m.isfile():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with tf.extractfile(m) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)
            os.chmod(target, 0o600 if name == "om.db" else 0o644)
            n += 1
    for ext in ("-wal", "-shm"):
        Path(str(data_dir / "om.db") + ext).unlink(missing_ok=True)
    # DB में पुराने absolute path हो सकते हैं - इस Server के हिसाब से ठीक करो
    con = sqlite3.connect(str(data_dir / "om.db"))
    try:
        for bid, owner in con.execute("SELECT id, owner_id FROM hosted_bots").fetchall():
            con.execute("UPDATE hosted_bots SET project_dir=? WHERE id=?",
                        (str(data_dir / "users" / str(owner) / "bots" / str(bid) / "project"), bid))
        con.execute("UPDATE bot_status SET pid=NULL, container_name=NULL")
        con.commit()
    finally:
        con.close()
    return n


class Snapshotter(threading.Thread):
    """हर कुछ मिनट में (बदलाव हो तो) Snapshot GitHub पर भेजता है."""

    def __init__(self, cfg, db, store: GithubStore):
        super().__init__(daemon=True, name="snapshotter")
        self.cfg, self.db, self.store = cfg, db, store
        self.last_hash = None
        self.restored_ok = False       # जब तक Restore की स्थिति साफ़ न हो, Upload नहीं (खाली Data से असली Snapshot न मिटे)
        self.last_error = ""
        self.last_ok_ts = 0.0
        self._stop_evt = threading.Event()
        self._kick = threading.Event()
        self._lock = threading.Lock()

    def kick(self):
        """कुछ ज़रूरी बदला (नया Bot/Token आदि): जल्दी (≈20 सेकंड में) Snapshot लो."""
        self._kick.set()

    def restore(self, retries=4) -> str:
        """'restored' | 'empty' (पहली बार) | 'error'."""
        delay = 2
        for i in range(retries):
            try:
                blob = self.store.get_snapshot()
                if blob is None:
                    self.restored_ok = True
                    return "empty"
                n = unpack(self.cfg, blob)
                self.restored_ok = True
                log.info("Snapshot Restore हुआ (%s files)", n)
                return "restored"
            except StoreError as e:
                self.last_error = str(e)
                log.warning("Restore कोशिश %s असफल: %s", i + 1, e)
                if "SECRET_KEY" in str(e) or "Token" in str(e):
                    break
                time.sleep(delay)
                delay *= 2
        return "error"

    def snapshot_now(self, force=False) -> str:
        """'uploaded' | 'unchanged' | 'skipped' | 'error'."""
        with self._lock:
            if not self.restored_ok:
                return "skipped"
            try:
                blob, h = pack(self.cfg, self.db)
                if not force and h == self.last_hash:
                    return "unchanged"
                self.store.put_snapshot(blob, "snapshot")
                self.last_hash = h
                self.last_ok_ts = time.time()
                self.last_error = ""
                return "uploaded"
            except StoreError as e:
                self.last_error = str(e)
                log.warning("Snapshot Upload असफल: %s", e)
                return "error"
            except Exception as e:  # pragma: no cover
                self.last_error = type(e).__name__
                log.exception("Snapshot में अप्रत्याशित Error")
                return "error"

    def run(self):
        while not self._stop_evt.is_set():
            kicked = self._kick.wait(timeout=self.cfg.snapshot_interval_sec)
            if self._stop_evt.is_set():
                break
            if kicked:
                self._kick.clear()
                if self._stop_evt.wait(self.cfg.kick_debounce_sec if hasattr(self.cfg, "kick_debounce_sec") else 20):
                    break
            self.snapshot_now()

    def stop(self):
        self._stop_evt.set()
        self._kick.set()
