"""security_manager.py - सुरक्षा की जाँचें.

ध्यान दें: Static scan सिर्फ़ पहली छलनी है. असली सुरक्षा Docker Isolation
(non-root, cap-drop, resource limits) से मिलती है. Static scan हर खतरे को नहीं पकड़ सकता.
"""
from __future__ import annotations

import difflib
import os
import re
import shutil
import stat
import zipfile
from dataclasses import dataclass
from pathlib import Path

# ---------------------------------------------------------------- redaction
TOKEN_RE = re.compile(r"(?<!\d)\d{6,12}:[A-Za-z0-9_-]{30,}")
_GENERIC_PATTERNS = [
    (re.compile(r"AIza[0-9A-Za-z_\-]{35}"), "[REDACTED_GOOGLE_KEY]"),
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}"), "[REDACTED_KEY]"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}"), "[REDACTED_GITHUB_TOKEN]"),
    (re.compile(r"(?i)(\bauth=)[^&\s\"'<>]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(authorization:\s*bearer\s+)[A-Za-z0-9._\-]+"), r"\1[REDACTED]"),
]


def redact(text: str, secrets=()) -> str:
    """Logs/Reports में से Token और Secret हटाता है."""
    if not text:
        return text or ""
    out = str(text)
    for s in secrets or ():
        if s and len(str(s)) >= 6:
            out = out.replace(str(s), "[REDACTED]")
    out = TOKEN_RE.sub("[REDACTED_TOKEN]", out)
    for rx, rep in _GENERIC_PATTERNS:
        out = rx.sub(rep, out)
    return out


def mask_secret(s: str) -> str:
    s = s or ""
    if len(s) <= 8:
        return "•" * len(s)
    return f"{s[:4]}…{s[-3:]}"


# ------------------------------------------------------------ path / names
class SecurityError(Exception):
    pass


def safe_filename(name: str, default: str = "file") -> str:
    name = os.path.basename((name or "").replace("\\", "/"))
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name).lstrip(".")
    name = name[:100]
    return name or default


def safe_join(base: str | Path, *parts: str) -> Path:
    """base के बाहर जाने वाला कोई भी path रोकता है (Path Traversal Protection)."""
    base_p = Path(base).resolve()
    target = base_p.joinpath(*parts).resolve()
    if target != base_p and base_p not in target.parents:
        raise SecurityError(f"असुरक्षित path रोका गया: {'/'.join(parts)}")
    return target


# --------------------------------------------------------------- ZIP safety
def safe_extract_zip(zip_path, dest, max_files=2000, max_total_bytes=100 * 1024 * 1024,
                     max_file_bytes=50 * 1024 * 1024, max_ratio=200) -> list[str]:
    """ZIP को सुरक्षित तरीके से खोलता है.

    रोकता है: Zip-Slip (../ या absolute path), Symlink, Encrypted ZIP, Zip-Bomb
    (बहुत ज़्यादा size/ratio), बहुत ज़्यादा files. Header पर भरोसा नहीं करता - असली bytes गिनता है.
    """
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    dest_r = dest.resolve()
    extracted: list[str] = []
    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as e:
        raise SecurityError(f"ZIP खराब है: {e}")
    with zf:
        infos = zf.infolist()
        if len(infos) > max_files:
            raise SecurityError(f"ZIP में बहुत ज़्यादा files हैं ({len(infos)} > {max_files}).")
        declared = sum(i.file_size for i in infos)
        if declared > max_total_bytes:
            raise SecurityError("ZIP खोलने पर बहुत बड़ा हो जाएगा (Zip-Bomb जैसा).")
        total = 0
        for zi in infos:
            raw = zi.filename.replace("\\", "/")
            if raw.startswith("__MACOSX/") or raw.endswith(".DS_Store"):
                continue
            if raw.startswith("/") or re.match(r"^[A-Za-z]:", raw):
                raise SecurityError(f"ZIP में absolute path मिला: {raw}")
            parts = [p for p in raw.split("/") if p not in ("", ".")]
            if ".." in parts:
                raise SecurityError(f"ZIP में '..' वाला path मिला (Zip-Slip): {raw}")
            if zi.flag_bits & 0x1:
                raise SecurityError("Password वाला (encrypted) ZIP समर्थित नहीं है.")
            mode = (zi.external_attr >> 16) & 0o170000
            if mode == stat.S_IFLNK:
                raise SecurityError(f"ZIP में symlink मिला (रोका गया): {raw}")
            if zi.file_size > max_file_bytes:
                raise SecurityError(f"ZIP की एक file बहुत बड़ी है: {raw}")
            if zi.compress_size and zi.file_size > 1_000_000 and zi.file_size / zi.compress_size > max_ratio:
                raise SecurityError(f"Compression ratio संदिग्ध (Zip-Bomb): {raw}")
            target = (dest_r.joinpath(*parts)).resolve()
            if target != dest_r and dest_r not in target.parents:
                raise SecurityError(f"ZIP path बाहर जा रहा है: {raw}")
            if zi.is_dir() or raw.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            written = 0
            with zf.open(zi) as src, open(target, "wb") as out:
                while True:
                    buf = src.read(65536)
                    if not buf:
                        break
                    written += len(buf)
                    total += len(buf)
                    if written > max_file_bytes or total > max_total_bytes:
                        out.close()
                        raise SecurityError("ZIP असली size में limit से बड़ा निकला (Zip-Bomb).")
                    out.write(buf)
            os.chmod(target, 0o644)  # execute bit नहीं
            extracted.append("/".join(parts))
    return extracted


def flatten_single_root(dest) -> None:
    """ZIP में सिर्फ़ एक folder हो तो उसकी चीज़ें ऊपर ले आता है."""
    dest = Path(dest)
    entries = [e for e in dest.iterdir() if e.name != "__MACOSX"]
    if len(entries) == 1 and entries[0].is_dir():
        inner = entries[0]
        for item in list(inner.iterdir()):
            shutil.move(str(item), str(dest / item.name))
        inner.rmdir()


# -------------------------------------------------------------- static scan
@dataclass
class Finding:
    severity: str   # critical | warning
    file: str
    line: int
    rule: str
    message: str

    def to_dict(self):
        return self.__dict__.copy()


_CRITICAL = [
    (r"docker\.sock|/var/run/docker", "Docker socket तक पहुँच की कोशिश"),
    (r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:", "Fork bomb"),
    (r"\brm\s+-[a-zA-Z]*[rR][a-zA-Z]*\s+(--no-preserve-root\s+)?/(\s|$|\*|\"|')", "पूरा system मिटाने वाला command (rm -rf /)"),
    (r"/dev/tcp/|\bbash\s+-i\s*>&|\bnc(at)?\s+(-\w+\s+)*-e\b|pty\.spawn\(\s*[\"']/bin/(ba)?sh", "Reverse shell जैसा pattern"),
    (r"stratum\+tcp://|\bxmrig\b|\bminerd\b|cryptonight|coinhive", "Crypto-miner जैसा pattern"),
    (r"/etc/shadow|/etc/sudoers|/root/\.ssh|\.ssh/id_(rsa|ed25519|ecdsa)|/proc/1/(root|environ|cmdline)", "Host की संवेदनशील files पढ़ने की कोशिश"),
    (r"\bnsenter\b|\bchroot\b|--privileged|\binsmod\b", "Container से बाहर निकलने जैसा कोड"),
    (r"169\.254\.169\.254|metadata\.google\.internal", "Cloud metadata (credentials) तक पहुँच की कोशिश"),
    (r"\b(exec|eval)\s*\(\s*(base64\.b64decode|zlib\.decompress|marshal\.loads|codecs\.decode|bytes\.fromhex)", "छिपा हुआ (obfuscated) कोड चलाने की कोशिश"),
    (r"\bmarshal\.loads\s*\(", "Compiled कोड load करने की कोशिश (छिपा हुआ कोड)"),
    (r"eval\s*\(\s*(atob|Buffer\.from)\s*\(", "छिपा हुआ (obfuscated) JS कोड"),
]
_WARNING = [
    (r"\bos\.system\s*\(|\bsubprocess\.(Popen|run|call|check_output|check_call)\b", "Shell/Process चलाता है"),
    (r"\bchild_process\b", "Node child_process का उपयोग"),
    (r"(?<![\w.])(eval|exec)\s*\(", "eval/exec का उपयोग"),
    (r"\bpickle\.loads?\s*\(", "pickle load (अनजान data पर खतरनाक)"),
    (r"\bctypes\b", "ctypes (low-level) का उपयोग"),
    (r"\bsocket\.socket\s*\(", "सीधा socket खोलता है"),
    (r"\.sh\b.*\bchmod\b|\bchmod\s+\+x\b", "File को executable बनाता है"),
]
_CRIT_RX = [(re.compile(p, re.I), m) for p, m in _CRITICAL]
_WARN_RX = [(re.compile(p), m) for p, m in _WARNING]
_SCAN_EXT = {".py", ".js", ".mjs", ".cjs", ".ts", ".sh", ".bash"}
_SKIP_DIRS = {".venv", "venv", "node_modules", "__pycache__", ".git", ".om_backup"}


def iter_project_files(root, limit=5000):
    root = Path(root)
    n = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fn in filenames:
            n += 1
            if n > limit:
                return
            yield Path(dirpath) / fn


def static_scan(project_dir, max_files=400, max_bytes=600_000) -> list[Finding]:
    root = Path(project_dir)
    findings: list[Finding] = []
    scanned = 0
    for path in iter_project_files(root):
        rel = str(path.relative_to(root))
        ext = path.suffix.lower()
        try:
            with open(path, "rb") as f:
                head = f.read(4)
        except OSError:
            continue
        if head == b"\x7fELF":
            findings.append(Finding("warning", rel, 0, "binary", "ELF binary file मिली (Host पर नहीं, सिर्फ़ container में चलेगी)"))
            continue
        if ext in (".exe", ".dll", ".bat", ".cmd", ".scr"):
            findings.append(Finding("warning", rel, 0, "windows-binary", "Windows executable फ़ाइल (Linux पर नहीं चलेगी)"))
            continue
        if ext not in _SCAN_EXT:
            continue
        scanned += 1
        if scanned > max_files:
            break
        try:
            text = path.read_bytes()[:max_bytes].decode("utf-8", "ignore")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            if len(line) > 2000:
                line = line[:2000]
            stripped = line.strip()
            if stripped.startswith("#") and ext == ".py":
                continue
            for rx, msg in _CRIT_RX:
                if rx.search(line):
                    findings.append(Finding("critical", rel, i, "critical", msg))
                    break
            else:
                for rx, msg in _WARN_RX:
                    if rx.search(line):
                        findings.append(Finding("warning", rel, i, "warn", msg))
                        break
        if len(findings) > 200:
            break
    # एक ही message बार-बार न दिखे
    seen, uniq = set(), []
    for f in findings:
        k = (f.severity, f.file, f.message)
        if k in seen:
            continue
        seen.add(k)
        uniq.append(f)
    return uniq


# ------------------------------------------------------- dependency safety
POPULAR_PY = {
    "requests", "aiohttp", "httpx", "flask", "django", "fastapi", "uvicorn", "numpy", "pandas", "scipy",
    "matplotlib", "pillow", "opencv-python", "opencv-python-headless", "beautifulsoup4", "lxml", "pyyaml",
    "python-dotenv", "python-telegram-bot", "pytelegrambotapi", "aiogram", "pyrogram", "telethon", "tgcrypto",
    "psutil", "aiofiles", "aiosqlite", "sqlalchemy", "pymongo", "motor", "redis", "psycopg2-binary", "pymysql",
    "cryptography", "pycryptodome", "pycryptodomex", "firebase-admin", "pyrebase4", "google-api-python-client",
    "google-auth", "gspread", "openpyxl", "xlsxwriter", "pydantic", "jinja2", "click", "colorama", "tqdm",
    "schedule", "apscheduler", "pytz", "tzlocal", "python-dateutil", "websockets", "websocket-client", "paramiko",
    "yt-dlp", "youtube-dl", "pytube", "gtts", "qrcode", "emoji", "validators", "tabulate", "rich", "loguru",
    "ujson", "orjson", "uvloop", "certifi", "urllib3", "six", "setuptools", "wheel", "pip", "attrs", "typing-extensions",
    "pytest", "black", "flake8", "mypy", "selenium", "playwright", "scrapy", "nest-asyncio", "cachetools",
    "pymupdf", "pypdf", "pypdf2", "reportlab", "fpdf", "docx", "python-docx", "speedtest-cli", "ping3", "whois",
    "pyshorteners", "wikipedia", "googletrans", "deep-translator", "openai", "anthropic", "tweepy", "discord-py",
    "pyngrok", "gunicorn", "waitress", "starlette", "sanic", "tornado", "pyjwt", "bcrypt", "passlib", "faker",
    "httpcore", "anyio", "sniffio", "idna", "charset-normalizer", "decorator", "regex", "pyparsing", "packaging",
    "tgcrypto", "telegraph", "aiogram-dialog", "pymongo", "dnspython", "ccxt", "yfinance", "beautifulsoup", "pytesseract",
}
POPULAR_NPM = {
    "node-telegram-bot-api", "telegraf", "grammy", "telegram", "axios", "node-fetch", "express", "dotenv", "lodash",
    "moment", "dayjs", "cheerio", "request", "got", "ws", "mongoose", "mongodb", "sqlite3", "better-sqlite3",
    "firebase", "firebase-admin", "cors", "body-parser", "chalk", "commander", "uuid", "cron", "node-cron",
    "discord.js", "sharp", "jimp", "puppeteer", "nodemon", "pm2", "winston", "pino", "yargs", "fs-extra",
}
# pip पर इन नामों का मतलब कुछ और है - import-नाम को pip-नाम से बदलना पड़ता है
PIP_NAME_FIX = {
    "telebot": "pyTelegramBotAPI",
    "telegram": "python-telegram-bot",
    "cv2": "opencv-python-headless",
    "pil": "Pillow",
    "bs4": "beautifulsoup4",
    "sklearn": "scikit-learn",
    "yaml": "PyYAML",
    "dotenv": "python-dotenv",
    "crypto": "pycryptodome",
    "fitz": "PyMuPDF",
    "docx": "python-docx",
    "magic": "python-magic",
    "serial": "pyserial",
    "dateutil": "python-dateutil",
    "jwt": "PyJWT",
    "googleapiclient": "google-api-python-client",
}

_REQ_RE = re.compile(
    r"^(?P<name>[A-Za-z0-9][A-Za-z0-9._-]*)\s*(?P<extras>\[[A-Za-z0-9,._\- ]+\])?\s*"
    r"(?P<spec>(?:(?:===|==|>=|<=|~=|!=|<|>)\s*[A-Za-z0-9.*+!_-]+\s*,?\s*)*)\s*(?P<marker>;.*)?$"
)


def norm_pkg(name: str) -> str:
    return re.sub(r"[-_.]+", "-", (name or "").strip()).lower()


def typosquat_suspect(name: str, popular=None) -> str | None:
    """नाम किसी popular package से मिलता-जुलता (पर बराबर नहीं) हो तो वह popular नाम लौटाता है."""
    popular = popular or POPULAR_PY
    n = norm_pkg(name)
    if n in popular:
        return None
    for p in popular:
        if abs(len(p) - len(n)) <= 2 and len(n) >= 5:
            if difflib.SequenceMatcher(None, n, p).ratio() >= 0.88:
                return p
    return None


@dataclass
class ReqCheck:
    ok: bool
    name: str = ""
    spec: str = ""
    marker: str = ""
    reason: str = ""
    suggestion: str = ""


def check_requirement_line(line: str) -> ReqCheck | None:
    """requirements.txt की एक line जाँचता है. खाली/comment पर None."""
    line = re.sub(r"\s+#.*$", "", line.strip())
    if not line or line.startswith("#"):
        return None
    if line.startswith("-"):
        return ReqCheck(False, line[:60], reason="pip option/nested file (-r, -e, --index-url आदि) सुरक्षा कारण से समर्थित नहीं")
    if "://" in line or "@" in line.replace(" ", "") and "@" in line.split(";")[0] or "git+" in line:
        return ReqCheck(False, line[:60], reason="URL/Git/Local source से install नहीं करते (सिर्फ़ PyPI नाम)")
    if "/" in line.split(";")[0] or "\\" in line:
        return ReqCheck(False, line[:60], reason="Local path वाली dependency समर्थित नहीं")
    m = _REQ_RE.match(line)
    if not m:
        return ReqCheck(False, line[:60], reason="Requirement का format समझ नहीं आया")
    name = m.group("name")
    spec = re.sub(r"\s+", "", m.group("spec") or "")
    marker = (m.group("marker") or "").strip()
    fix = PIP_NAME_FIX.get(norm_pkg(name))
    if fix and norm_pkg(name) in ("telebot", "telegram", "cv2", "pil", "bs4", "sklearn", "yaml", "dotenv", "crypto", "fitz", "docx", "jwt"):
        return ReqCheck(False, name, spec, marker, reason=f"pip पर '{name}' का मतलब वह package नहीं जो import में है", suggestion=fix)
    sus = typosquat_suspect(name)
    if sus:
        return ReqCheck(False, name, spec, marker, reason=f"'{name}' नाम '{sus}' से मिलता-जुलता है (typosquat का खतरा)", suggestion=sus)
    return ReqCheck(True, name, spec, marker)


_NPM_NAME = re.compile(r"^(@[a-z0-9-~][a-z0-9-._~]*/)?[a-z0-9-~][a-z0-9-._~]*$")
_NPM_SPEC = re.compile(r"^(latest|next|[~^<>=v0-9.*xX|\s-]+)$")


def check_npm_dependency(name: str, spec: str) -> ReqCheck:
    if not _NPM_NAME.match(name or ""):
        return ReqCheck(False, name, reason="npm package का नाम गलत है")
    spec = (spec or "latest").strip()
    if not _NPM_SPEC.match(spec):
        return ReqCheck(False, name, spec, reason="Git/URL/Local source वाली npm dependency समर्थित नहीं")
    sus = typosquat_suspect(name, POPULAR_NPM)
    if sus:
        return ReqCheck(False, name, spec, reason=f"'{name}' नाम '{sus}' से मिलता-जुलता है (typosquat का खतरा)", suggestion=sus)
    return ReqCheck(True, name, spec)
