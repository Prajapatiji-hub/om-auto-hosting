"""file_analyzer.py - बिना किसी AI API के Project का तकनीकी (static) विश्लेषण.

सिर्फ़ Python `ast`, regex और package.json पढ़ने से काम होता है. Code चलाया नहीं जाता.
"""
from __future__ import annotations

import ast
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

import command_detector
from project_detector import ProjectInfo
from security_manager import (TOKEN_RE, PIP_NAME_FIX, POPULAR_PY, check_requirement_line, iter_project_files,
                              norm_pkg, redact)
from utils import esc

TELEGRAM_FRAMEWORKS = {
    "telebot": "TeleBot (pyTelegramBotAPI)",
    "telegram": "python-telegram-bot",
    "aiogram": "aiogram",
    "pyrogram": "Pyrogram",
    "telethon": "Telethon",
}
NODE_TELEGRAM = {
    "node-telegram-bot-api": "node-telegram-bot-api",
    "telegraf": "Telegraf",
    "grammy": "grammY",
    "telegram": "GramJS (telegram)",
}
IMPORT_TO_PIP = {
    "telebot": "pyTelegramBotAPI", "telegram": "python-telegram-bot", "aiogram": "aiogram", "pyrogram": "pyrogram",
    "telethon": "telethon", "tgcrypto": "TgCrypto", "requests": "requests", "aiohttp": "aiohttp", "httpx": "httpx",
    "flask": "Flask", "flask_cors": "Flask-Cors", "fastapi": "fastapi", "uvicorn": "uvicorn", "starlette": "starlette",
    "pil": "Pillow", "cv2": "opencv-python-headless", "bs4": "beautifulsoup4", "lxml": "lxml", "yaml": "PyYAML",
    "dotenv": "python-dotenv", "psutil": "psutil", "numpy": "numpy", "pandas": "pandas", "scipy": "scipy",
    "matplotlib": "matplotlib", "sklearn": "scikit-learn", "crypto": "pycryptodome", "cryptography": "cryptography",
    "firebase_admin": "firebase-admin", "pyrebase": "pyrebase4", "dateutil": "python-dateutil", "pytz": "pytz",
    "jwt": "PyJWT", "yt_dlp": "yt-dlp", "gtts": "gTTS", "speedtest": "speedtest-cli", "qrcode": "qrcode",
    "schedule": "schedule", "apscheduler": "APScheduler", "uvloop": "uvloop", "ujson": "ujson", "orjson": "orjson",
    "nest_asyncio": "nest-asyncio", "motor": "motor", "pymongo": "pymongo", "bson": "pymongo", "redis": "redis",
    "sqlalchemy": "SQLAlchemy", "pymysql": "PyMySQL", "psycopg2": "psycopg2-binary", "aiosqlite": "aiosqlite",
    "aiofiles": "aiofiles", "websockets": "websockets", "websocket": "websocket-client", "paramiko": "paramiko",
    "pydantic": "pydantic", "jinja2": "Jinja2", "click": "click", "colorama": "colorama", "tqdm": "tqdm",
    "rich": "rich", "loguru": "loguru", "emoji": "emoji", "validators": "validators", "tabulate": "tabulate",
    "openpyxl": "openpyxl", "xlsxwriter": "XlsxWriter", "fitz": "PyMuPDF", "docx": "python-docx", "pypdf": "pypdf",
    "pypdf2": "PyPDF2", "reportlab": "reportlab", "fpdf": "fpdf2", "pytesseract": "pytesseract",
    "wikipedia": "wikipedia", "googletrans": "googletrans", "deep_translator": "deep-translator", "openai": "openai",
    "tweepy": "tweepy", "discord": "discord.py", "selenium": "selenium", "playwright": "playwright",
    "telegraph": "telegraph", "pyngrok": "pyngrok", "git": "GitPython", "serial": "pyserial", "dns": "dnspython",
    "whois": "python-whois", "pyshorteners": "pyshorteners", "ping3": "ping3", "pytube": "pytube",
    "markdown": "Markdown", "slugify": "python-slugify", "seaborn": "seaborn", "gunicorn": "gunicorn",
    "sanic": "sanic", "tornado": "tornado", "bcrypt": "bcrypt", "passlib": "passlib", "faker": "Faker",
    "magic": "python-magic", "regex": "regex", "cachetools": "cachetools", "anyio": "anyio", "attr": "attrs",
    "aiocron": "aiocron", "googleapiclient": "google-api-python-client", "gspread": "gspread", "ccxt": "ccxt",
    "yfinance": "yfinance", "scrapy": "scrapy", "pytest": "pytest",
}
KNOWN_PIP = {norm_pkg(v) for v in IMPORT_TO_PIP.values()} | POPULAR_PY
NODE_BUILTINS = {
    "fs", "path", "http", "https", "http2", "os", "crypto", "child_process", "events", "stream", "util", "url", "zlib",
    "readline", "net", "dns", "tls", "buffer", "assert", "process", "timers", "worker_threads", "cluster", "vm", "v8",
    "querystring", "string_decoder", "perf_hooks", "async_hooks", "module", "console", "dgram", "inspector", "repl",
    "tty", "punycode", "constants", "diagnostics_channel",
}
KNOWN_NPM = {"node-telegram-bot-api", "telegraf", "grammy", "axios", "node-fetch", "express", "dotenv", "lodash",
             "moment", "dayjs", "cheerio", "ws", "mongoose", "sqlite3", "better-sqlite3", "firebase-admin", "cors",
             "chalk", "uuid", "node-cron", "cron", "winston"}

_TELEGRAM_TOKEN_ENV = re.compile(
    r"^(TOKEN|BOT_TOKEN|API_TOKEN|TELEGRAM_TOKEN|TG_TOKEN|BOTTOKEN|(TELEGRAM|TG|BOT)_[A-Z0-9_]*TOKEN)$")
_API_LIKE = re.compile(
    r"(?i)(api[_-]?key|api[_-]?hash|api[_-]?id|secret|passw(or)?d|access[_-]?token|client[_-]?(id|secret)|"
    r"private[_-]?key|auth[_-]?token|(^|_)key$|_token$|^token$)")
_PLACEHOLDER = re.compile(
    r"(?i)(your|here|xxx+|placeholder|example|changeme|change_me|insert|enter|paste|dummy|todo|replace|"
    r"<.*>|\*{3,}|^none$|^null$|^token$|^key$)")
_OTHER_ENV_OPTIONAL = re.compile(r"(?i)^(PORT|HOST|DEBUG|LOG_LEVEL|TZ|LANG|PATH|HOME|PYTHONPATH|ENV|ENVIRONMENT)$")


def is_placeholder(v: str) -> bool:
    v = (v or "").strip()
    return v == "" or bool(_PLACEHOLDER.search(v))


def classify_name(name: str) -> str | None:
    """'token' (Telegram Bot Token), 'api' (दूसरी API Key/Secret) या None."""
    n = name.upper().replace("-", "_")
    if _TELEGRAM_TOKEN_ENV.match(n):
        return "token"
    if _API_LIKE.search(name):
        return "api"
    return None


def parse_env_text(text: str) -> dict:
    out = {}
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:]
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        elif " #" in v:
            v = v.split(" #", 1)[0].strip()
        if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", k):
            out[k] = v
    return out


@dataclass
class ConfigReq:
    kind: str                    # token | api | config
    name: str                    # दिखाने का नाम
    method: str                  # env | placeholder | source_present | dotenv_present
    env_names: list = field(default_factory=list)
    file: str = ""
    line: int = 0
    literal: str = ""            # placeholder का literal (Secret नहीं)
    optional: bool = False
    note: str = ""

    def to_dict(self):
        return self.__dict__.copy()


@dataclass
class Analysis:
    runtime: str | None = None
    entry: str | None = None
    framework: str = ""
    is_telegram: bool = False
    framework_note: str = ""
    imports_all: list = field(default_factory=list)
    stdlib: list = field(default_factory=list)
    local_modules: list = field(default_factory=list)
    third_party: list = field(default_factory=list)       # [{import, pip, known}]
    requirements: list = field(default_factory=list)      # [{name, spec, ok, reason, suggestion}]
    missing: list = field(default_factory=list)           # requirements में न होने वाले [{import, pip, known}]
    pins: list = field(default_factory=list)              # [{name, spec, reason}]
    config: list = field(default_factory=list)            # ConfigReq dicts
    commands: list = field(default_factory=list)
    has_main_guard: bool = False
    entry_markers: list = field(default_factory=list)
    main_function: bool = False
    syntax_errors: list = field(default_factory=list)     # [{file, line, msg}]
    risks: list = field(default_factory=list)             # संभावित Errors/चेतावनियाँ
    hardcoded_secrets: list = field(default_factory=list) # [{file, line, kind}] (value कभी नहीं)
    other_env: list = field(default_factory=list)
    package_json: dict = field(default_factory=dict)

    def to_dict(self):
        return self.__dict__.copy()


# ---------------------------------------------------------------- helpers
def _py_files(root: Path, limit=300, max_bytes=500_000):
    n = 0
    for p in iter_project_files(root):
        if p.suffix.lower() == ".py":
            try:
                if p.stat().st_size > max_bytes:
                    continue
            except OSError:
                continue
            n += 1
            if n > limit:
                return
            yield p


def _local_module_names(root: Path, info: ProjectInfo) -> set:
    names = set()
    for rel in info.files:
        parts = Path(rel).parts
        if rel.endswith(".py"):
            names.add(Path(rel).stem)
            if len(parts) > 1:
                names.add(parts[0])
                names.add(Path(parts[-1]).stem)
        elif len(parts) > 1:
            names.add(parts[0])
    return names


def _env_name_from_call(node):
    """os.getenv / os.environ.get / environ.get / getenv -> (name, has_default, default_value)."""
    if not isinstance(node, ast.Call) or not node.args:
        return None
    f = node.func
    ok = False
    if isinstance(f, ast.Attribute) and f.attr == "getenv" and isinstance(f.value, ast.Name) and f.value.id == "os":
        ok = True
    elif isinstance(f, ast.Name) and f.id == "getenv":
        ok = True
    elif isinstance(f, ast.Attribute) and f.attr == "get":
        v = f.value
        if (isinstance(v, ast.Attribute) and v.attr == "environ") or (isinstance(v, ast.Name) and v.id == "environ"):
            ok = True
    if not ok:
        return None
    a0 = node.args[0]
    if not (isinstance(a0, ast.Constant) and isinstance(a0.value, str)):
        return None
    default = None
    has_default = False
    if len(node.args) > 1:
        has_default = True
        d = node.args[1]
        default = d.value if isinstance(d, ast.Constant) else "<expr>"
    for kw in node.keywords:
        if kw.arg == "default":
            has_default = True
            default = kw.value.value if isinstance(kw.value, ast.Constant) else "<expr>"
    return a0.value, has_default, default


def _env_name_from_subscript(node):
    if isinstance(node, ast.Subscript):
        v = node.value
        if (isinstance(v, ast.Attribute) and v.attr == "environ") or (isinstance(v, ast.Name) and v.id == "environ"):
            s = node.slice
            if isinstance(s, ast.Constant) and isinstance(s.value, str):
                return s.value
    return None


# ------------------------------------------------------- python analysis
def _analyze_python(root: Path, info: ProjectInfo, a: Analysis, env_literals: list, env_reads: dict):
    local = _local_module_names(root, info)
    stdlib_names = set(getattr(sys, "stdlib_module_names", set())) | {"__future__"}
    all_imports, optional_imports = set(), set()
    src_all = []
    v13_markers = v20_markers = aiogram2 = aiogram3 = False

    for p in _py_files(root):
        rel = str(p.relative_to(root))
        text = p.read_text("utf-8", "ignore")
        src_all.append(text)
        try:
            tree = ast.parse(text, filename=rel)
        except SyntaxError as e:
            a.syntax_errors.append({"file": rel, "line": e.lineno or 0, "msg": f"{e.msg}"})
            continue
        except (ValueError, RecursionError) as e:
            a.syntax_errors.append({"file": rel, "line": 0, "msg": f"parse नहीं हो सका: {e}"})
            continue

        # try/except ImportError में रखे imports वैकल्पिक माने जाते हैं
        for node in ast.walk(tree):
            if isinstance(node, ast.Try):
                handles = False
                for h in node.handlers:
                    names = []
                    if h.type is None:
                        handles = True
                    elif isinstance(h.type, ast.Name):
                        names = [h.type.id]
                    elif isinstance(h.type, ast.Tuple):
                        names = [e.id for e in h.type.elts if isinstance(e, ast.Name)]
                    if any(n in ("ImportError", "ModuleNotFoundError") for n in names):
                        handles = True
                if handles:
                    for sub in node.body:
                        for n2 in ast.walk(sub):
                            if isinstance(n2, ast.Import):
                                optional_imports.update(al.name.split(".")[0] for al in n2.names)
                            elif isinstance(n2, ast.ImportFrom) and n2.module and n2.level == 0:
                                optional_imports.add(n2.module.split(".")[0])

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                all_imports.update(al.name.split(".")[0] for al in node.names)
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                top = node.module.split(".")[0]
                all_imports.add(top)
                names = {al.name for al in node.names}
                if top == "telegram" and ("Filters" in names or "Updater" in names):
                    v13_markers = True
                if top == "telegram" and ("Application" in names or "ApplicationBuilder" in names):
                    v20_markers = True
                if top == "aiogram":
                    if "executor" in names or node.module.startswith("aiogram.dispatcher") or node.module == "aiogram.utils.executor":
                        aiogram2 = True
                    if "Router" in names or "F" in names or node.module.startswith("aiogram.filters") or "CommandStart" in names:
                        aiogram3 = True
            elif isinstance(node, ast.Call):
                fn = node.func.attr if isinstance(node.func, ast.Attribute) else (node.func.id if isinstance(node.func, ast.Name) else "")
                if fn in ("infinity_polling", "polling", "run_polling", "start_polling", "run_until_disconnected", "idle", "run_forever"):
                    a.entry_markers.append(f"{fn}() ({rel})")
                if fn == "input" and rel == info.entry:
                    a.risks.append(f"'{rel}' में input() है - Bot बैकग्राउंड में चलता है, वहाँ कोई टाइप नहीं कर सकता (EOFError आएगा).")
                if fn == "run" and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id in ("app", "flask_app", "server"):
                    a.risks.append("Flask/Web server मिला: Hosted Bots के Port बाहर नहीं खुलते, इसलिए Web page बाहर से नहीं दिखेगा (Telegram polling वाले Bots ठीक हैं).")
                if fn == "Updater" and (node.args or any(k.arg == "use_context" for k in node.keywords)):
                    v13_markers = True
                if fn == "Dispatcher" and not node.args and not node.keywords:
                    aiogram3 = True
                if fn == "TeleBot" or fn == "AsyncTeleBot":
                    a.framework = a.framework or "telebot"
                env = _env_name_from_call(node)
                if env:
                    name, has_def, default = env
                    ent = env_reads.setdefault(name, {"has_default": False, "default": None, "files": []})
                    if has_def and not (isinstance(default, str) and is_placeholder(default)) and default not in (None, ""):
                        ent["has_default"] = True
                    ent["files"].append((rel, node.lineno))
            elif isinstance(node, ast.Subscript):
                nm = _env_name_from_subscript(node)
                if nm:
                    ent = env_reads.setdefault(nm, {"has_default": False, "default": None, "files": []})
                    ent["files"].append((rel, node.lineno))
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                value = node.value
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    for t in targets:
                        nm = t.id if isinstance(t, ast.Name) else (t.attr if isinstance(t, ast.Attribute) else None)
                        if nm and classify_name(nm):
                            env_literals.append({"name": nm, "value": value.value, "file": rel, "line": node.lineno,
                                                 "kind": classify_name(nm)})
            elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                if node.name == "main" and rel == info.entry:
                    a.main_function = True

        # commands
        a.commands.extend(command_detector.detect_python_commands(tree, rel))
        if rel == info.entry and re.search(r"""if\s+__name__\s*==\s*["']__main__["']""", text):
            a.has_main_guard = True
        if rel == info.entry:
            for top in tree.body:
                if isinstance(top, (ast.While, ast.For, ast.With, ast.Try)) or (
                        isinstance(top, ast.Expr) and isinstance(top.value, ast.Call)):
                    a.entry_markers.append("top-level code")
                    break

    all_imports = {i for i in all_imports if i}
    a.imports_all = sorted(all_imports)
    for imp in sorted(all_imports):
        if imp in local and imp not in stdlib_names:
            a.local_modules.append(imp)
        elif imp in stdlib_names:
            a.stdlib.append(imp)
        elif imp in optional_imports:
            continue
        else:
            pip = IMPORT_TO_PIP.get(imp.lower()) or IMPORT_TO_PIP.get(imp) or PIP_NAME_FIX.get(imp.lower()) or imp
            a.third_party.append({"import": imp, "pip": pip, "known": norm_pkg(pip) in KNOWN_PIP})

    # framework
    for imp, label in TELEGRAM_FRAMEWORKS.items():
        if imp in all_imports:
            a.framework = label
            a.is_telegram = True
            break
    if a.framework == "telebot":
        a.framework = TELEGRAM_FRAMEWORKS["telebot"]
        a.is_telegram = True
    if a.framework.startswith("python-telegram-bot"):
        if v13_markers and not v20_markers:
            a.framework_note = "पुराना (v13) style API"
        elif v20_markers:
            a.framework_note = "नया (v20+, async) style API"
    if a.framework == "aiogram":
        if aiogram2 and not aiogram3:
            a.framework_note = "aiogram v2 style"
        elif aiogram3:
            a.framework_note = "aiogram v3 style"

    # requirements.txt
    declared = {}
    req_path = root / "requirements.txt"
    if req_path.exists():
        for line in req_path.read_text("utf-8", "ignore").splitlines():
            chk = check_requirement_line(line)
            if chk is None:
                continue
            a.requirements.append({"name": chk.name, "spec": chk.spec, "ok": chk.ok, "reason": chk.reason, "suggestion": chk.suggestion})
            nm = norm_pkg(chk.suggestion or chk.name)
            declared.setdefault(nm, []).append(chk.spec)
    for tp in a.third_party:
        if norm_pkg(tp["pip"]) not in declared:
            a.missing.append(tp)

    # version pins (साफ़ संकेत मिलने पर)
    if a.framework == "python-telegram-bot" and v13_markers and not v20_markers:
        pinned = declared.get("python-telegram-bot", [""])
        if not any(s for s in pinned):
            a.pins.append({"name": "python-telegram-bot", "spec": "==13.15", "reason": "Code पुराने v13 API (Updater/Filters) का है; नया version चलाने पर टूट जाएगा."})
    if a.framework == "aiogram" and aiogram2 and not aiogram3:
        pinned = declared.get("aiogram", [""])
        if not any(s for s in pinned):
            a.pins.append({"name": "aiogram", "spec": "<3", "reason": "Code aiogram v2 style का है."})
    # version conflict (एक ही package, अलग अलग pin)
    for nm, specs in declared.items():
        uniq = {s for s in specs if s}
        if len(specs) > 1 and len(uniq) > 1:
            a.risks.append(f"requirements.txt में '{nm}' के अलग-अलग versions लिखे हैं: {', '.join(sorted(uniq))}")
    if "telegram" in {norm_pkg(r["name"]) for r in a.requirements} and "python-telegram-bot" not in declared:
        pass  # check_requirement_line पहले ही रोकता है
    return src_all


def _analyze_node(root: Path, info: ProjectInfo, a: Analysis, env_literals: list, env_reads: dict, js_syntax_checker):
    pj = root / "package.json"
    declared = {}
    if pj.exists():
        try:
            data = json.loads(pj.read_text("utf-8", "ignore"))
            declared = {**(data.get("dependencies") or {}), **(data.get("devDependencies") or {})}
            a.package_json = {"name": data.get("name", ""), "main": data.get("main", ""),
                              "start": (data.get("scripts") or {}).get("start", ""),
                              "dependencies": data.get("dependencies") or {}, "type": data.get("type", "")}
        except ValueError:
            a.risks.append("package.json का JSON गलत है.")
    imports = set()
    n = 0
    for p in iter_project_files(root):
        if p.suffix.lower() not in (".js", ".mjs", ".cjs"):
            continue
        n += 1
        if n > 200:
            break
        rel = str(p.relative_to(root))
        text = p.read_text("utf-8", "ignore")[:500_000]
        for m in re.finditer(r"""require\(\s*['"]([^'"]+)['"]\s*\)|from\s+['"]([^'"]+)['"]|import\s+['"]([^'"]+)['"]""", text):
            spec = m.group(1) or m.group(2) or m.group(3)
            if not spec or spec.startswith((".", "/")):
                continue
            spec = spec.replace("node:", "")
            parts = spec.split("/")
            pkg = "/".join(parts[:2]) if spec.startswith("@") else parts[0]
            if pkg not in NODE_BUILTINS:
                imports.add(pkg)
        for m in re.finditer(r"process\.env\.([A-Za-z_][A-Za-z0-9_]*)|process\.env\[\s*['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]\s*\]", text):
            nm = m.group(1) or m.group(2)
            ent = env_reads.setdefault(nm, {"has_default": False, "default": None, "files": []})
            line_start = text.rfind("\n", 0, m.start()) + 1
            line_end = text.find("\n", m.end())
            line = text[line_start: line_end if line_end != -1 else len(text)]
            if re.search(r"(\|\||\?\?)\s*['\"][^'\"]+['\"]", line) and not is_placeholder(re.findall(r"(?:\|\||\?\?)\s*['\"]([^'\"]+)['\"]", line)[0]):
                ent["has_default"] = True
            ent["files"].append((rel, text.count("\n", 0, m.start()) + 1))
        for m in re.finditer(r"""(?:const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*['"]([^'"]*)['"]""", text):
            if classify_name(m.group(1)):
                env_literals.append({"name": m.group(1), "value": m.group(2), "file": rel,
                                     "line": text.count("\n", 0, m.start()) + 1, "kind": classify_name(m.group(1))})
        a.commands.extend(command_detector.detect_js_commands(text, rel))
        if rel == info.entry:
            if re.search(r"\bmain\s*\(", text):
                a.main_function = True
            for mk in re.finditer(r"startPolling|\.launch\(|bot\.start\(|polling\s*:\s*true|new TelegramBot\(", text):
                a.entry_markers.append(mk.group(0))
    a.imports_all = sorted(imports)
    for imp in sorted(imports):
        if imp in NODE_TELEGRAM:
            a.framework = NODE_TELEGRAM[imp]
            a.is_telegram = True
    for imp in sorted(imports):
        if imp not in declared and not (root / "node_modules" / imp).exists():
            a.missing.append({"import": imp, "pip": imp, "known": imp in KNOWN_NPM})
        a.third_party.append({"import": imp, "pip": imp, "known": imp in KNOWN_NPM})
    if js_syntax_checker and info.entry:
        try:
            for err in js_syntax_checker(root):
                a.syntax_errors.append(err)
        except Exception as e:  # pragma: no cover
            a.risks.append(f"JS syntax check नहीं हो सका: {e}")


def _build_config(root: Path, info: ProjectInfo, a: Analysis, env_literals, env_reads):
    dotenv = {}
    if info.has_dotenv:
        dotenv = parse_env_text((root / ".env").read_text("utf-8", "ignore"))
    example = {}
    for nm in (".env.example", "env.example", ".env.sample"):
        if (root / nm).exists():
            example.update(parse_env_text((root / nm).read_text("utf-8", "ignore")))
    reqs: dict[tuple, ConfigReq] = {}
    token_envs: list[str] = []

    for name, ent in env_reads.items():
        cls = classify_name(name)
        if cls is None:
            if not ent["has_default"] and not _OTHER_ENV_OPTIONAL.match(name):
                a.other_env.append(name)
            continue
        if name in dotenv and not is_placeholder(dotenv[name]):
            reqs[(cls, name)] = ConfigReq(cls, name, "dotenv_present", [name], *ent["files"][0], note=".env में मिला")
            continue
        if ent["has_default"]:
            reqs[(cls, name)] = ConfigReq(cls, name, "env", [name], *ent["files"][0], optional=True, note="Default मौजूद")
            continue
        if cls == "token":
            token_envs.append(name)
        else:
            f = ent["files"][0]
            reqs[(cls, name)] = ConfigReq("api", name, "env", [name], f[0], f[1])

    # .env.example के token/api नाम जो Code में सीधे नहीं दिखे
    for name, val in example.items():
        cls = classify_name(name)
        if cls and (cls, name) not in reqs and name not in token_envs and name not in dotenv:
            if cls == "token":
                token_envs.append(name)
            else:
                reqs[(cls, name)] = ConfigReq("api", name, "env", [name], ".env.example", 0, note=".env.example में लिखा है")

    if token_envs:
        reqs[("token", "BOT_TOKEN")] = ConfigReq("token", "Telegram Bot Token", "env", sorted(set(token_envs)),
                                                 *env_reads.get(token_envs[0], {"files": [("", 0)]})["files"][0])

    # literals (source में लिखे)
    token_found_literal = False
    for lit in env_literals:
        val, kind = lit["value"], lit["kind"]
        if kind == "token":
            if ("token", "BOT_TOKEN") in reqs:
                continue
            if TOKEN_RE.fullmatch(val.strip()):
                if not token_found_literal:
                    reqs[("token", "BOT_TOKEN")] = ConfigReq("token", "Telegram Bot Token", "source_present", [], lit["file"], lit["line"],
                                                             note="Token Source Code में पहले से लिखा है")
                    token_found_literal = True
                a.hardcoded_secrets.append({"file": lit["file"], "line": lit["line"], "kind": "telegram_token"})
            elif is_placeholder(val) or len(val) < 20:
                if not token_found_literal and ("token", "BOT_TOKEN") not in reqs:
                    reqs[("token", "BOT_TOKEN")] = ConfigReq("token", "Telegram Bot Token", "placeholder", [], lit["file"], lit["line"],
                                                             literal=val, note=f"'{lit['name']}' में placeholder लिखा है")
        else:
            key = ("api", lit["name"])
            if key in reqs:
                continue
            if is_placeholder(val):
                reqs[key] = ConfigReq("api", lit["name"], "placeholder", [], lit["file"], lit["line"], literal=val,
                                      note="Source में placeholder लिखा है")
            elif len(val) >= 8:
                a.hardcoded_secrets.append({"file": lit["file"], "line": lit["line"], "kind": f"api:{lit['name']}"})

    # बिखरे Token (किसी भी text फाइल में)
    if not any(k[0] == "token" for k in reqs):
        for p in iter_project_files(root):
            if p.suffix.lower() in (".py", ".js", ".json", ".env", ".txt", ".yml", ".yaml", ".ini", ".cfg") or p.name == ".env":
                try:
                    if p.stat().st_size > 300_000:
                        continue
                    txt = p.read_text("utf-8", "ignore")
                except OSError:
                    continue
                m = TOKEN_RE.search(txt)
                if m:
                    line = txt.count("\n", 0, m.start()) + 1
                    rel = str(p.relative_to(root))
                    reqs[("token", "BOT_TOKEN")] = ConfigReq("token", "Telegram Bot Token", "source_present", [], rel, line,
                                                             note="Token फाइल में पहले से लिखा है")
                    a.hardcoded_secrets.append({"file": rel, "line": line, "kind": "telegram_token"})
                    break
    a.config = [r.to_dict() for r in reqs.values()]


def analyze_project(root, info: ProjectInfo, js_syntax_checker=None) -> Analysis:
    root = Path(root)
    a = Analysis(runtime=info.runtime, entry=info.entry)
    env_literals: list = []
    env_reads: dict = {}
    if info.runtime == "python":
        _analyze_python(root, info, a, env_literals, env_reads)
    elif info.runtime == "node":
        _analyze_node(root, info, a, env_literals, env_reads, js_syntax_checker)
    _build_config(root, info, a, env_literals, env_reads)
    a.commands = command_detector.merge_commands(a.commands)

    if a.syntax_errors:
        e = a.syntax_errors[0]
        a.risks.insert(0, f"Syntax Error: {e['file']} लाइन {e['line']} - {e['msg']}")
    if a.is_telegram and not any(c["kind"] == "token" for c in a.config):
        a.risks.append("Telegram Framework मिला पर Token कहाँ से आता है पहचान नहीं हुआ (शायद input()/अलग config). चलने पर Error आए तो Error Report देखें.")
    if a.hardcoded_secrets:
        a.risks.append("Secret सीधे Code/फाइल में लिखे हैं (सुरक्षित तरीका: Environment Variable). Hosting में वे Reports/Logs में छिपाए जाएँगे.")
    unknown_missing = [m for m in a.missing if not m["known"]]
    if unknown_missing:
        a.risks.append("अनजान Packages (Install से पहले आपकी अनुमति लगेगी): " + ", ".join(m["pip"] for m in unknown_missing[:8]))
    if info.entry and not a.syntax_errors and not (a.has_main_guard or a.entry_markers or a.main_function):
        a.risks.append("Entry फाइल में चलाने वाला हिस्सा (main/polling) साफ़ नहीं दिखा; Script शायद तुरंत खत्म हो जाए.")
    return a


# --------------------------------------------------------------- report
def format_analysis_html(a: Analysis, info: ProjectInfo, findings=None, secrets=()) -> str:
    L = []
    L.append("🔎 <b>Auto File Analysis</b>")
    langs = ", ".join(f"{k} ({v})" for k, v in sorted(info.languages.items())) or "—"
    L.append(f"📁 Files: {len(info.files)} | भाषाएँ: {esc(langs)}")
    rt = {"python": "Python", "node": "Node.js"}.get(a.runtime or "", "नहीं पहचाना")
    L.append(f"⚙️ Runtime: <b>{rt}</b> | Entry: <code>{esc(a.entry or '—')}</code>")
    if info.entry_candidates and len(info.entry_candidates) > 1:
        L.append("↳ अन्य संभावित Entry: " + esc(", ".join(info.entry_candidates[1:4])))
    fw = a.framework or "कोई Telegram Framework नहीं मिला"
    if a.framework_note:
        fw += f" ({a.framework_note})"
    L.append(f"🤖 Framework: {esc(fw)}")
    mark = ", ".join(sorted(set(a.entry_markers))[:3]) or ("main guard" if a.has_main_guard else "—")
    L.append(f"▶️ Entry point: {esc(mark)}")
    if a.third_party:
        L.append("📦 Third-party: " + esc(", ".join(t["import"] for t in a.third_party[:15])))
    if a.requirements:
        L.append(f"📄 requirements/package में {len(a.requirements) or len(a.package_json.get('dependencies', {}))} entries")
    if a.missing:
        L.append("➕ अलग से Install होंगे/पूछे जाएँगे: " + esc(", ".join(m["pip"] for m in a.missing[:10])))
    if a.pins:
        for p in a.pins:
            L.append(f"📌 Version pin: {esc(p['name'])}{esc(p['spec'])} - {esc(p['reason'])}")
    # config
    if a.config:
        L.append("🔐 <b>Configuration</b>")
        for c in a.config:
            if c["method"] == "source_present":
                st = "Code में पहले से मौजूद"
            elif c["method"] == "dotenv_present":
                st = ".env में मौजूद"
            elif c.get("optional"):
                st = "वैकल्पिक"
            else:
                st = "आपसे माँगा जाएगा"
            L.append(f"• {esc(c['name'])} — {st}")
    else:
        L.append("🔐 Token/API configuration की जरूरत नहीं मिली.")
    if a.other_env:
        L.append("ℹ️ अन्य Environment Variables (बिना default): " + esc(", ".join(sorted(set(a.other_env))[:8])))
    # commands
    if a.commands:
        L.append("⌨️ Commands: " + esc(" ".join("/" + c["name"] for c in a.commands[:25])))
    else:
        L.append("⌨️ Script में कोई Command नहीं मिला.")
    # risks
    if a.risks:
        L.append("⚠️ <b>संभावित समस्याएँ</b>")
        for r in a.risks[:8]:
            L.append("• " + esc(redact(r, secrets)))
    if findings:
        crit = [f for f in findings if f.severity == "critical"]
        warn = [f for f in findings if f.severity == "warning"]
        if crit:
            L.append(f"⛔ <b>गंभीर सुरक्षा समस्या ({len(crit)})</b>")
            for f in crit[:5]:
                L.append(f"• {esc(f.file)}:{f.line} — {esc(f.message)}")
        if warn:
            L.append(f"🟡 सुरक्षा चेतावनी ({len(warn)}): " + esc("; ".join(sorted({f.message for f in warn})[:3])))
    for n in info.notes:
        L.append("ℹ️ " + esc(n))
    return "\n".join(L)
