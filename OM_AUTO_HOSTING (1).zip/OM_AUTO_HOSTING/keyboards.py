"""keyboards.py - Reply Keyboard (मुख्य Menu) और Inline Keyboards.

telebot पर निर्भर हिस्सा सिर्फ़ यहीं है; buttons को पहले सादे (label, data) जोड़ों में बनाया जाता है.
"""
from __future__ import annotations

# 22 मुख्य Menu बटन (क्रम वही जो आपने बताया)
MENU = [
    "📤 Upload New Bot", "🤖 My Hosted Bots",
    "📂 Check Files", "🔎 Auto File Analyzer",
    "▶️ Start Bot", "⏹ Stop Bot",
    "🔄 Restart Bot", "📊 Bot Status",
    "📜 Live Logs", "🚨 Error Report",
    "⌨️ Bot Commands", "🔑 API / Token Settings",
    "📦 Dependency Manager", "🔥 Firebase Checker",
    "🖥 Server Status", "💻 CPU Usage",
    "🧠 RAM Usage", "💾 Disk Usage",
    "🟢 Running Bots", "🗄 Backup & Restore",
    "❓ Help & Instructions", "📞 Contact Owner",
]
ADMIN_BTN = "👑 Admin Panel"

ACTION_OF = {
    "📤 Upload New Bot": "upload", "🤖 My Hosted Bots": "mybots", "📂 Check Files": "files",
    "🔎 Auto File Analyzer": "analyzer", "▶️ Start Bot": "start", "⏹ Stop Bot": "stop",
    "🔄 Restart Bot": "restart", "📊 Bot Status": "status", "📜 Live Logs": "logs",
    "🚨 Error Report": "errors", "⌨️ Bot Commands": "commands", "🔑 API / Token Settings": "settings",
    "📦 Dependency Manager": "deps", "🔥 Firebase Checker": "firebase", "🖥 Server Status": "server",
    "💻 CPU Usage": "cpu", "🧠 RAM Usage": "ram", "💾 Disk Usage": "disk", "🟢 Running Bots": "running",
    "🗄 Backup & Restore": "backup", "❓ Help & Instructions": "help", "📞 Contact Owner": "contact",
    ADMIN_BTN: "admin",
}


def main_menu_rows(is_owner: bool) -> list[list[str]]:
    rows = [MENU[i:i + 2] for i in range(0, len(MENU), 2)]
    if is_owner:
        rows.append([ADMIN_BTN])
    return rows


# ---- telebot में बदलने वाले helper (telebot यहीं import होता है)
def reply_markup(is_owner: bool):
    from telebot import types
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    for row in main_menu_rows(is_owner):
        kb.row(*[types.KeyboardButton(t) for t in row])
    return kb


def inline_markup(buttons):
    """buttons: [[(label, callback_data) | (label, 'url:https://..')]]"""
    if not buttons:
        return None
    from telebot import types
    kb = types.InlineKeyboardMarkup()
    for row in buttons:
        btns = []
        for label, data in row:
            if data.startswith("url:"):
                btns.append(types.InlineKeyboardButton(label, url=data[4:]))
            else:
                btns.append(types.InlineKeyboardButton(label, callback_data=data[:64]))
        kb.row(*btns)
    return kb


# ---- Button layouts (सादी lists)
def bot_list_buttons(bots, action: str):
    """किसी Action के लिए Bot चुनने की list. action: start/stop/status/logs/..."""
    icon = {"running": "🟢", "stopped": "🔴", "failed": "❌", "finished": "⚪", "blocked": "⛔"}
    return [[(f"{icon.get(b['status'], '🟡')} {b['name']} (#{b['id']})", f"pick:{action}:{b['id']}")] for b in bots]


def bot_detail_buttons(bot_id: int, running: bool, auto_restart: bool):
    first = [("⏹ Stop", f"act:stop:{bot_id}")] if running else [("▶️ Start", f"act:start:{bot_id}")]
    return [
        first + [("🔄 Restart", f"act:restart:{bot_id}"), ("📊 Status", f"act:status:{bot_id}")],
        [("📜 Logs", f"act:logs:{bot_id}"), ("🧹 Clear Logs", f"act:clrlogs:{bot_id}"), ("🚨 Errors", f"act:errors:{bot_id}")],
        [("⌨️ Commands", f"act:cmds:{bot_id}"), ("🔑 Token/API", f"act:cfg:{bot_id}"), ("📦 Deps", f"act:deps:{bot_id}")],
        [("📂 Files", f"act:files:{bot_id}"), ("🔎 Analysis", f"act:analyze:{bot_id}")],
        [(f"🔁 Auto Restart: {'चालू' if auto_restart else 'बंद'}", f"act:autor:{bot_id}"), ("✏️ Rename", f"act:rename:{bot_id}")],
        [("🗑 Delete", f"act:del:{bot_id}")],
    ]


def confirm_buttons(yes_data: str, no_data: str = "noop"):
    return [[("✅ हाँ", yes_data), ("❌ नहीं", no_data)]]


def logs_buttons(bot_id: int):
    return [[("🔄 Refresh", f"act:logs:{bot_id}"), ("🧹 Clear", f"act:clrlogs:{bot_id}"), ("⬅️ Bot", f"bot:{bot_id}")]]


def settings_buttons(bot_id: int, missing_names: list[str]):
    rows = [[("🔑 Telegram Token बदलें", f"cfg:token:{bot_id}")], [("➕ API Key/Value जोड़ें", f"cfg:api:{bot_id}")]]
    for n in missing_names[:4]:
        rows.append([(f"❌ {n} दें", f"cfg:set:{bot_id}:{n[:30]}")])
    rows.append([("⌨️ Commands Menu सेट करें", f"act:setcmds:{bot_id}")])
    return rows


def deps_buttons(bot_id: int):
    return [[("♻️ Reinstall", f"dep:reinstall:{bot_id}"), ("🧪 pip check", f"dep:check:{bot_id}")],
            [("➕ Package जोड़ें", f"dep:add:{bot_id}")]]


def firebase_menu_buttons():
    return [[("🔍 Single URL जाँचें", "fb:single")],
            [("📋 मेरे अधिकृत URLs जाँचें", "fb:all")],
            [("📄 TXT File Import", "fb:import")],
            [("🔐 Auth Token सेट करें", "fb:auth"), ("🗑 URL हटाएँ", "fb:remove")]]


def export_buttons():
    return [[("JSON", "fb:exp:json"), ("TXT", "fb:exp:txt"), ("CSV", "fb:exp:csv")]]


def backup_buttons():
    return [[("💾 अपना Backup बनाओ", "bk:make")], [("♻️ Restore (मेरे Backups)", "bk:list")]]


def admin_buttons():
    return [
        [("📊 Stats", "adm:stats"), ("👥 Users", "adm:users")],
        [("➕ Friend जोड़ें", "adm:addf"), ("➖ Friend हटाएँ", "adm:remf")],
        [("🚫 Block", "adm:block"), ("✅ Unblock", "adm:unblock")],
        [("📢 Broadcast", "adm:bc"), ("🔒 Lock/Unlock", "adm:lock")],
        [("🤖 सभी Bots", "adm:bots"), ("🩺 Server Health", "adm:health")],
        [("🗃 DB Backup", "adm:dbbk"), ("♻️ DB Restore", "adm:dbrs")],
        [("📜 System Logs", "adm:syslog"), ("🔁 Hosting Restart", "adm:restart")],
        [("💾 GitHub Snapshot अभी", "adm:snap")],
    ]
