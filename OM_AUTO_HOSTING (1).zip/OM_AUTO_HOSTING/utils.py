"""utils.py - छोटे helper: HTML escape, लंबे message बाँटना, समय/साइज format."""
from __future__ import annotations

import html
import time
from datetime import datetime, timezone

TG_LIMIT = 3900  # Telegram 4096 से थोड़ा कम, सुरक्षा के लिए


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""), quote=False)


def pre(s: str, limit: int = 3000) -> str:
    s = str(s or "")
    if len(s) > limit:
        s = "…" + s[-limit:]
    return f"<pre>{esc(s)}</pre>"


def chunk_text(text: str, limit: int = TG_LIMIT) -> list[str]:
    """लंबा text लाइन-सीमा पर बाँटता है."""
    if len(text) <= limit:
        return [text]
    parts, cur = [], ""
    for line in text.split("\n"):
        while len(line) > limit:
            if cur:
                parts.append(cur)
                cur = ""
            parts.append(line[:limit])
            line = line[limit:]
        if len(cur) + len(line) + 1 > limit:
            parts.append(cur)
            cur = line
        else:
            cur = f"{cur}\n{line}" if cur else line
    if cur:
        parts.append(cur)
    return parts


def human_size(n: float) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def human_duration(seconds: float) -> str:
    s = int(max(0, seconds))
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    out = []
    if d:
        out.append(f"{d} दिन")
    if h:
        out.append(f"{h} घंटे")
    if m:
        out.append(f"{m} मिनट")
    if not out:
        out.append(f"{s} सेकंड")
    return " ".join(out[:2])


def now_ts() -> float:
    return time.time()


def iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def ago(ts_iso: str | None) -> str:
    if not ts_iso:
        return "—"
    try:
        dt = datetime.strptime(ts_iso, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return ts_iso
    return human_duration((datetime.now(timezone.utc) - dt).total_seconds()) + " पहले"
