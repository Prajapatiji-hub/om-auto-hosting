"""server_monitor.py - Server की CPU / RAM / Disk / Docker की जानकारी."""
from __future__ import annotations

import os
import shutil
import time

import psutil

from utils import esc, human_duration, human_size

FREE_NOTE = ("ℹ️ Free Server पर 24/7 Uptime की गारंटी नहीं होती: Provider Idle Instance को रोक/हटा सकता है, "
             "Capacity कम हो सकती है और Limits बदल सकती हैं.")


def cpu_text() -> str:
    cores = psutil.cpu_count() or 1
    pct = psutil.cpu_percent(interval=0.6)
    try:
        l1, l5, l15 = os.getloadavg()
        load = f"{l1:.2f} / {l5:.2f} / {l15:.2f}"
    except (OSError, AttributeError):
        load = "—"
    return f"💻 <b>CPU</b>\nउपयोग: {pct:.1f}%\nCores: {cores}\nLoad (1/5/15 मिनट): {load}"


def ram_text() -> str:
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    return (f"🧠 <b>RAM</b>\nकुल: {human_size(vm.total)} | उपयोग: {human_size(vm.used)} ({vm.percent:.0f}%)\n"
            f"खाली: {human_size(vm.available)}\nSwap: {human_size(sw.used)} / {human_size(sw.total)}")


def disk_text(path) -> str:
    u = shutil.disk_usage(path if os.path.exists(path) else "/")
    pct = u.used / u.total * 100 if u.total else 0
    return (f"💾 <b>Disk</b>\nकुल: {human_size(u.total)} | उपयोग: {human_size(u.used)} ({pct:.0f}%)\n"
            f"खाली: {human_size(u.free)}")


def docker_line(runner) -> str:
    try:
        ok, msg = runner.available()
    except Exception as e:  # pragma: no cover
        return f"🐳 Docker: ❌ {esc(str(e))}"
    return f"🐳 Runner: {'✅' if ok else '❌'} {esc(msg)}"


def server_status_text(cfg, db, runner) -> str:
    boot = psutil.boot_time()
    c = db.counts()
    try:
        running = len(runner.list_running())
    except Exception:
        running = c["running"]
    L = ["🖥 <b>Server Status</b>",
         f"⏱ Server Uptime: {human_duration(time.time() - boot)}",
         docker_line(runner),
         f"🤖 Hosted Bots: {c['bots']} | चल रहे: {running} | बंद: {c['stopped']} | Failed: {c['failed']}",
         cpu_text(), ram_text(), disk_text(cfg.data_dir), FREE_NOTE]
    if runner.name == "process":
        L.insert(2, "ℹ️ <b>PROCESS mode (Render Free):</b> हर Bot अलग Process है, Docker जैसा मज़बूत Isolation नहीं. सिर्फ़ भरोसेमंद दोस्तों के Bots रखें.")
    elif runner.name != "docker":
        L.insert(2, "⚠️ <b>LOCAL (असुरक्षित) Runner चालू है — सिर्फ़ टेस्ट के लिए!</b>")
    return "\n\n".join(L)


def health(cfg, db, runner) -> dict:
    vm = psutil.virtual_memory()
    u = shutil.disk_usage(cfg.data_dir if cfg.data_dir.exists() else "/")
    ok, msg = runner.available()
    problems = []
    if not ok:
        problems.append(msg)
    if vm.percent > 90:
        problems.append(f"RAM {vm.percent:.0f}% भरी")
    if u.used / u.total > 0.9:
        problems.append("Disk 90% से ज़्यादा भरा")
    return {"ok": not problems, "problems": problems, "ram": vm.percent, "disk": u.used / u.total * 100,
            "cpu": psutil.cpu_percent(interval=0.3)}


def running_bots_text(db, runner, owner_id=None) -> str:
    bots = [b for b in db.list_bots(owner_id) if b["status"] == "running"]
    if not bots:
        return "🟢 अभी कोई Bot नहीं चल रहा."
    L = [f"🟢 <b>चल रहे Bots ({len(bots)})</b>"]
    for b in bots:
        alive = runner.is_running(b["id"])
        s = runner.stats(b["id"]) if alive else {}
        L.append(f"• <b>{esc(b['name'])}</b> (ID {b['id']}) — " +
                 (f"CPU {s.get('cpu', 0):.1f}% | RAM {esc(s.get('mem_text', '—'))}" if alive else "⚠️ Process नहीं मिला"))
    return "\n".join(L)
