"""access_control.py - सिर्फ़ Owner और चुने हुए दोस्त Hosting Bot चला सकते हैं."""
from __future__ import annotations

import functools
import time


class AccessControl:
    def __init__(self, cfg, db):
        self.cfg = cfg
        self.db = db
        self._denied_at: dict[int, float] = {}
        self.sync_config_friends()

    def sync_config_friends(self):
        """.env की FRIEND_IDS को Database में जोड़ दो (हटाना सिर्फ़ /removefriend से)."""
        for fid in self.cfg.friend_ids:
            if fid != self.cfg.owner_id and not self.db.is_friend(fid):
                self.db.add_friend(fid, self.cfg.owner_id, note="from .env")

    def is_owner(self, uid: int) -> bool:
        return bool(uid) and uid == self.cfg.owner_id

    def is_allowed(self, uid: int) -> bool:
        if not uid:
            return False
        if self.db.is_blocked(uid) and not self.is_owner(uid):
            return False
        return self.is_owner(uid) or self.db.is_friend(uid)

    def role(self, uid: int) -> str:
        return "owner" if self.is_owner(uid) else ("friend" if self.is_allowed(uid) else "stranger")

    def should_reply_denied(self, uid: int) -> bool:
        """अनजान User को बार-बार जवाब न दें (spam रोकने के लिए 60 सेकंड में एक बार)."""
        now = time.time()
        last = self._denied_at.get(uid, 0)
        if now - last > 60:
            self._denied_at[uid] = now
            return True
        return False


DENIED_TEXT = ("🔒 यह एक निजी Hosting Bot है.\n"
               "सिर्फ़ Owner और उनके चुने हुए दोस्त इसे इस्तेमाल कर सकते हैं.\n"
               "अगर आप दोस्त हैं तो Owner को अपना Telegram ID भेजें: <code>{uid}</code>")
BLOCKED_TEXT = "⛔ आपका Access Owner ने बंद किया है."


def require_allowed(ctx):
    """Handler decorator: निजी चैट + Allowed User + Blocked नहीं."""
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(m, *a, **kw):
            user = getattr(m, "from_user", None)
            chat = getattr(m, "chat", None) or getattr(getattr(m, "message", None), "chat", None)
            if user is None:
                return None
            if chat is not None and getattr(chat, "type", "private") != "private":
                return None  # Group में कुछ नहीं करते
            ctx.db.upsert_user(user.id, getattr(user, "username", "") or "", getattr(user, "first_name", "") or "")
            if ctx.access.is_allowed(user.id) and not ctx.access.is_owner(user.id) and ctx.db.get_setting("locked") == "1":
                if ctx.access.should_reply_denied(user.id):
                    ctx.reply_text(user.id, "🔒 Hosting Bot अभी Owner ने Lock किया है. थोड़ी देर बाद कोशिश करें.")
                return None
            if not ctx.access.is_allowed(user.id):
                if ctx.access.should_reply_denied(user.id):
                    text = BLOCKED_TEXT if ctx.db.is_blocked(user.id) else DENIED_TEXT.format(uid=user.id)
                    ctx.reply_text(user.id, text)
                return None
            return fn(m, *a, **kw)
        return wrapper
    return deco


def require_owner(ctx):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(m, *a, **kw):
            user = getattr(m, "from_user", None)
            if user is None or not ctx.access.is_owner(user.id):
                if user is not None and ctx.access.is_allowed(user.id):
                    ctx.reply_text(user.id, "🔒 यह सुविधा सिर्फ़ Owner के लिए है.")
                return None
            return fn(m, *a, **kw)
        return wrapper
    return deco
