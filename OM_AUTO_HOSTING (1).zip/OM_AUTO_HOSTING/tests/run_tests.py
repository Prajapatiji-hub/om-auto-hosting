"""टेस्ट चलाकर TEST_REPORT.md बनाता है.  चलाएँ:  python tests/run_tests.py"""
import sys, time, unittest, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import test_all, test_render_mode

class Res(unittest.TextTestResult):
    def __init__(s, *a, **k):
        super().__init__(*a, **k); s.rows = []
    def _doc(s, t):
        return (t._testMethodDoc or t._testMethodName).strip().splitlines()[0]
    def addSuccess(s, t): super().addSuccess(t); s.rows.append(("PASS", t.id().split('.')[-1], s._doc(t), ""))
    def addFailure(s, t, e): super().addFailure(t, e); s.rows.append(("FAIL", t.id().split('.')[-1], s._doc(t), s._exc_info_to_string(e, t)[-600:]))
    def addError(s, t, e): super().addError(t, e); s.rows.append(("ERROR", t.id().split('.')[-1], s._doc(t), s._exc_info_to_string(e, t)[-600:]))
    def addSkip(s, t, r): super().addSkip(t, r); s.rows.append(("SKIP", t.id().split('.')[-1], s._doc(t), r))

if __name__ == "__main__":
    pattern = sys.argv[1] if len(sys.argv) > 1 else None
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(test_all), unittest.defaultTestLoader.loadTestsFromModule(test_render_mode)])
    def flat(x):
        for t in x:
            if isinstance(t, unittest.TestSuite):
                yield from flat(t)
            else:
                yield t
    tests = list(flat(suite))
    suite = unittest.TestSuite(t for t in tests if (not pattern or pattern in t.id()))
    t0 = time.time()
    runner = unittest.TextTestRunner(resultclass=Res, verbosity=2, stream=sys.stdout)
    res = runner.run(suite)
    out = ["# TEST REPORT\n", f"चलाए गए टेस्ट: {res.testsRun} | समय: {time.time()-t0:.0f}s | "
           f"PASS: {sum(1 for r in res.rows if r[0]=='PASS')} FAIL: {sum(1 for r in res.rows if r[0] in ('FAIL','ERROR'))} SKIP: {sum(1 for r in res.rows if r[0]=='SKIP')}\n",
           "> ⚠️ ये टेस्ट Docker/असली Telegram/असली Internet के बिना चले (LocalRunner + mock). देखें README_HINDI.md → 'क्या टेस्ट हुआ, क्या नहीं'.\n",
           "| नतीजा | टेस्ट | क्या जाँचा |", "|---|---|---|"]
    for st, name, doc, err in res.rows:
        out.append(f"| {st} | {name} | {doc} |")
    fails = [r for r in res.rows if r[0] in ("FAIL", "ERROR")]
    if fails:
        out.append("\n## Failures\n")
        for st, name, doc, err in fails:
            out.append(f"### {name}\n```\n{err}\n```")
    Path(__file__).parent.parent.joinpath("TEST_REPORT.md").write_text("\n".join(out), "utf-8")
    sys.exit(0 if res.wasSuccessful() else 1)
