"""टेस्ट के लिए नकली telebot (असली telebot इस टेस्ट Sandbox में Install नहीं है; Internet बंद है).
सिर्फ़ उतना API जितना हमारा कोड इस्तेमाल करता है."""
import sys
import types as _t
from types import SimpleNamespace as NS


class _Kb:
    def __init__(self, *a, **k):
        self.rows = []

    def row(self, *btns):
        self.rows.append(list(btns))

    def add(self, *btns):
        self.rows.append(list(btns))


class _Btn:
    def __init__(self, text, callback_data=None, url=None):
        self.text, self.callback_data, self.url = text, callback_data, url


class FakeTeleBot:
    def __init__(self, token="", **kw):
        self.sent = []          # (chat_id, text, reply_markup)
        self.docs = []          # (chat_id, name)
        self.deleted = []
        self.handlers = []      # (kind, kwargs, fn)
        self.files = {}         # file_id -> bytes
        self.answered = []
        self.edited = []

    # --- sending
    def send_message(self, chat_id, text, **kw):
        self.sent.append((chat_id, text, kw.get("reply_markup")))
        return NS(message_id=len(self.sent))

    def edit_message_text(self, text, chat_id, message_id, **kw):
        self.edited.append((chat_id, text))

    def send_document(self, chat_id, doc, **kw):
        name = getattr(doc, "name", "file")
        self.docs.append((chat_id, str(name)))

    def delete_message(self, chat_id, message_id):
        self.deleted.append((chat_id, message_id))

    def answer_callback_query(self, cid, *a, **k):
        self.answered.append(cid)

    def get_file(self, file_id):
        return NS(file_path=file_id)

    def download_file(self, path):
        return self.files[path]

    def set_my_commands(self, cmds):
        self.my_commands = cmds

    def stop_polling(self):
        self.stopped = True

    # --- registration
    def message_handler(self, commands=None, func=None, content_types=None, **kw):
        def deco(fn):
            self.handlers.append(("message", {"commands": commands, "func": func, "content_types": content_types or ["text"]}, fn))
            return fn
        return deco

    def callback_query_handler(self, func=None, **kw):
        def deco(fn):
            self.handlers.append(("callback", {"func": func}, fn))
            return fn
        return deco

    # --- dispatch helpers (टेस्ट के लिए)
    def feed_message(self, m):
        ctype = "document" if getattr(m, "document", None) else "text"
        for kind, kw, fn in self.handlers:
            if kind != "message" or ctype not in kw["content_types"]:
                continue
            if kw["commands"]:
                t = (getattr(m, "text", "") or "")
                if not t.startswith("/") or t.split()[0][1:].split("@")[0].lower() not in kw["commands"]:
                    continue
            if kw["func"] and not kw["func"](m):
                continue
            return fn(m)

    def feed_callback(self, c):
        for kind, kw, fn in self.handlers:
            if kind == "callback" and (kw["func"] is None or kw["func"](c)):
                return fn(c)

    def texts(self, chat_id=None):
        return [t for cid, t, _ in self.sent if chat_id is None or cid == chat_id]


def install():
    mod = _t.ModuleType("telebot")
    mod.TeleBot = FakeTeleBot
    types = _t.ModuleType("telebot.types")
    types.ReplyKeyboardMarkup = _Kb
    types.InlineKeyboardMarkup = _Kb
    types.KeyboardButton = lambda text, **k: text
    types.InlineKeyboardButton = _Btn
    types.BotCommand = lambda c, d: (c, d)
    mod.types = types
    sys.modules["telebot"] = mod
    sys.modules["telebot.types"] = types
    return mod


def msg(uid, text=None, doc=None, mid=1, first="T"):
    m = NS(from_user=NS(id=uid, username=f"u{uid}", first_name=first), chat=NS(id=uid, type="private"), text=text,
           message_id=mid, document=doc)
    return m


def doc(file_id, name, size=100):
    return NS(file_id=file_id, file_name=name, file_size=size)


def cb(uid, data, mid=1):
    return NS(id=f"cb{mid}", data=data, from_user=NS(id=uid, username=f"u{uid}", first_name="T"),
              message=NS(chat=NS(id=uid, type="private"), message_id=mid))
