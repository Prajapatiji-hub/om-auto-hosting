"""Render Mode टेस्ट: GitHub Snapshot, ProcessRunner (असली uid-बदलाव, ulimit), Restore/Recovery, Health URL.
⚠️ GitHub API नकली (local) सर्वर है; असली GitHub/Render पर नहीं चला."""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import tarfile
import threading
import time
import unittest
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import test_all as T
from test_all import OWNER, FRIEND, SAMPLES, wait_for, make_zip
import fake_telebot as ft

import admin_panel
import file_receiver
import handlers
import snapshot_manager as sm
from config import Config, fernet_from_secret
from context import build_context
from docker_runner import ProcessRunner, RunnerError
from github_store import GithubStore, StoreError


class FakeGitHub:
    def __init__(self):
        self.blobs, self.trees, self.commits, self.refs = {}, {}, {}, {}
        self.fail_get = None       # जैसे 500
        self.puts = 0
        self.token_ok = "tok"
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _body(self):
                n = int(self.headers.get("Content-Length", 0))
                return json.loads(self.rfile.read(n) or b"{}")

            def _j(self, code, obj):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def _auth(self):
                if self.headers.get("Authorization") != f"Bearer {outer.token_ok}":
                    self._j(403, {"message": "bad token"})
                    return False
                return True

            def do_POST(self):
                if not self._auth():
                    return
                p = self.path.split("/git/")[-1]
                b = self._body()
                if p == "blobs":
                    data = base64.b64decode(b["content"])
                    sha = hashlib.sha1(data).hexdigest()
                    outer.blobs[sha] = data
                    return self._j(201, {"sha": sha})
                if p == "trees":
                    sha = hashlib.sha1(json.dumps(b, sort_keys=True).encode()).hexdigest()
                    outer.trees[sha] = b["tree"]
                    return self._j(201, {"sha": sha})
                if p == "commits":
                    sha = hashlib.sha1((json.dumps(b, sort_keys=True) + str(time.time())).encode()).hexdigest()
                    outer.commits[sha] = b
                    return self._j(201, {"sha": sha})
                if p == "refs":
                    outer.refs[b["ref"]] = b["sha"]
                    return self._j(201, {"ref": b["ref"]})
                self._j(404, {})

            def do_PATCH(self):
                if not self._auth():
                    return
                ref = "refs/heads/" + self.path.split("/git/refs/heads/")[-1]
                b = self._body()
                if ref not in outer.refs:
                    return self._j(422, {"message": "Reference does not exist"})
                outer.refs[ref] = b["sha"]
                outer.puts += 1
                self._j(200, {"ref": ref})

            def do_GET(self):
                if outer.fail_get:
                    return self._j(outer.fail_get, {"message": "boom"})
                if not self._auth():
                    return
                ref = "refs/heads/main"
                if ref not in outer.refs:
                    return self._j(404, {"message": "Not Found"})
                tree = outer.trees[outer.commits[outer.refs[ref]]["tree"]]
                blob = outer.blobs[tree[0]["sha"]]
                self.send_response(200)
                self.send_header("Content-Length", str(len(blob)))
                self.end_headers()
                self.wfile.write(blob)

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.base = f"http://127.0.0.1:{self.srv.server_address[1]}"

    def store(self, token="tok"):
        return GithubStore(token, "me/om-hosting-data", "main", api_base=self.base)

    def close(self):
        self.srv.shutdown()


class RenderBase(T.Base):
    def setUp(self):
        self.gh = FakeGitHub()
        super().setUp()
        os.chmod(self.tmp, 0o755)   # mkdtemp 700 बनाता है; असली Render पर /app पहले से 755 है
        self.cfg.snapshot_interval_sec = 3600
        self.cfg.kick_debounce_sec = 0.3

    def tearDown(self):
        self.gh.close()
        super().tearDown()

    def make_ctx(self):
        cfg = self.cfg
        cfg.runner_mode = "process"
        cfg.allow_process_runner = True
        cfg.allow_unsafe_local = False
        cfg.ensure_dirs()
        runner = ProcessRunner(cfg)
        self.ctx = ctx = build_context(cfg, runner=runner, http_get=T.http_get, http_post=T.http_post)
        ctx.tg = ft.FakeTeleBot()
        ctx.send = handlers.make_sender(ctx)
        ctx.reply_text = lambda uid, text: ctx.send(uid, text)
        ctx.manager.set_notifier(ctx.send)
        admin_panel.register(ctx)
        file_receiver.register(ctx)
        handlers.register(ctx)
        self.tg = ctx.tg

    def snap(self):
        s = sm.Snapshotter(self.cfg, self.ctx.db, self.gh.store())
        s.restored_ok = True
        return s


class R01_Store(RenderBase):
    def test_store_roundtrip_single_commit_history(self):
        """GitHub Store: Snapshot भेजना/पढ़ना, और History नहीं बढ़ता (parentless commit)"""
        st = self.gh.store()
        self.assertIsNone(st.get_snapshot())          # पहली बार: कुछ नहीं (404)
        st.put_snapshot(b"one")
        st.put_snapshot(b"two-two")
        self.assertEqual(st.get_snapshot(), b"two-two")
        for c in self.gh.commits.values():
            self.assertEqual(c["parents"], [])        # कोई पुराना parent नहीं → history नहीं बढ़ती

    def test_bad_token_and_oversize(self):
        """गलत GitHub Token पर साफ़ संदेश; बहुत बड़ा Snapshot रोका जाता है"""
        bad = self.gh.store(token="wrong")
        with self.assertRaises(StoreError) as e:
            bad.put_snapshot(b"x")
        self.assertIn("Contents", str(e.exception))
        with self.assertRaises(StoreError):
            self.gh.store().put_snapshot(b"x" * (91 * 1024 * 1024))


class R02_Snapshot(RenderBase):
    def _make_bot(self, secret="supersecret-token-value"):
        self.upload_file(OWNER, SAMPLES / "missing_config.py")
        bid = self.first_bot()
        self.wait_status(bid, "awaiting_config")
        self.say(OWNER, secret, mid=9)
        self.assertTrue(self.wait_status(bid, "running"))
        return bid

    def test_pack_unpack_encrypted_roundtrip(self):
        """Snapshot: Encrypted, venv/node_modules/logs बाहर, Restore पर DB और Project लौटते हैं, path ठीक होते हैं"""
        bid = self._make_bot()
        proj = Path(self.ctx.db.get_bot(bid)["project_dir"])
        (proj / ".venv" / "bin").mkdir(parents=True)
        (proj / ".venv" / "bin" / "junk").write_text("x")
        (proj / "node_modules").mkdir()
        (proj / "node_modules" / "junk.js").write_text("x")
        blob, h = sm.pack(self.cfg, self.ctx.db)
        self.assertNotIn(b"supersecret", blob)
        self.assertNotIn(b"missing_config", blob)     # पूरा tar भी Encrypted
        # नए "Server" पर Restore
        cfg2 = Config()
        cfg2.__dict__.update(self.cfg.__dict__)
        cfg2.data_dir = self.tmp / "newdata"
        cfg2.ensure_dirs()
        n = sm.unpack(cfg2, blob)
        self.assertGreater(n, 1)
        from database import Database
        db2 = Database(cfg2.db_path)
        b2 = db2.get_bot(bid)
        self.assertEqual(Path(b2["project_dir"]), cfg2.data_dir / "users" / str(OWNER) / "bots" / str(bid) / "project")
        self.assertTrue((Path(b2["project_dir"]) / "missing_config.py").exists())
        self.assertFalse((Path(b2["project_dir"]) / ".venv").exists())
        self.assertFalse((Path(b2["project_dir"]) / "node_modules").exists())
        from token_manager import TokenManager
        self.assertEqual(TokenManager(cfg2, db2).get_api_value(OWNER, bid, "MY_API_KEY"), "supersecret-token-value")
        # वही data दोबारा pack करें तो hash वही (अनावश्यक Upload नहीं)
        _, h2 = sm.pack(self.cfg, self.ctx.db)
        self.assertEqual(h, h2)

    def test_malicious_snapshot_rejected_and_wrong_key(self):
        """खराब Snapshot (../ path, symlink) और गलत SECRET_KEY रोके जाते हैं"""
        for kind in ("traversal", "symlink"):
            buf = io.BytesIO()
            with tarfile.open(fileobj=buf, mode="w:gz") as tf:
                ti = tarfile.TarInfo("data/../../evil.txt" if kind == "traversal" else "data/link")
                if kind == "symlink":
                    ti.type = tarfile.SYMTYPE
                    ti.linkname = "/etc/passwd"
                    tf.addfile(ti)
                else:
                    ti.size = 1
                    tf.addfile(ti, io.BytesIO(b"x"))
            blob = fernet_from_secret(self.cfg.secret_key).encrypt(buf.getvalue())
            with self.assertRaises(StoreError):
                sm.unpack(self.cfg, blob)
        self.assertFalse((self.tmp / "evil.txt").exists())
        good, _ = sm.pack(self.cfg, self.ctx.db)
        other = Config()
        other.__dict__.update(self.cfg.__dict__)
        other.secret_key = "a-totally-different-long-secret-key"
        with self.assertRaises(StoreError) as e:
            sm.unpack(other, good)
        self.assertIn("SECRET_KEY", str(e.exception))

    def test_restore_error_never_overwrites(self):
        """GitHub पढ़ना फेल हुआ तो खाली Data से असली Snapshot नहीं मिटाता; 404 (पहली बार) हो तो Upload चलता है"""
        self.gh.store().put_snapshot(b"precious-existing-snapshot")
        before = self.gh.puts
        s = sm.Snapshotter(self.cfg, self.ctx.db, self.gh.store())
        self.gh.fail_get = 500
        self.assertEqual(s.restore(retries=1), "error")
        self.assertEqual(s.snapshot_now(force=True), "skipped")
        self.assertEqual(self.gh.puts, before)
        self.gh.fail_get = None
        # असली Snapshot "blob" नहीं है इसलिए unpack फेल → error → फिर भी Upload नहीं
        self.assertEqual(s.restore(retries=1), "error")
        self.assertEqual(s.snapshot_now(force=True), "skipped")
        # खाली repo → 'empty' → अब Upload ठीक
        self.gh.refs.clear()
        s2 = sm.Snapshotter(self.cfg, self.ctx.db, self.gh.store())
        self.assertEqual(s2.restore(retries=1), "empty")
        self.assertEqual(s2.snapshot_now(), "uploaded")
        self.assertEqual(s2.snapshot_now(), "unchanged")

    def test_kick_uploads_soon_after_change(self):
        """नया Bot बनते ही (बदलाव पर) कुछ सेकंड में Snapshot GitHub पर पहुँच जाता है"""
        s = self.snap()
        self.ctx.manager.on_change = s.kick
        s.start()
        try:
            self.upload_file(OWNER, SAMPLES / "plain_script.py")
            self.first_bot()
            self.assertTrue(wait_for(lambda: self.gh.refs, 20), "Snapshot नहीं गया")
        finally:
            s.stop()

    def test_secret_key_any_string(self):
        """SECRET_KEY कोई भी लंबा string हो (Render का generateValue) तो चलता है; वही string हमेशा वही key"""
        a = fernet_from_secret("Zm9vYmFy+/random=stuff-from-render-1234567890")
        b = fernet_from_secret("Zm9vYmFy+/random=stuff-from-render-1234567890")
        self.assertEqual(b.decrypt(a.encrypt(b"hi")), b"hi")


@unittest.skipUnless(hasattr(os, "getuid") and os.getuid() == 0 and shutil.which("setpriv"), "root और setpriv चाहिए")
class R03_ProcessIsolation(RenderBase):
    def test_bots_run_as_separate_uids_and_cannot_read_manager_or_each_other(self):
        """PROCESS mode (root): हर Bot अलग uid; Manager का DB और दूसरे Bot की files पढ़ नहीं सकता"""
        import psutil
        victim = "SECRETFILE"
        # पहले दूसरे User का Bot (उसमें "गुप्त" फाइल)
        z = self.sample_zip("b.zip", {"main.py": "import time\ntime.sleep(60)\n", victim: "top-secret-of-bot-b"})
        self.upload_file(FRIEND, z, "b.zip")
        b = self.first_bot(FRIEND)
        self.assertTrue(self.wait_status(b, "running"))
        other = self.cfg.users_dir / str(FRIEND) / "bots" / str(b) / "project" / victim
        self.assertTrue(other.exists())
        probe = f'''
import os, time
def can(p):
    try:
        open(p, "rb").read(1); return "READ"
    except Exception as e:
        return "DENIED:" + type(e).__name__
print("DB:", can({str(self.cfg.db_path)!r}), flush=True)
print("OTHER:", can({str(other)!r}), flush=True)
print("OWN:", can("probe_a.py"), flush=True)
print("UID:", os.getuid(), flush=True)
time.sleep(60)
'''
        self.upload(OWNER, "probe_a.py", probe.encode())
        a = self.first_bot()
        self.assertTrue(self.wait_status(a, "running"), self.all_text(OWNER))
        self.assertTrue(wait_for(lambda: "UID:" in self.ctx.manager.logs_text(OWNER, a), 25), self.ctx.manager.logs_text(OWNER, a))
        logs = self.ctx.manager.logs_text(OWNER, a)
        self.assertIn("DB: DENIED", logs)
        self.assertIn("OTHER: DENIED", logs)
        self.assertIn("OWN: READ", logs)
        self.assertIn(f"UID: {self.cfg.bot_uid_base + a}", logs)
        pid = self.ctx.runner.pid(a)
        kids = psutil.Process(pid).children(recursive=True)
        self.assertTrue(any(k.uids().real == self.cfg.bot_uid_base + a for k in kids), [k.uids() for k in kids])
        self.assertNotEqual(self.cfg.bot_uid_base + a, self.cfg.bot_uid_base + b)

    def test_fsize_limit_kills_big_writer(self):
        """ulimit: एक फाइल की साइज़ सीमा पार करने पर Bot रोका जाता है"""
        self.cfg.fsize_limit_mb = 1
        self.upload(OWNER, "big.py", b"f = open('big.dat', 'wb')\nfor i in range(50):\n    f.write(b'x' * 100000)\n    f.flush()\nprint('done')\n")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "failed", "finished", timeout=30), self.all_text(OWNER))
        size = (Path(self.ctx.db.get_bot(bid)["project_dir"]) / "big.dat").stat().st_size
        self.assertLessEqual(size, 1024 * 1024 + 4096)
        self.assertNotEqual(self.status(bid), "running")

    def test_memory_limit_enforced(self):
        """RAM सीमा: ज़्यादा Memory लेने वाला Bot Monitor रोक देता है और बताता है"""
        self.cfg.mem_limit_mb = 60
        self.upload(OWNER, "hog.py", b"import time\nx = bytearray(200 * 1024 * 1024)\nfor i in range(0, len(x), 4096):\n    x[i] = 1\nprint('allocated', flush=True)\ntime.sleep(60)\n")
        bid = self.first_bot()
        self.assertTrue(wait_for(lambda: "allocated" in self.ctx.manager.logs_text(OWNER, bid), 20))
        self.ctx.manager.enforce_memory_limits()
        self.assertFalse(self.ctx.runner.is_running(bid))
        self.assertEqual(self.status(bid), "failed")
        self.assertIn("RAM", self.all_text(OWNER))


class R04_Recovery(RenderBase):
    def test_full_cycle_snapshot_restore_recover_quietly(self):
        """Render Restart जैसा चक्र: Bot चलता है → Snapshot → पूरा Data मिटा → Restore → Bot अपने-आप वापस (शांत संदेश)"""
        z = self.sample_zip("p.zip", {"main.py": "import time\nprint('alive after restore', flush=True)\ntime.sleep(120)\n",
                                      "requirements.txt": "# कोई package नहीं\n"})
        self.upload_file(OWNER, z, "p.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"))
        self.assertTrue(wait_for(lambda: "Host हो गया" in self.all_text(OWNER), 15))
        s = self.snap()
        self.assertEqual(s.snapshot_now(force=True), "uploaded")
        # Container मर गया: Process और पूरा Data गायब
        self.ctx.runner.stop(bid)
        for b in list(self.ctx.runner.list_running()):
            self.ctx.runner.stop(b)
        shutil.rmtree(self.cfg.data_dir)
        self.make_ctx()
        s2 = sm.Snapshotter(self.cfg, None, self.gh.store())
        self.assertEqual(s2.restore(), "restored")
        # नया Context (नया Server): DB खुले, Bot की files लौटीं
        self.make_ctx()
        self.assertTrue((Path(self.ctx.db.get_bot(bid)["project_dir"]) / "main.py").exists())
        self.tg.sent.clear()
        res = self.ctx.manager.recover_all()
        self.assertEqual(res["reinstalling"], 1, res)    # requirements.txt है, venv नहीं → शांत Reinstall
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(bid) and "♻️" in self.all_text(OWNER), 60), self.all_text(OWNER))
        txt = self.all_text(OWNER)
        self.assertNotIn("Auto File Analysis", txt)
        self.assertNotIn("जाँच रहा हूँ", txt)
        self.assertTrue(wait_for(lambda: "alive after restore" in self.ctx.manager.logs_text(OWNER, bid), 15))

    def test_recover_without_deps_starts_directly(self):
        """Dependencies नहीं हैं तो Restore के बाद सीधे Start (reinstall नहीं)"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"))
        time.sleep(3.5)
        self.ctx.runner.stop(bid)
        self.ctx.db.update_bot(bid, status="running", desired_state="running")
        res = self.ctx.manager.recover_all()
        self.assertEqual((res["restarted"], res["reinstalling"]), (1, 0), res)
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(bid)))


class R05_Misc(RenderBase):
    def test_health_server(self):
        """Health URL: /health पर 200 'ok' (GET/HEAD), बाकी 404, कोई जानकारी लीक नहीं"""
        import render_main
        srv = render_main.start_health_server(0, "127.0.0.1")
        port = srv.server_address[1]
        try:
            r = urllib.request.urlopen(f"http://127.0.0.1:{port}/health")
            self.assertEqual((r.status, r.read()), (200, b"ok"))
            r = urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{port}/health", method="HEAD"))
            self.assertEqual(r.status, 200)
            with self.assertRaises(urllib.error.HTTPError) as e:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/data/om.db")
            self.assertEqual(e.exception.code, 404)
        finally:
            srv.shutdown()

    def test_gating_and_config_validation(self):
        """ProcessRunner सिर्फ़ Render पर; Render में GitHub Token/Repo बिना रोका जाता है"""
        c = Config()
        with self.assertRaises(RunnerError):
            ProcessRunner(c)
        c.render_mode = True
        c.runner_mode = "process"
        c.bot_token, c.owner_id, c.secret_key = "1111111111:" + "A" * 35, 1, "x" * 20
        probs = c.validate()
        self.assertTrue(any("GITHUB_DATA_TOKEN" in p for p in probs))
        self.assertTrue(any("DATA_REPO" in p for p in probs))
        c.github_data_token, c.data_repo = "tok", "me/om-hosting-data"
        self.assertEqual(c.validate(), [])
        c2 = Config()
        c2.runner_mode = "process"
        self.assertTrue(any("RUNNER_MODE=process" in p for p in c2.validate()))

    def test_snapshot_status_in_admin(self):
        """Admin Panel में Snapshot की स्थिति दिखती है और 'अभी Snapshot' बटन काम करता है"""
        s = self.snap()
        self.ctx.snapshotter = s
        self.click(OWNER, "adm:snap")
        self.assertIn("Snapshot GitHub पर सुरक्षित", self.all_text(OWNER))
        self.click(OWNER, "adm:health")
        self.assertIn("GitHub Snapshot", self.all_text(OWNER))

    def test_render_main_end_to_end_boot_uses_snapshot(self):
        """render_main.run(): खाली repo → चालू; Restore 'error' हो तो रुकता है (exit 3), असली Data सुरक्षित"""
        import render_main
        self.gh.fail_get = 500
        cfg = Config()
        cfg.__dict__.update(self.cfg.__dict__)
        cfg.render_mode = True
        cfg.github_data_token, cfg.data_repo = "tok", "me/om-hosting-data"
        cfg.port = 0
        store = self.gh.store()
        orig = sm.Snapshotter.restore
        sm.Snapshotter.restore = lambda self_, retries=1: orig(self_, retries=1)
        try:
            self.assertEqual(render_main.run(cfg, store=store), 3)
        finally:
            sm.Snapshotter.restore = orig


if __name__ == "__main__":
    unittest.main(verbosity=2)
