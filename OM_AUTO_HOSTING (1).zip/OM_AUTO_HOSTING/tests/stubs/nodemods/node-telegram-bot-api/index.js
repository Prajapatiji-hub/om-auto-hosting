// नकली node-telegram-bot-api (टेस्ट)
module.exports = class TelegramBot {
  constructor(token, opts) { console.log('node stub bot, token length ' + (token||'').length); setInterval(()=>{}, 1000); }
  onText() {} sendMessage() {}
};
