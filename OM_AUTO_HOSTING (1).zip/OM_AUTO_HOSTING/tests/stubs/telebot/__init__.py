# नकली 'telebot' - टेस्ट के लिए. असली Library नहीं है!
import os, sys, time
class TeleBot:
    def __init__(self, token, **kw):
        self.token = token
        # जानबूझकर Token print करते हैं ताकि Log-redaction टेस्ट हो सके
        print("TeleBot stub started, token=%s" % token, flush=True)
    def message_handler(self, **kw):
        return lambda fn: fn
    def reply_to(self, *a, **k): pass
    def infinity_polling(self, **kw):
        print("polling...", flush=True)
        while True:
            time.sleep(1)
