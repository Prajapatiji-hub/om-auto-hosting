import asyncio
class Bot:
    def __init__(self, token, **k): print("aiogram stub Bot ok len=%d" % len(token), flush=True)
class Router:
    def message(self, *a, **k): return lambda fn: fn
class Dispatcher:
    def __init__(self, *a, **k): pass
    def include_router(self, r): pass
    async def start_polling(self, bot):
        print("aiogram polling", flush=True)
        while True: await asyncio.sleep(1)
