class Command:
    def __init__(self, *a, **k): pass
class CommandStart:
    def __init__(self, *a, **k): pass
