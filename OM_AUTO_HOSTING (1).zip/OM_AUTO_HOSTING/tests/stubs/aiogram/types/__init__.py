class Message: pass
