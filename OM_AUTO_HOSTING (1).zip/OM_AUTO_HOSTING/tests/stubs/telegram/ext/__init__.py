import time
class ContextTypes:
    DEFAULT_TYPE = object
class CommandHandler:
    def __init__(self, *a, **k): pass
class _B:
    def __init__(self): self.t = None
    def token(self, t): self.t = t; return self
    def build(self):
        print("PTB stub app, token_len=%d" % len(self.t or ""), flush=True)
        return _App()
class _App:
    def add_handler(self, h): pass
    def run_polling(self):
        print("run_polling...", flush=True)
        while True: time.sleep(1)
class Application:
    @staticmethod
    def builder(): return _B()
class ApplicationBuilder: pass
