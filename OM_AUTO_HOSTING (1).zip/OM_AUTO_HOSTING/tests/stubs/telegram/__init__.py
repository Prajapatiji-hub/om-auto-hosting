class Update: pass
