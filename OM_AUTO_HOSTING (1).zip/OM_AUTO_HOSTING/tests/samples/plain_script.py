import time
print("plain script started", flush=True)
i = 0
while True:
    i += 1
    print(f"tick {i}", flush=True)
    time.sleep(1)
