import time
print("starting up", flush=True)
time.sleep(2)
raise RuntimeError("boom - intentional crash")
