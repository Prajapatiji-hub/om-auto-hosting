import os
import telebot

TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)


@bot.message_handler(commands=['start', 'help'])
def start(message):
    bot.reply_to(message, "Hello")


@bot.message_handler(commands=['status'])
def status(message):
    bot.reply_to(message, "ok")


if __name__ == "__main__":
    bot.infinity_polling()
