import os, time
KEY = os.environ["MY_API_KEY"]
print("running with key", flush=True)
time.sleep(30)
