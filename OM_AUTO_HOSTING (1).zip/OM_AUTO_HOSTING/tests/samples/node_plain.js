console.log('node plain started');
setInterval(() => console.log('tick'), 1000);
