import telebot
bot = telebot.TeleBot("123456789:AAHdummyDUMMYdummyDUMMYdummyDUMMY12")
@bot.message_handler(commands=['start'])
def s(m): bot.reply_to(m, "x")
bot.infinity_polling()
