import nonexistent_pkg_xyz
print("never reached")
