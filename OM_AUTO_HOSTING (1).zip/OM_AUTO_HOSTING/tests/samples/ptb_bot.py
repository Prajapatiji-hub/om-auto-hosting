from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

TOKEN = "YOUR_BOT_TOKEN_HERE"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("hi")


async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("settings")


def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler(["settings", "Export"], settings))
    app.run_polling()


if __name__ == "__main__":
    main()
