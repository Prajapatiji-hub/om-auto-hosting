import os
def main(:
    print("broken")
