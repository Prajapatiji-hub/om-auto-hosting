"""handlers.py - मुख्य Telegram Handlers: Menu बटन, Slash Commands, Callbacks और बातचीत (state) वाले इनपुट."""
from __future__ import annotations

import html as _html
import logging
import re

import admin_panel
import firebase_ui
import keyboards as K
import server_monitor
from access_control import require_allowed
from bot_manager import BotError
from utils import esc, human_size

log = logging.getLogger("om.handlers")

ACTIONS_NEEDING_BOT = {"start", "stop", "restart", "status", "logs", "errors", "commands", "settings", "deps", "files"}
ALIAS = {"cmds": "commands", "cfg": "settings"}

HELP_TEXT = (
    "❓ <b>OM AUTO HOSTING BOT — मदद</b>\n\n"
    "<b>कैसे चलाएँ?</b>\n"
    "1️⃣ Menu → <b>Upload New Bot</b> दबाएँ और अपनी <code>.py</code> / <code>.js</code> / <code>.zip</code> फाइल भेजें.\n"
    "2️⃣ मैं खुद फाइल जाँचूँगा: प्रकार, Libraries, Token/Key की जरूरत, Commands, सुरक्षा.\n"
    "3️⃣ जरूरत हो तो आपसे Bot का Token माँगूँगा (निजी चैट में भेजें; संदेश मिटा दिया जाता है).\n"
    "4️⃣ Libraries Sandbox में Install होंगी, फिर Bot Start होकर जाँचा जाएगा.\n"
    "5️⃣ सब ठीक रहा तो Bot Host हो जाएगा. Error आए तो Report मिलेगी.\n\n"
    "<b>ज़रूरी बातें</b>\n"
    "• हर Bot अलग Container में चलता है; एक बंद होने से दूसरा नहीं रुकता.\n"
    "• आपका Code मैं अपने-आप नहीं बदलता (सिर्फ़ आपकी अनुमति से एक placeholder लाइन).\n"
    "• अनजान Libraries Install से पहले आपकी अनुमति माँगी जाती है.\n"
    "• Free Server पर 24/7 Uptime की गारंटी नहीं है.\n\n"
    "<b>Commands:</b> /menu /upload /mybots /status /running /startbot /stopbot /restartbot /logs /errors /commands "
    "/firebase /server /backup /settings"
)


# ------------------------------------------------------------------ sending
def make_sender(ctx):
    def send(uid, text, buttons=None):
        from utils import chunk_text
        markup = K.inline_markup(buttons)
        chunks = chunk_text(text)
        for i, ch in enumerate(chunks):
            mk = markup if i == len(chunks) - 1 else None
            try:
                ctx.tg.send_message(uid, ch, parse_mode="HTML", reply_markup=mk, disable_web_page_preview=True)
            except Exception as e:
                if "parse" in str(e).lower():
                    plain = _html.unescape(re.sub(r"<[^>]+>", "", ch))
                    ctx.tg.send_message(uid, plain, reply_markup=mk)
                else:
                    raise
    return send


def send_menu(ctx, uid, text):
    ctx.tg.send_message(uid, text, parse_mode="HTML", reply_markup=K.reply_markup(ctx.access.is_owner(uid)))


def edit_or_send(ctx, call, text, buttons=None):
    if len(text) < 3900:
        try:
            ctx.tg.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="HTML",
                                     reply_markup=K.inline_markup(buttons), disable_web_page_preview=True)
            return
        except Exception:
            pass
    ctx.send(call.from_user.id, text, buttons)


def _delete(ctx, m):
    try:
        ctx.tg.delete_message(m.chat.id, m.message_id)
    except Exception:
        pass


# ---------------------------------------------------------- bot actions
def _missing_api_names(ctx, bot):
    an = ctx.manager.analysis_of(bot)
    return [c["name"] for c in ctx.tokens.config_status(bot, an) if c["status"] == "missing" and c["kind"] != "token"]


def run_bot_action(ctx, uid, action, bot_id):
    """(text, buttons) लौटाता है. BotError पर संदेश."""
    action = ALIAS.get(action, action)
    m = ctx.manager
    try:
        bot = m.get_for(uid, bot_id)
        running = ctx.runner.is_running(bot_id)
        if action == "start":
            return m.start_bot(uid, bot_id), None
        if action == "stop":
            return m.stop_bot(uid, bot_id), None
        if action == "restart":
            return m.restart_bot(uid, bot_id), None
        if action == "status":
            return m.status_text(uid, bot_id), K.bot_detail_buttons(bot_id, running, bool(bot["auto_restart"]))
        if action == "logs":
            return m.logs_text(uid, bot_id), K.logs_buttons(bot_id)
        if action == "clrlogs":
            return m.clear_logs(uid, bot_id), None
        if action == "errors":
            return m.error_text(uid, bot_id), None
        if action == "commands":
            return m.commands_text(uid, bot_id), [[("📋 Telegram Commands Menu सेट करें", f"act:setcmds:{bot_id}")]]
        if action == "setcmds":
            return m.apply_commands_menu(uid, bot_id), None
        if action == "settings":
            return m.config_text(uid, bot_id), K.settings_buttons(bot_id, _missing_api_names(ctx, bot))
        if action == "deps":
            return m.deps_text(uid, bot_id), K.deps_buttons(bot_id)
        if action == "files":
            return m.files_text(uid, bot_id), None
        if action == "analyze":
            return m.reanalyze_text(uid, bot_id), None
        if action == "autor":
            return m.toggle_auto_restart(uid, bot_id), None
        if action == "rename":
            ctx.db.set_state(uid, f"await_rename:{bot_id}", {})
            return "✏️ Bot का नया नाम भेजें (1-40 अक्षर).", None
        if action == "del":
            return f"🗑 <b>{esc(bot['name'])}</b> को हमेशा के लिए Delete करूँ? (फाइलें, Token, Logs सब मिट जाएँगे)", K.confirm_buttons(f"act:delc:{bot_id}")
        if action == "delc":
            return m.delete_bot(uid, bot_id), None
    except BotError as e:
        return "❌ " + esc(str(e)), None
    return "❌ अज्ञात क्रिया.", None


def with_bot(ctx, uid, action):
    bots = ctx.db.list_bots(uid)
    if not bots:
        ctx.send(uid, "आपका अभी कोई Bot नहीं है. Menu → <b>Upload New Bot</b> से शुरू करें.")
        return
    if len(bots) == 1:
        text, btns = run_bot_action(ctx, uid, action, bots[0]["id"])
        ctx.send(uid, text, btns)
        return
    ctx.send(uid, "कौन सा Bot?", K.bot_list_buttons(bots, action))


def do_action(ctx, uid, action):
    db = ctx.db
    if action != "upload" and action != "analyzer":
        st, _ = db.get_state(uid)
        if st:
            db.set_state(uid, "", {})
    if action == "upload":
        db.set_state(uid, "await_upload", {})
        ctx.send(uid, ctx_support_text(ctx))
    elif action == "mybots":
        bots = db.list_bots(uid)
        if not bots:
            ctx.send(uid, "आपका अभी कोई Hosted Bot नहीं है.")
        else:
            ctx.send(uid, f"🤖 <b>आपके Bots ({len(bots)}/{ctx.cfg.max_bots_per_user})</b>", K.bot_list_buttons(bots, "status"))
    elif action in ACTIONS_NEEDING_BOT:
        with_bot(ctx, uid, action)
    elif action == "analyzer":
        ctx.send(uid, "🔎 <b>Auto File Analyzer</b>\nकिसे जाँचूँ?",
                 [[("📄 नई फाइल (सिर्फ़ विश्लेषण)", "ana:file")], [("🤖 मेरा मौजूदा Bot", "ana:bot")]])
    elif action == "firebase":
        firebase_ui.menu(ctx, uid)
    elif action == "server":
        ctx.send(uid, server_monitor.server_status_text(ctx.cfg, ctx.db, ctx.runner))
    elif action == "cpu":
        ctx.send(uid, server_monitor.cpu_text())
    elif action == "ram":
        ctx.send(uid, server_monitor.ram_text())
    elif action == "disk":
        ctx.send(uid, server_monitor.disk_text(ctx.cfg.data_dir))
    elif action == "running":
        ctx.send(uid, server_monitor.running_bots_text(ctx.db, ctx.runner, uid))
    elif action == "backup":
        ctx.send(uid, "🗄 <b>Backup & Restore</b>\nआपके सभी Bots की फाइलें और Config (Tokens Encrypted) का Backup.\n"
                      "⚠️ Backup किसी को न भेजें.", K.backup_buttons())
    elif action == "help":
        send_menu(ctx, uid, HELP_TEXT)
    elif action == "contact":
        owner = ctx.cfg.owner_username
        link = f"url:https://t.me/{owner}" if owner else f"url:tg://user?id={ctx.cfg.owner_id}"
        ctx.send(uid, "📞 Owner से संपर्क करें:", [[("💬 Owner को Message", link)]])
    elif action == "admin":
        if not ctx.access.is_owner(uid):
            ctx.send(uid, "🔒 यह सिर्फ़ Owner के लिए है.")
        else:
            ctx.send(uid, admin_panel.stats_text(ctx), K.admin_buttons())


def ctx_support_text(ctx):
    from file_receiver import SUPPORT_TEXT
    return SUPPORT_TEXT.format(mb=min(ctx.cfg.max_upload_mb, 20))


# -------------------------------------------------------------- callbacks
def on_callback(ctx, call):
    uid = call.from_user.id
    data = call.data or ""
    try:
        ctx.tg.answer_callback_query(call.id)
    except Exception:
        pass
    if data == "noop":
        edit_or_send(ctx, call, "रद्द किया.")
        return
    if admin_panel.on_callback(ctx, call) or firebase_ui.on_callback(ctx, call):
        return
    parts = data.split(":")
    kind = parts[0]
    try:
        if kind in ("pick", "act") and len(parts) == 3:
            action, bot_id = parts[1], int(parts[2])
            text, btns = run_bot_action(ctx, uid, action, bot_id)
            if action in ("status", "logs"):
                edit_or_send(ctx, call, text, btns)
            else:
                ctx.send(uid, text, btns)
        elif kind == "bot" and len(parts) == 2:
            text, btns = run_bot_action(ctx, uid, "status", int(parts[1]))
            edit_or_send(ctx, call, text, btns)
        elif kind == "inst" and len(parts) == 4:
            ctx.send(uid, ctx.manager.confirm_dep(uid, int(parts[1]), parts[2], parts[3] == "y"))
        elif kind == "patch" and len(parts) == 4:
            ctx.send(uid, ctx.manager.apply_patch(uid, int(parts[1]), parts[2], parts[3] == "y"))
        elif kind == "cfg":
            _cfg_callback(ctx, uid, parts)
        elif kind == "dep":
            _dep_callback(ctx, uid, parts)
        elif kind == "ana":
            if parts[1] == "file":
                ctx.db.set_state(uid, "await_analyze", {})
                ctx.send(uid, "📄 जिस .py/.js/.zip को सिर्फ़ जाँचना है वह भेजें (Host नहीं होगी, बाद में हटा दी जाएगी).")
            else:
                with_bot(ctx, uid, "analyze")
        elif kind == "att" and len(parts) == 2:
            st, sd = ctx.db.get_state(uid)
            if st != "await_attach":
                ctx.send(uid, "यह अनुरोध पुराना हो गया, फाइल दोबारा भेजें.")
            else:
                ctx.db.set_state(uid, "", {})
                ctx.send(uid, ctx.manager.attach_file(uid, int(parts[1]), sd["path"], sd["name"]))
        elif kind == "bk":
            _backup_callback(ctx, uid, parts)
    except BotError as e:
        ctx.send(uid, "❌ " + esc(str(e)))
    except Exception:
        log.exception("callback failed: %s", data)
        ctx.send(uid, "❌ अंदरूनी समस्या हुई. दोबारा कोशिश करें.")


def _cfg_callback(ctx, uid, parts):
    act, bot_id = parts[1], int(parts[2])
    ctx.manager.get_for(uid, bot_id)
    if act == "token":
        ctx.db.set_state(uid, f"await_cfg:{bot_id}", {"bot_id": bot_id, "name": "__token__", "kind": "token"})
        ctx.send(uid, "🔑 नया Telegram Bot Token इसी निजी चैट में भेजें. (मैं संदेश मिटा दूँगा, Token Encrypted रहेगा.)")
    elif act == "api":
        ctx.db.set_state(uid, f"await_api_name:{bot_id}", {"bot_id": bot_id})
        ctx.send(uid, "➕ Environment Variable का नाम भेजें (जैसे <code>MY_API_KEY</code>). फिर उसकी Value पूछूँगा.")
    elif act == "set" and len(parts) > 3:
        name = parts[3]
        ctx.db.set_state(uid, f"await_cfg:{bot_id}", {"bot_id": bot_id, "name": name, "kind": "api"})
        ctx.send(uid, f"🔑 <code>{esc(name)}</code> की Value भेजें. (संदेश मिटा दिया जाएगा.)")


def _dep_callback(ctx, uid, parts):
    act, bot_id = parts[1], int(parts[2])
    bot = ctx.manager.get_for(uid, bot_id)
    if act == "reinstall":
        ctx.manager.reinstall_deps(uid, bot_id)
        ctx.send(uid, "♻️ Dependencies दोबारा Install हो रही हैं (Bot रुककर फिर चलेगा)…")
    elif act == "check":
        issues = ctx.deps.pip_check(bot) if bot["runtime"] != "node" else []
        ctx.send(uid, "✅ कोई Dependency टकराव नहीं." if not issues else "⚠️ pip check:\n<pre>" + esc("\n".join(issues)) + "</pre>")
    elif act == "add":
        ctx.db.set_state(uid, f"await_addpkg:{bot_id}", {})
        ctx.send(uid, "➕ Package का नाम भेजें (सिर्फ़ PyPI/npm नाम; URL/Git नहीं).")


def _backup_callback(ctx, uid, parts):
    from backup_manager import BackupError
    act = parts[1]
    try:
        if act == "make":
            b = ctx.backups.backup_user(uid)
            ctx.send(uid, f"✅ Backup तैयार ({human_size(b['size'])}). भेज रहा हूँ…")
            with open(b["path"], "rb") as f:
                ctx.tg.send_document(uid, f, caption="⚠️ यह Backup किसी को न भेजें.")
        elif act == "list":
            rows = ctx.backups.list_backups(uid, "user")
            if not rows:
                ctx.send(uid, "अभी कोई Backup नहीं है. पहले 'अपना Backup बनाओ' दबाएँ.")
            else:
                ctx.send(uid, "कौन सा Backup Restore करें? (Bots नए Bots के रूप में वापस आएँगे; मौजूदा Bots नहीं बदलेंगे)",
                         [[(f"#{r['id']} {r['created_at']} ({r['note']})", f"bk:rs:{r['id']}")] for r in rows])
        elif act == "rs":
            ctx.send(uid, f"♻️ Backup #{parts[2]} Restore करूँ?", K.confirm_buttons(f"bk:rsy:{parts[2]}"))
        elif act == "rsy":
            ids = ctx.backups.restore_user(uid, int(parts[2]))
            ctx.send(uid, f"✅ {len(ids)} Bot(s) वापस आए. Dependencies Install करके Start कर रहा हूँ…")
            note = ctx.db.get_setting(f"restore_note_{uid}")
            if note:
                ctx.send(uid, "⚠️ " + esc(note))
                ctx.db.set_setting(f"restore_note_{uid}", "")
            for bid in ids:
                ctx.manager.run_bg(ctx.manager._continue, bid)
    except BackupError as e:
        ctx.send(uid, "❌ " + esc(str(e)))


# ------------------------------------------------------------------ text
def on_text(ctx, m):
    uid = m.from_user.id
    text = (m.text or "").strip()
    action = K.ACTION_OF.get(text)
    if action:
        do_action(ctx, uid, action)
        return
    state, sd = ctx.db.get_state(uid)
    if not state:
        ctx.send(uid, "नीचे के Menu से चुनें, या फाइल भेजें. मदद: /help")
        return
    if firebase_ui.handle_text_state(ctx, m, state, sd):
        return
    try:
        if state.startswith("await_cfg:"):
            _delete(ctx, m)
            bot_id = int(state.split(":")[1])
            ok, msg = ctx.manager.provide_value(uid, bot_id, sd.get("name", "__token__"), text)
            if ok:
                ctx.db.set_state(uid, "", {})
                ctx.send(uid, "✅ " + esc(msg) + "\n(आपका संदेश मैंने मिटा दिया.)")
            else:
                ctx.send(uid, "❌ " + esc(msg) + "\nफिर से भेजें, या Menu से कुछ और चुनें.")
        elif state.startswith("await_api_name:"):
            bot_id = int(state.split(":")[1])
            name = ctx.manager.add_manual_config(uid, bot_id, text)
            ctx.db.set_state(uid, f"await_cfg:{bot_id}", {"bot_id": bot_id, "name": name, "kind": "api"})
            ctx.send(uid, f"🔑 अब <code>{esc(name)}</code> की Value भेजें (संदेश मिटा दिया जाएगा).")
        elif state.startswith("await_rename:"):
            ctx.db.set_state(uid, "", {})
            ctx.send(uid, ctx.manager.rename_bot(uid, int(state.split(":")[1]), text))
        elif state.startswith("await_addpkg:"):
            ctx.db.set_state(uid, "", {})
            ok, msg = ctx.manager.add_package(uid, int(state.split(":")[1]), text)
            ctx.send(uid, ("✅ " if ok else "❌ ") + esc(msg))
        elif state.startswith("adm_"):
            if not ctx.access.is_owner(uid):
                return
            ctx.db.set_state(uid, "", {})
            which = state[4:]
            if which == "addf":
                ctx.send(uid, admin_panel.add_friend(ctx, uid, admin_panel._int(text)))
            elif which == "remf":
                ctx.send(uid, admin_panel.remove_friend(ctx, admin_panel._int(text)))
            elif which == "block":
                ctx.send(uid, admin_panel.block(ctx, admin_panel._int(text)))
            elif which == "unblock":
                ctx.send(uid, admin_panel.unblock(ctx, admin_panel._int(text)))
            elif which == "bc":
                ctx.send(uid, admin_panel.broadcast(ctx, text))
        elif state in ("await_upload", "await_analyze", "await_attach", "await_fb_txt"):
            ctx.send(uid, "📎 कृपया फाइल (Document) भेजें. रद्द करने के लिए Menu का कोई बटन दबाएँ.")
        else:
            ctx.db.set_state(uid, "", {})
            ctx.send(uid, "नीचे के Menu से चुनें. मदद: /help")
    except BotError as e:
        ctx.send(uid, "❌ " + esc(str(e)))


# --------------------------------------------------------------- register
COMMAND_ACTION = {
    "upload": "upload", "mybots": "mybots", "status": "status", "running": "running", "startbot": "start",
    "stopbot": "stop", "restartbot": "restart", "logs": "logs", "errors": "errors", "commands": "commands",
    "firebase": "firebase", "server": "server", "backup": "backup", "settings": "settings", "admin": "admin",
}


def welcome(ctx, uid, first_name):
    role = "👑 Owner" if ctx.access.is_owner(uid) else "🤝 Premium दोस्त"
    send_menu(ctx, uid,
              f"नमस्ते {esc(first_name or '')}! 👋\n<b>OM AUTO HOSTING BOT</b> में स्वागत है.\n"
              f"आपकी पहचान: {role} (सभी सुविधाएँ, कोई Approval/Payment नहीं).\n\n"
              "अपनी Python/JavaScript Bot की फाइल (.py / .js / .zip) भेजें — बाकी मैं संभाल लूँगा: "
              "जाँच → Libraries → Token माँगना → Test → Host.\n"
              "Menu नीचे है. मदद के लिए /help")


def register(ctx):
    tg = ctx.tg
    allowed = require_allowed(ctx)

    @tg.message_handler(commands=["start", "menu"])
    @allowed
    def _start(m):
        welcome(ctx, m.from_user.id, m.from_user.first_name)

    @tg.message_handler(commands=["help"])
    @allowed
    def _help(m):
        send_menu(ctx, m.from_user.id, HELP_TEXT)

    @tg.message_handler(commands=list(COMMAND_ACTION))
    @allowed
    def _cmd(m):
        name = (m.text or "").split()[0][1:].split("@")[0].lower()
        action = COMMAND_ACTION.get(name)
        if action:
            do_action(ctx, m.from_user.id, action)

    @tg.callback_query_handler(func=lambda c: True)
    @allowed
    def _cb(call):
        on_callback(ctx, call)

    @tg.message_handler(func=lambda m: True, content_types=["text"])
    @allowed
    def _text(m):
        if (m.text or "").startswith("/"):
            ctx.send(m.from_user.id, "यह Command मुझे नहीं पता. /help देखें.")
            return
        on_text(ctx, m)
