"""project_detector.py - फाइल/Project का प्रकार और Entry File पहचानना."""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

from security_manager import iter_project_files

LANG_BY_EXT = {
    ".py": "Python", ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript", ".ts": "TypeScript",
    ".html": "HTML", ".htm": "HTML", ".css": "CSS", ".php": "PHP", ".java": "Java", ".kt": "Kotlin",
    ".cpp": "C++", ".cc": "C++", ".c": "C", ".h": "C/C++", ".cs": "C#", ".go": "Go", ".rs": "Rust",
    ".rb": "Ruby", ".sh": "Shell", ".dart": "Dart", ".swift": "Swift", ".apk": "Android APK",
    ".aab": "Android Bundle", ".exe": "Windows EXE", ".jar": "Java JAR",
}
DATA_EXT = {".json", ".txt", ".md", ".csv", ".yaml", ".yml", ".ini", ".cfg", ".toml", ".env", ".db", ".sqlite"}

PY_PREFERRED = ["main.py", "bot.py", "app.py", "run.py", "start.py", "index.py", "__main__.py"]
JS_PREFERRED = ["index.js", "main.js", "bot.js", "app.js", "server.js", "start.js", "index.mjs"]

_BOT_MARKERS = re.compile(
    r"infinity_polling|\.polling\(|run_polling|start_polling|run_until_disconnected|bot\.launch|\.startPolling|"
    r"TelegramBot\(|new Telegraf|new Bot\(|\.run\(\)|Client\(|TeleBot\(|Application\.builder|Dispatcher\("
)
_MAIN_GUARD = re.compile(r"""if\s+__name__\s*==\s*["']__main__["']""")
_NOT_ENTRY = {"setup.py", "config.py", "settings.py", "constants.py", "utils.py", "helpers.py", "conftest.py"}


@dataclass
class ProjectInfo:
    root: str = ""
    files: list = field(default_factory=list)
    languages: dict = field(default_factory=dict)
    runtime: str | None = None            # python | node | None
    runnable: bool = False
    entry: str | None = None
    entry_candidates: list = field(default_factory=list)
    has_requirements: bool = False
    has_package_json: bool = False
    has_env_example: bool = False
    has_dotenv: bool = False
    unsupported: list = field(default_factory=list)   # इंसानी message
    notes: list = field(default_factory=list)

    def to_dict(self):
        d = self.__dict__.copy()
        d["files"] = self.files[:200]
        return d


def detect_file_type(filename: str, size: int = 0) -> dict:
    """एक अकेली अपलोड की गई फाइल का प्रकार."""
    name = os.path.basename(filename or "")
    low = name.lower()
    ext = os.path.splitext(low)[1]
    info = {"name": name, "ext": ext, "size": size, "kind": "unknown", "label": ext or "बिना extension", "hostable": False}
    if low == "requirements.txt":
        info.update(kind="requirements", label="Python requirements.txt")
    elif low == "package.json":
        info.update(kind="package_json", label="Node package.json")
    elif low in (".env.example", "env.example", ".env.sample"):
        info.update(kind="env_example", label=".env.example (Config का नमूना)")
    elif low == ".env":
        info.update(kind="dotenv", label=".env (Secrets की फाइल)")
    elif ext == ".py":
        info.update(kind="python", label="Python script", hostable=True)
    elif ext in (".js", ".mjs", ".cjs"):
        info.update(kind="javascript", label="JavaScript (Node.js) script", hostable=True)
    elif ext == ".zip":
        info.update(kind="zip", label="ZIP Project", hostable=True)
    elif ext == ".json":
        info.update(kind="json", label="JSON data/config")
    elif ext == ".txt":
        info.update(kind="text", label="Text फाइल")
    elif ext in LANG_BY_EXT:
        info.update(kind="other_language", label=f"{LANG_BY_EXT[ext]} फाइल")
    elif ext in DATA_EXT:
        info.update(kind="data", label=f"Data फाइल ({ext})")
    return info


def _read(path: Path, limit=200_000) -> str:
    try:
        return path.read_bytes()[:limit].decode("utf-8", "ignore")
    except OSError:
        return ""


def _score_py(path: Path, root: Path) -> int:
    text = _read(path)
    name = path.name
    s = 0
    if _MAIN_GUARD.search(text):
        s += 5
    if _BOT_MARKERS.search(text):
        s += 4
    if re.search(r"^\s*(import|from)\s+(telebot|telegram|aiogram|pyrogram|telethon)\b", text, re.M):
        s += 3
    if name in PY_PREFERRED:
        s += 3 + (len(PY_PREFERRED) - PY_PREFERRED.index(name)) * 0.1
    if name in _NOT_ENTRY or name.startswith("test_"):
        s -= 4
    depth = len(path.relative_to(root).parts) - 1
    s -= depth * 2
    return s


def _score_js(path: Path, root: Path) -> int:
    text = _read(path)
    name = path.name
    s = 0
    if _BOT_MARKERS.search(text):
        s += 4
    if re.search(r"require\(['\"](node-telegram-bot-api|telegraf|grammy)|from ['\"](telegraf|grammy|node-telegram-bot-api)", text):
        s += 3
    if name in JS_PREFERRED:
        s += 3 + (len(JS_PREFERRED) - JS_PREFERRED.index(name)) * 0.1
    if name.startswith("test") or name.endswith(".test.js"):
        s -= 4
    s -= (len(path.relative_to(root).parts) - 1) * 2
    return s


def scan_project(root, runtimes: dict | None = None) -> ProjectInfo:
    """Project folder को पढ़कर ProjectInfo बनाता है.

    runtimes: {'python': True, 'node': True} - जो Runtime उपलब्ध नहीं उसे चलाने का दावा नहीं करते.
    """
    runtimes = runtimes or {"python": True, "node": True}
    root = Path(root)
    info = ProjectInfo(root=str(root))
    py_files: list[Path] = []
    js_files: list[Path] = []
    for p in iter_project_files(root):
        rel = str(p.relative_to(root))
        info.files.append(rel)
        ext = p.suffix.lower()
        lang = LANG_BY_EXT.get(ext)
        if lang:
            info.languages[lang] = info.languages.get(lang, 0) + 1
        if ext == ".py":
            py_files.append(p)
        elif ext in (".js", ".mjs", ".cjs"):
            js_files.append(p)
        low = p.name.lower()
        if rel == "requirements.txt":
            info.has_requirements = True
        elif rel == "package.json":
            info.has_package_json = True
        elif low in (".env.example", "env.example", ".env.sample") and len(p.relative_to(root).parts) == 1:
            info.has_env_example = True
        elif low == ".env" and len(p.relative_to(root).parts) == 1:
            info.has_dotenv = True

    # runtime चुनना
    choice = None
    if info.has_package_json and not py_files:
        choice = "node"
    elif py_files and not js_files:
        choice = "python"
    elif js_files and not py_files:
        choice = "node"
    elif py_files and js_files:
        if info.has_requirements or any(f.name in PY_PREFERRED for f in py_files):
            choice = "python"
        elif info.has_package_json:
            choice = "node"
        else:
            choice = "python" if len(py_files) >= len(js_files) else "node"
        info.notes.append("Project में Python और JavaScript दोनों हैं; " + ("Python" if choice == "python" else "Node.js") + " वाला हिस्सा चुना गया.")

    # Entry
    cands: list[tuple[float, str]] = []
    if choice == "python":
        for f in py_files:
            if "site-packages" in f.parts:
                continue
            cands.append((_score_py(f, root), str(f.relative_to(root))))
    elif choice == "node":
        pkg_main = None
        pj = root / "package.json"
        if pj.exists():
            try:
                data = json.loads(_read(pj))
                pkg_main = data.get("main")
                start = (data.get("scripts") or {}).get("start", "")
                m = re.search(r"node\s+([\w./-]+\.(?:m|c)?js)", start)
                if m:
                    cands.append((20, m.group(1).lstrip("./")))
                if pkg_main:
                    cands.append((18, pkg_main.lstrip("./")))
            except (ValueError, AttributeError):
                info.notes.append("package.json पढ़ी नहीं जा सकी (JSON गलत है).")
        for f in js_files:
            cands.append((_score_js(f, root), str(f.relative_to(root))))
    seen, ordered = set(), []
    for sc, rel in sorted(cands, key=lambda x: -x[0]):
        if rel in seen or not (root / rel).is_file():
            continue
        seen.add(rel)
        ordered.append((sc, rel))
    info.entry_candidates = [r for _, r in ordered[:6]]
    if ordered:
        info.entry = ordered[0][1]
        if len(ordered) > 1 and ordered[0][0] - ordered[1][0] < 1.5:
            info.notes.append(f"कई संभावित Entry मिलीं; '{info.entry}' चुनी गई. बाकी: {', '.join(info.entry_candidates[1:4])}")

    # Runtime उपलब्धता और असमर्थित भाषाएँ
    info.runtime = choice
    if choice and info.entry:
        if runtimes.get(choice):
            info.runnable = True
        else:
            info.unsupported.append(f"{'Python' if choice == 'python' else 'Node.js'} Runtime इस Server पर उपलब्ध नहीं है, इसलिए चलाना संभव नहीं.")
    elif choice and not info.entry:
        info.unsupported.append("Entry फाइल नहीं मिली.")
    if not choice:
        other = [k for k in info.languages if k not in ("Python", "JavaScript")]
        if other:
            info.unsupported.append(
                "यह Project " + ", ".join(sorted(other)) + " का है. अभी सिर्फ़ Python और Node.js (JavaScript) Bots को Host करना समर्थित है; "
                "बाकी भाषाओं के लिए Runtime इस Hosting System में नहीं है.")
        else:
            info.unsupported.append("कोई .py या .js फाइल नहीं मिली.")
    elif choice:
        others = [k for k in info.languages if k not in ("Python", "JavaScript", "Shell", "HTML", "CSS")]
        if others:
            info.notes.append("पहचानी गई दूसरी भाषाएँ (चलाई नहीं जाएँगी): " + ", ".join(sorted(others)))
    return info
