"""token_manager.py - Telegram Token और API Keys को सुरक्षित (Encrypted) रखना.

- हर Bot का Token अलग, Fernet से Encrypted (key = .env का SECRET_KEY).
- Token कभी Logs/Reports/Messages में वापस नहीं दिखता (सिर्फ़ masked रूप).
- कोई API Key अपने-आप बनाकर "असली" नहीं बताई जाती; सिर्फ़ User की दी हुई Key इस्तेमाल होती है.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

import requests
from cryptography.fernet import Fernet, InvalidToken

from config import fernet_from_secret
from security_manager import TOKEN_RE, mask_secret
from utils import iso_now

TOKEN_FORMAT = re.compile(r"^\d{6,12}:[A-Za-z0-9_-]{30,}$")
_BAD_LITERAL = re.compile(r"[\"'\\\n\r`]")


class TokenError(Exception):
    pass


class TokenManager:
    def __init__(self, cfg, db, http_get=None, http_post=None):
        self.cfg = cfg
        self.db = db
        try:
            self.fernet = fernet_from_secret(cfg.secret_key)
        except Exception as e:
            raise TokenError(f"SECRET_KEY सही Fernet key नहीं है: {e}")
        self._get = http_get or (lambda url, **kw: requests.get(url, **kw))
        self._post = http_post or (lambda url, **kw: requests.post(url, **kw))

    # ------------------------------------------------------- encryption
    def enc(self, s: str) -> str:
        return self.fernet.encrypt(s.encode()).decode()

    def dec(self, s: str) -> str:
        try:
            return self.fernet.decrypt(s.encode()).decode()
        except InvalidToken:
            raise TokenError("Token खोला नहीं जा सका (SECRET_KEY बदल गई होगी).")

    # ---------------------------------------------------- Telegram checks
    @staticmethod
    def valid_format(token: str) -> bool:
        return bool(TOKEN_FORMAT.match((token or "").strip()))

    def verify(self, token: str) -> dict:
        """getMe से जाँच. {'ok':bool, 'kind':..., 'username', 'id', 'message'} (Token कभी नहीं लौटता)."""
        token = (token or "").strip()
        if not self.valid_format(token):
            return {"ok": False, "kind": "format", "message": "Token का format गलत है. सही Token ऐसा दिखता है: 123456789:ABCdef... (@BotFather से मिलता है)."}
        if token == self.cfg.bot_token:
            return {"ok": False, "kind": "same_as_host", "message": "यह तो Hosting Bot का अपना Token है. Hosted Bot के लिए अलग Bot बनाकर उसका Token दें."}
        try:
            r = self._get(f"https://api.telegram.org/bot{token}/getMe", timeout=15)
            data = r.json()
        except requests.RequestException:
            return {"ok": False, "kind": "network", "message": "Telegram से जुड़ नहीं सका (Internet/Connection समस्या). थोड़ी देर बाद फिर कोशिश करें."}
        except ValueError:
            return {"ok": False, "kind": "network", "message": "Telegram से अजीब जवाब मिला. बाद में फिर कोशिश करें."}
        if data.get("ok"):
            res = data.get("result", {})
            return {"ok": True, "kind": "ok", "username": res.get("username", ""), "id": res.get("id"),
                    "message": f"Token सही है (@{res.get('username', '')})."}
        code = data.get("error_code")
        if code in (401, 404):
            return {"ok": False, "kind": "invalid", "message": "Telegram ने यह Token नहीं माना (गलत या Revoke हो चुका). @BotFather से सही Token लें."}
        if code == 429:
            return {"ok": False, "kind": "network", "message": "Telegram ने अभी रोका है (बहुत ज़्यादा requests). कुछ देर बाद कोशिश करें."}
        return {"ok": False, "kind": "unknown", "message": f"Token जाँच में समस्या (code {code})."}

    def set_my_commands(self, token: str, commands: list[dict]) -> tuple[bool, str]:
        if not commands:
            return False, "कोई समर्थित Command नहीं मिला, Menu नहीं बदला."
        try:
            r = self._post(f"https://api.telegram.org/bot{token}/setMyCommands", json={"commands": commands}, timeout=15)
            ok = bool(r.json().get("ok"))
            return ok, ("Commands Menu सेट हो गया." if ok else "Telegram ने Commands Menu नहीं माना.")
        except (requests.RequestException, ValueError):
            return False, "Commands Menu सेट नहीं हो सका (Connection समस्या)."

    # --------------------------------------------------- bot token store
    def save_bot_token(self, bot_id: int, owner_id: int, token: str, info: dict | None = None):
        info = info or {}
        self.db.x("INSERT OR REPLACE INTO bot_tokens(bot_id,owner_id,token_enc,tg_bot_id,bot_username,validated,set_at)"
                  " VALUES(?,?,?,?,?,?,?)",
                  (bot_id, owner_id, self.enc(token.strip()), info.get("id"), info.get("username", ""),
                   1 if info.get("ok") else 0, iso_now()))

    def get_bot_token(self, bot_id: int, owner_id: int) -> str | None:
        """सिर्फ़ Bot के Owner को (अंदरूनी इस्तेमाल के लिए); Message में कभी नहीं भेजना."""
        row = self.db.q1("SELECT token_enc FROM bot_tokens WHERE bot_id=? AND owner_id=?", (bot_id, owner_id))
        return self.dec(row["token_enc"]) if row else None

    def token_info(self, bot_id: int, owner_id: int) -> dict | None:
        row = self.db.q1("SELECT bot_username, validated, set_at, tg_bot_id, token_enc FROM bot_tokens WHERE bot_id=? AND owner_id=?",
                         (bot_id, owner_id))
        if not row:
            return None
        try:
            masked = mask_secret(self.dec(row["token_enc"]))
        except TokenError:
            masked = "(पढ़ा नहीं जा सका)"
        return {"username": row["bot_username"], "validated": bool(row["validated"]), "set_at": row["set_at"],
                "masked": masked, "tg_bot_id": row["tg_bot_id"]}

    def token_used_elsewhere(self, tg_bot_id, bot_id: int) -> bool:
        if not tg_bot_id:
            return False
        r = self.db.q1("SELECT 1 x FROM bot_tokens WHERE tg_bot_id=? AND bot_id<>?", (tg_bot_id, bot_id))
        return r is not None

    # -------------------------------------------------------- api configs
    def save_api_value(self, owner_id: int, bot_id: int, name: str, value: str):
        self.db.x("INSERT OR REPLACE INTO api_configurations(owner_id,bot_id,key_name,value_enc,set_at) VALUES(?,?,?,?,?)",
                  (owner_id, bot_id, name, self.enc(value), iso_now()))

    def get_api_value(self, owner_id: int, bot_id: int, name: str) -> str | None:
        r = self.db.q1("SELECT value_enc FROM api_configurations WHERE owner_id=? AND bot_id=? AND key_name=?",
                       (owner_id, bot_id, name))
        return self.dec(r["value_enc"]) if r else None

    def api_names(self, owner_id: int, bot_id: int) -> list[str]:
        return [r["key_name"] for r in self.db.q("SELECT key_name FROM api_configurations WHERE owner_id=? AND bot_id=?", (owner_id, bot_id))]

    def delete_api_value(self, owner_id: int, bot_id: int, name: str):
        self.db.x("DELETE FROM api_configurations WHERE owner_id=? AND bot_id=? AND key_name=?", (owner_id, bot_id, name))

    def all_secrets(self, bot_id: int, owner_id: int) -> list[str]:
        """Redaction के लिए इस Bot के सारे Secrets."""
        out = []
        try:
            t = self.get_bot_token(bot_id, owner_id)
            if t:
                out.append(t)
            for r in self.db.q("SELECT value_enc FROM api_configurations WHERE owner_id=? AND bot_id=?", (owner_id, bot_id)):
                out.append(self.dec(r["value_enc"]))
        except TokenError:
            pass
        return out

    # ------------------------------------------------ requirements status
    def config_status(self, bot: dict, analysis: dict) -> list[dict]:
        """हर ConfigReq की स्थिति: set | missing | source | optional."""
        res = []
        for c in analysis.get("config", []):
            st = "missing"
            if c["method"] in ("source_present", "dotenv_present"):
                st = "source"
            elif c.get("optional"):
                st = "optional"
            if c["kind"] == "token":
                if self.token_info(bot["id"], bot["owner_id"]):
                    st = "set"
                elif st == "source":
                    st = "source"
            else:
                if c["name"] in self.api_names(bot["owner_id"], bot["id"]):
                    st = "set"
            res.append({**c, "status": st})
        return res

    def next_missing(self, bot: dict, analysis: dict) -> dict | None:
        for c in self.config_status(bot, analysis):
            if c["status"] == "missing":
                return c
        return None

    def build_env(self, bot: dict, analysis: dict) -> dict:
        """Container के लिए Environment (सिर्फ़ इसी Bot के Secrets)."""
        env = {}
        owner, bid = bot["owner_id"], bot["id"]
        tok = self.get_bot_token(bid, owner)
        for c in analysis.get("config", []):
            if c["kind"] == "token" and tok and c["method"] in ("env", "dotenv_present"):
                for n in c.get("env_names") or []:
                    env[n] = tok
        if tok and not any(c["kind"] == "token" and c.get("env_names") for c in analysis.get("config", [])):
            pass  # Token env से पढ़ा ही नहीं जाता (placeholder/source) - env में डालने की जरूरत नहीं
        for name in self.api_names(owner, bid):
            v = self.get_api_value(owner, bid, name)
            if v is not None:
                env[name] = v
        return env

    # ---------------------------------------------- placeholder patching
    @staticmethod
    def patch_placeholder(project_dir, req: dict, value: str) -> tuple[bool, str]:
        """सिर्फ़ उसी लाइन का placeholder बदलता है. मूल फाइल .om_backup/ में रखी जाती है.

        यह Source Code बदलता है, इसलिए सिर्फ़ User की साफ़ अनुमति के बाद बुलाएँ.
        """
        if _BAD_LITERAL.search(value or ""):
            return False, "Value में quote/backslash/नई लाइन है; Source में सुरक्षित तरीके से नहीं डाली जा सकती."
        root = Path(project_dir).resolve()
        target = (root / req["file"]).resolve()
        if root not in target.parents or not target.is_file():
            return False, "फाइल नहीं मिली."
        lines = target.read_text("utf-8", "ignore").split("\n")
        i = req["line"] - 1
        lit = req.get("literal", "")
        if not (0 <= i < len(lines)):
            return False, "लाइन नहीं मिली."
        ln = lines[i]
        new_ln = None
        if lit == "__TOKEN__":
            m = TOKEN_RE.search(ln)
            if m:
                new_ln = ln[:m.start()] + value + ln[m.end():]
        for q in (('"', "'") if new_ln is None else ()):
            old = f"{q}{lit}{q}"
            if old in ln:
                new_ln = ln.replace(old, f"{q}{value}{q}", 1)
                break
        if new_ln is None:
            return False, "फाइल बदल चुकी है, placeholder उस लाइन में नहीं मिला."
        bdir = root / ".om_backup"
        bdir.mkdir(exist_ok=True)
        bk = bdir / (req["file"].replace("/", "__") + ".orig")
        if not bk.exists():
            bk.write_bytes(target.read_bytes())
        lines[i] = new_ln
        target.write_text("\n".join(lines), "utf-8")
        return True, "ठीक है."
